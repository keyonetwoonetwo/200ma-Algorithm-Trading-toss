import json
import logging
import os
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

DEFAULT_STATE: Dict[str, Any] = {
    "schema_version": 2,
    "strategy": "generic",
    "cycle_state": "RISK_OFF",
    "cycle_high_close": None,
    "last_milestone": 0,
    "drawdown_triggered_at_high": None,
    "last_execution_date": None,
    "wait_confirmation_count": 0,
    "last_completed_workflow_id": None,
    "last_account_snapshot": None,
    "entry_split_total": 0,
    "entry_split_done": 0,
    "entry_base_cash": "0",
    "entry_reserved_cash": "0",
    "entry_reserved_cash_balance": "0",
    "entry_split_status": "INACTIVE",
    "entry_split_terminated_reason": None,
}


class StateIntegrityError(RuntimeError):
    pass


class StateStore:
    """Manages persistent state.json with atomic writing and discrepancy checks."""

    def __init__(self, state_file_path: str = "data/state.json"):
        self.state_file_path = Path(state_file_path)

    def load_state(self) -> Dict[str, Any]:
        """Loads state dictionary from file or returns default state."""
        if not self.state_file_path.exists():
            logger.info(f"State file {self.state_file_path} not found. Creating default state.")
            self.save_state(DEFAULT_STATE)
            return dict(DEFAULT_STATE)
        try:
            with open(self.state_file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    merged = dict(DEFAULT_STATE)
                    merged.update(data)
                    return merged
                logger.warning("State file did not contain a JSON object. Resetting to default.")
                return dict(DEFAULT_STATE)
        except Exception as exc:
            logger.error(f"Error loading state from {self.state_file_path}: {exc}. Using default state.")
            return dict(DEFAULT_STATE)

    def load_state_strict(self) -> Dict[str, Any]:
        """Load only an explicitly initialized, structurally valid state.

        Unlike the legacy helper, this never creates or resets state.  The
        trading path must fail closed when migration/initialization is needed.
        """
        if not self.state_file_path.exists():
            raise StateIntegrityError("state.json is missing; explicit initialization is required")
        try:
            with open(self.state_file_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except Exception as exc:
            raise StateIntegrityError(f"state.json is unreadable: {exc}") from exc
        if not isinstance(data, dict) or data.get("schema_version") != 2:
            raise StateIntegrityError("state.json requires explicit schema-v2 migration")
        for key in ("cycle_state", "last_milestone", "last_completed_workflow_id", "last_account_snapshot"):
            if key not in data:
                raise StateIntegrityError(f"state.json missing required key: {key}")
        if data["cycle_state"] not in {"RISK_OFF", "WAIT", "RISK_ON"}:
            raise StateIntegrityError("state.json has invalid cycle_state")
        count = data.get("wait_confirmation_count", 0)
        if not isinstance(count, int) or count < 0:
            raise StateIntegrityError("state.json has invalid wait_confirmation_count")
        data.setdefault("wait_confirmation_count", 0)
        split_defaults = {
            "entry_split_total": 0,
            "entry_split_done": 0,
            "entry_base_cash": "0",
            "entry_reserved_cash": "0",
            "entry_reserved_cash_balance": "0",
            "entry_split_status": "INACTIVE",
            "entry_split_terminated_reason": None,
        }
        for key, value in split_defaults.items():
            data.setdefault(key, value)
        if data["entry_split_status"] not in {
            "INACTIVE", "ACTIVE", "COMPLETED", "TERMINATED_OVERHEAT", "TERMINATED_RISK_OFF",
        }:
            raise StateIntegrityError("state.json has invalid entry_split_status")
        if not isinstance(data["entry_split_total"], int) or not isinstance(data["entry_split_done"], int):
            raise StateIntegrityError("state.json has invalid entry split counters")
        if data["entry_split_total"] < 0 or not 0 <= data["entry_split_done"] <= data["entry_split_total"]:
            raise StateIntegrityError("state.json has inconsistent entry split counters")
        for key in ("entry_base_cash", "entry_reserved_cash", "entry_reserved_cash_balance"):
            try:
                if Decimal(str(data[key])) < 0:
                    raise ValueError
            except Exception as exc:
                raise StateIntegrityError(f"state.json has invalid {key}") from exc
        return data

    def initialize_approved_state(self, approved_state: Dict[str, Any]) -> None:
        """Explicit migration/bootstrap entry point; never called automatically."""
        state = dict(DEFAULT_STATE)
        state.update(approved_state)
        state["schema_version"] = 2
        if state.get("last_account_snapshot") is None:
            raise StateIntegrityError("Approved initial state requires an account snapshot")
        self.save_state(state)

    @staticmethod
    def assert_installation_identity(state: Dict[str, Any], identity: Dict[str, str]) -> None:
        """Compare only durable identity keys, accepting legacy 3.80 extras."""
        approved = state.get("installation_identity")
        if not isinstance(approved, dict):
            raise StateIntegrityError("state.json lacks approved installation identity; explicit initialization/recovery is required")
        StateStore.assert_identity_values(approved, identity)

    @staticmethod
    def assert_identity_values(approved: Dict[str, Any], configured: Dict[str, Any]) -> None:
        """Validate protected keys without treating removed tuning keys as identity.

        Keeping the legacy dictionary untouched preserves an auditable record of
        the installation while allowing 3.80 states/workflows to upgrade without
        manual JSON edits or strategy-memory resets.
        """
        keys = (
            "account_no", "account_seq", "signal_symbol", "main_symbol",
            "overheat_symbol", "safe_symbol", "signal_mode", "signal_time",
        )
        mismatches = []
        labels = {
            "account_no": "TOSS_ACCOUNT_NO", "account_seq": "account_seq",
            "signal_symbol": "SIGNAL_SYMBOL", "main_symbol": "MAIN_SYMBOL",
            "overheat_symbol": "OVERHEAT_SYMBOL", "safe_symbol": "SAFE_SYMBOL",
            "signal_mode": "TRADING_SIGNAL_MODE", "signal_time": "SIGNAL_TIME",
        }
        for key in keys:
            old = approved.get(key)
            new = configured.get(key)
            if str(old).strip() != str(new).strip():
                mismatches.append(f"{labels[key]} changed: {old} -> {new}")
        if mismatches:
            raise StateIntegrityError("Installation identity mismatch: " + "; ".join(mismatches))

    @staticmethod
    def account_snapshot(portfolio: Any) -> Dict[str, str]:
        main_qty = portfolio.main_quantity
        main_avg = portfolio.main_avg_price
        overheat_qty = portfolio.overheat_quantity
        safe_qty = portfolio.safe_quantity
        return {
            "account_no": str(getattr(portfolio, "account_no", "")).strip(),
            "account_seq": str(getattr(portfolio, "account_seq", "")),
            "main_quantity": str(main_qty),
            "main_average_purchase_price": str(main_avg),
            "overheat_quantity": str(overheat_qty),
            "safe_quantity": str(safe_qty),
            "available_cash_usd": str(portfolio.available_cash_usd),
            # Legacy keys retained for backward compatibility
            "tqqq_quantity": str(main_qty),
            "tqqq_average_purchase_price": str(main_avg),
            "spym_quantity": str(overheat_qty),
            "sgov_quantity": str(safe_qty),
        }

    def assert_reconciled(
        self, state: Dict[str, Any], portfolio: Any, expected_account_identity: Optional[Dict[str, str]] = None,
    ) -> None:
        snapshot = state.get("last_account_snapshot")
        if not isinstance(snapshot, dict):
            raise StateIntegrityError("No approved account snapshot")
        actual = self.account_snapshot(portfolio)
        if expected_account_identity is not None:
            for key in ("account_no", "account_seq"):
                expected = str(expected_account_identity.get(key, "")).strip()
                if not expected or str(snapshot.get(key, "")).strip() != expected or actual.get(key) != expected:
                    raise StateIntegrityError(f"Broker/state account identity mismatch for {key}")
        # Quantities and Main average price are exact safety invariants.
        # Use Decimal numerical comparison so formatting differences (e.g. "50.00" vs "50")
        # do not cause false StateIntegrityError rejections.
        key_pairs = [
            ("main_quantity", "tqqq_quantity"),
            ("main_average_purchase_price", "tqqq_average_purchase_price"),
            ("overheat_quantity", "spym_quantity"),
            ("safe_quantity", "sgov_quantity"),
        ]
        for primary_key, legacy_key in key_pairs:
            snap_raw = snapshot.get(primary_key)
            if snap_raw is None:
                snap_raw = snapshot.get(legacy_key)
            act_raw = actual.get(primary_key)
            if snap_raw is None or act_raw is None:
                raise StateIntegrityError(f"Missing snapshot or broker value for {primary_key}")
            try:
                snap_val = Decimal(str(snap_raw))
                act_val = Decimal(str(act_raw))
            except Exception as e:
                raise StateIntegrityError(f"Cannot parse {primary_key} to Decimal: {snap_raw} vs {act_raw}") from e
            manual_safe_liquidation = (
                primary_key == "safe_quantity"
                and state.get("entry_split_status") == "TERMINATED_OVERHEAT"
                and act_val <= snap_val
            )
            if snap_val != act_val and not manual_safe_liquidation:
                raise StateIntegrityError(f"Broker/state mismatch for {primary_key}: {snap_val} != {act_val}")
        
        main_qty = portfolio.main_quantity
        overheat_qty = portfolio.overheat_quantity
        if state["cycle_state"] == "RISK_OFF" and (main_qty > 0 or overheat_qty > 0):
            raise StateIntegrityError("RISK_OFF state conflicts with Main/Overheat holdings")
        if state["cycle_state"] == "WAIT" and main_qty > 0:
            raise StateIntegrityError("WAIT state conflicts with Main holdings")
        if state["cycle_state"] == "RISK_ON" and (main_qty <= 0 or state.get("cycle_high_close") is None):
            raise StateIntegrityError("RISK_ON state conflicts with Cycle or Main holdings")

    def save_state(self, state_data: Dict[str, Any]) -> None:
        """Atomically saves state to disk."""
        self.state_file_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self.state_file_path.with_suffix(".tmp")

        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(state_data, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())

            # Atomic replace
            tmp_path.replace(self.state_file_path)
            logger.debug(f"State saved successfully to {self.state_file_path}")
        except Exception as e:
            logger.error(f"Failed to save state to {self.state_file_path}: {e}")
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except Exception:
                    pass
            raise
