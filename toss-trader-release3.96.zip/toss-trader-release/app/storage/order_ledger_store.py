"""Durable order intent ledger.

The ledger is deliberately separate from confirmed strategy state.  A broker
request is never made until its intent is atomically written here.
"""
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
from decimal import Decimal, InvalidOperation

from app.models.order_identity import workflow_client_order_id


DEFAULT_LEDGER: Dict[str, Any] = {
    "schema_version": 1,
    "active_workflow": None,
    "orders": [],
    "workflow_history": [],
}


class LedgerCorruptionError(RuntimeError):
    pass


class OrderLedgerStore:
    def __init__(self, ledger_file_path: str = "data/order_ledger.json"):
        self.path = Path(ledger_file_path)

    def load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return dict(DEFAULT_LEDGER)
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise LedgerCorruptionError(f"Cannot read order ledger: {exc}") from exc
        if (
            not isinstance(raw, dict)
            or raw.get("schema_version") != 1
            or not isinstance(raw.get("orders"), list)
            or raw.get("active_workflow") is not None and not isinstance(raw.get("active_workflow"), dict)
            or "workflow_history" in raw and not isinstance(raw.get("workflow_history"), list)
        ):
            raise LedgerCorruptionError("Order ledger has an invalid shape")
        merged = dict(DEFAULT_LEDGER)
        merged.update(raw)
        return merged

    def load_strict(self) -> Dict[str, Any]:
        """Load an explicitly initialized ledger for a live trading run.

        A missing ledger is not equivalent to an empty ledger after the system
        has operated: it could erase durable intents for already-submitted
        orders.  Live execution must therefore stop and require an operator to
        restore or explicitly initialize the ledger.
        """
        if not self.path.exists():
            raise LedgerCorruptionError("order ledger is missing; live execution requires operator recovery")
        ledger = self.load()
        self.validate_active_workflow(ledger)
        return ledger

    @staticmethod
    def validate_active_workflow(ledger: Dict[str, Any]) -> None:
        """Reject semantically incomplete active-workflow records before recovery."""
        workflow = ledger.get("active_workflow")
        if workflow is None:
            return
        required = ("workflow_id", "execution_core", "execution_policy", "steps", "status", "next_index", "execution_mode")
        if any(key not in workflow for key in required) or not isinstance(workflow.get("steps"), list):
            raise LedgerCorruptionError("Active workflow is semantically incomplete")
        workflow_id = workflow.get("workflow_id")
        if not isinstance(workflow_id, str) or not workflow_id:
            raise LedgerCorruptionError("Active workflow has invalid workflow_id")
        steps = {str(step.get("leg")): step for step in workflow["steps"] if isinstance(step, dict) and step.get("leg")}
        if len(steps) != len(workflow["steps"]):
            raise LedgerCorruptionError("Active workflow has invalid steps")
        for order in ledger.get("orders", []):
            if not isinstance(order, dict) or order.get("workflow_id") != workflow_id:
                continue
            status = order.get("status")
            client_id = order.get("client_order_id")
            leg = order.get("leg")
            if not isinstance(client_id, str) or not client_id or leg not in steps:
                raise LedgerCorruptionError("Workflow order has invalid linkage")
            step = steps[leg]
            expected_client = workflow_client_order_id(workflow, str(leg))
            if client_id != expected_client or order.get("symbol") != step.get("symbol"):
                raise LedgerCorruptionError("Workflow order does not match its persisted step")
            if status == "FILLED":
                fields = ("broker_order_id", "symbol", "side", "requested_quantity", "filled_quantity", "average_filled_price", "filled_amount")
                if any(order.get(key) in (None, "") for key in fields):
                    raise LedgerCorruptionError("FILLED workflow order lacks required execution fields")
                try:
                    requested = Decimal(str(order["requested_quantity"]))
                    filled = Decimal(str(order["filled_quantity"]))
                    average = Decimal(str(order["average_filled_price"]))
                    amount = Decimal(str(order["filled_amount"]))
                except (InvalidOperation, ValueError, TypeError) as exc:
                    raise LedgerCorruptionError("FILLED workflow order has malformed execution fields") from exc
                if requested <= 0 or filled != requested or average <= 0 or amount <= 0:
                    raise LedgerCorruptionError("FILLED workflow order has inconsistent execution fields")
                expected_side = "SELL" if str(step.get("kind", "")).startswith("SELL") else "BUY"
                if order.get("side") not in {"BUY", "SELL"} or order.get("side") != expected_side:
                    raise LedgerCorruptionError("FILLED workflow order side does not match its step")

    def initialize_approved_ledger(self) -> None:
        """Explicit bootstrap entry point; never called automatically by trading."""
        if self.path.exists():
            raise LedgerCorruptionError("order ledger already exists; refusing to overwrite it")
        self.save(dict(DEFAULT_LEDGER))

    def save(self, ledger: Dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(ledger, handle, indent=2, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        temp.replace(self.path)

    def begin_workflow(self, workflow: Dict[str, Any]) -> Dict[str, Any]:
        ledger = self.load()
        if ledger.get("active_workflow"):
            raise RuntimeError("An active workflow already exists")
        ledger["active_workflow"] = workflow
        self.save(ledger)
        return ledger

    def append_intent(self, order: Dict[str, Any]) -> None:
        ledger = self.load()
        if any(x.get("client_order_id") == order["client_order_id"] for x in ledger["orders"]):
            raise RuntimeError(f"Duplicate client order id in ledger: {order['client_order_id']}")
        order = dict(order)
        order["intent_recorded_at"] = datetime.now(timezone.utc).isoformat()
        ledger["orders"].append(order)
        self.save(ledger)

    def update_order(self, client_order_id: str, **changes: Any) -> None:
        ledger = self.load()
        for order in ledger["orders"]:
            if order.get("client_order_id") == client_order_id:
                order.update(changes)
                order["last_checked_at"] = datetime.now(timezone.utc).isoformat()
                self.save(ledger)
                return
        raise KeyError(f"Unknown ledger order: {client_order_id}")

    def update_workflow(self, **changes: Any) -> None:
        ledger = self.load()
        workflow = ledger.get("active_workflow")
        if not workflow:
            raise RuntimeError("No active workflow")
        workflow.update(changes)
        workflow["updated_at"] = datetime.now(timezone.utc).isoformat()
        self.save(ledger)

    def complete_workflow(self) -> None:
        ledger = self.load()
        ledger["active_workflow"] = None
        self.save(ledger)

    def abort_workflow(self, terminal_status: str, abort_reason: str, **details: Any) -> Dict[str, Any]:
        """Durably retain a terminal abort record, then clear only active_workflow."""
        if not terminal_status.startswith("ABORTED_"):
            raise ValueError("terminal abort status must start with ABORTED_")
        ledger = self.load()
        workflow = ledger.get("active_workflow")
        if not workflow:
            raise RuntimeError("No active workflow")
        workflow_id = workflow.get("workflow_id")
        workflow_orders = [
            order for order in ledger.get("orders", [])
            if order.get("workflow_id") == workflow_id
        ]
        record = {
            "workflow_id": workflow_id,
            "terminal_status": terminal_status,
            "previous_status": workflow.get("status"),
            "abort_reason": abort_reason,
            "aborted_at": datetime.now(timezone.utc).isoformat(),
            "order_count": len(workflow_orders),
            "broker_final_order_status": details.pop("broker_final_order_status", None),
            "filled_quantity": details.pop("filled_quantity", "0"),
            "cancel_result": details.pop("cancel_result", None),
        }
        record.update(details)
        ledger.setdefault("workflow_history", []).append(record)
        ledger["active_workflow"] = None
        self.save(ledger)
        return record


class ProcessLock:
    """Fail closed single-process lock. Stale locks require operator action."""

    def __init__(self, path: str = "data/trader.lock"):
        self.path = Path(path)
        self.acquired = False

    def __enter__(self) -> "ProcessLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            raise RuntimeError(f"Execution lock exists: {self.path}") from exc
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(f"pid={os.getpid()} started_at={datetime.now(timezone.utc).isoformat()}\n")
            handle.flush()
            os.fsync(handle.fileno())
        self.acquired = True
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self.acquired and self.path.exists():
            self.path.unlink()
