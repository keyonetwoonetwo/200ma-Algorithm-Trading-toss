import json
import logging
from html import escape
import urllib.error
import urllib.request
from decimal import Decimal
from typing import List, Optional
from app.models.common import OrderStatus
from app.models.orders import ExecutionRecord, OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState

logger = logging.getLogger(__name__)


def _html(value: object) -> str:
    return escape(str(value), quote=True)


def _money(value: Optional[Decimal]) -> str:
    return f"${value:.2f}" if value is not None else "N/A"


def _quantity(value: object) -> str:
    quantity = Decimal(str(value))
    return str(int(quantity)) if quantity == quantity.to_integral_value() else format(quantity, "f")


class TelegramNotifier:
    """Sends notifications to a Telegram chat safely without leaking sensitive information."""

    def __init__(
        self,
        bot_token: str,
        chat_id: str,
        enabled: bool = True,
        timeout_seconds: int = 10,
    ):
        self.bot_token = bot_token
        self.chat_id = chat_id
        if enabled and not (bot_token and chat_id):
            raise ValueError("TELEGRAM_ENABLED=true requires TELEGRAM_BOT_TOKEN and TELEGRAM_ALERT_CHAT_ID")
        self.enabled = enabled and bool(bot_token and chat_id)
        self.timeout_seconds = timeout_seconds

    def send_message(self, text: str) -> bool:
        if not self.enabled:
            logger.debug(f"[Telegram Disabled] Message not sent: {text[:60]}...")
            return False

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        data_bytes = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"}

        req = urllib.request.Request(url, data=data_bytes, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                if resp.status == 200:
                    logger.debug("Telegram message sent successfully.")
                    return True
                else:
                    logger.warning(f"Telegram API responded with status: {resp.status}")
                    return False
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8")
            logger.warning(f"Telegram API HTTP error {e.code}: {err_body}")
            return False
        except Exception as e:
            logger.error(f"Failed to send Telegram notification: {e}")
            return False

    def notify_startup(self, mode: str, date_str: str) -> None:
        msg = f"🚀 <b>[자동매매 시작]</b>\n- 실행 모드: <code>{_html(mode)}</code>\n- 기준일자: <code>{_html(date_str)}</code>"
        self.send_message(msg)

    def notify_decision(
        self,
        decision: StrategyDecision,
        plan: OrderPlan,
        portfolio: PortfolioState,
        main_symbol: str = "MAIN",
        overheat_symbol: str = "OVERHEAT",
        safe_symbol: str = "SAFE",
        wait_days: int = 0,
        entry_split: int = 1,
        entry_split_overheat_action: str = "SAFE",
    ) -> None:
        display_decision = decision.display_decision or decision.decision
        signal_symbol = decision.signal_symbol or "N/A"
        holding = (
            f"- 보유 {_html(main_symbol)}: {_quantity(portfolio.main_quantity)}주 "
            f"(평단: {_money(portfolio.main_avg_price)})"
        )
        main_price = portfolio.prices.get(main_symbol)
        if portfolio.main_quantity <= 0:
            holding = holding[:-1] + ", 수익률: 0.0%)"
        elif portfolio.main_avg_price > 0 and main_price is not None and main_price > 0:
            return_rate = ((main_price / portfolio.main_avg_price) - Decimal("1")) * Decimal("100")
            holding = holding[:-1] + f", 수익률: {return_rate:.1f}%)"

        lines = [
            f"📊 <b>[전략 판단: {_html(display_decision)}]</b>",
            f"- 신호 종목: {_html(signal_symbol)}",
            f"- 신호 종가: <b>{_money(decision.signal_close)}</b>",
            f"- 200MA: {_money(decision.signal_ma200)}",
            f"- Risk-On 기준: {_money(decision.risk_on_price)}",
            f"- Overheat 기준: {_money(decision.overheat_price)}",
            f"- 메인 종목: {_html(main_symbol)}",
            holding,
            (
                f"- 보유 {_html(overheat_symbol)}: {_quantity(portfolio.overheat_quantity)}주 | "
                f"{_html(safe_symbol)}: {_quantity(portfolio.safe_quantity)}주"
            ),
            f"- 주문가능 달러: {_money(portfolio.available_cash_usd)}",
            f"- 판단 근거: {_html(decision.reason)}",
            (
                f"- 진입 설정: 대기 {wait_days}일 | ENTRY_SPLIT={entry_split} | "
                f"미진입 tranche={_html(entry_split_overheat_action)}"
            ),
        ]
        split = plan.entry_split or {}
        if split.get("kind") == "TRANCHE":
            lines.append(
                f"- 분할 진입: {_html(split.get('tranche_index'))}/{_html(split.get('total'))}"
            )
        self.send_message("\n".join(lines))

    def notify_execution(self, records: List[ExecutionRecord]) -> None:
        if not records:
            return

        def display_status(record: ExecutionRecord) -> str:
            if record.order_id == "UNKNOWN" or record.status == OrderStatus.PENDING:
                return "UNKNOWN"
            if record.status == OrderStatus.PARTIAL_FILLED:
                return "PARTIAL"
            return record.status.value

        statuses = [display_status(record) for record in records]
        unsafe = any(status != OrderStatus.FILLED.value for status in statuses)
        icon = "⚠️" if unsafe else "⚡"
        lines = [f"{icon} <b>[주문 실행 결과]</b>"]
        for r in records:
            status = display_status(r)
            lines.extend([
                "",
                f"- 주문: {_html(r.side.value)} {_html(r.symbol)}",
                f"- 체결상태: <code>{_html(status)}</code>",
                f"- 체결단가: {_money(r.average_filled_price)}",
                f"- 체결수량: {_quantity(r.filled_quantity)}주",
            ])
            if status != OrderStatus.FILLED.value:
                lines.append(f"- 요청수량: {_quantity(r.quantity)}주")
                lines.append("- 조치: 자동 진행 중단")
        self.send_message("\n".join(lines))

    def notify_error(self, error_message: str) -> None:
        msg = f"🚨 <b>[시스템 오류 발생]</b>\n<code>{_html(error_message)}</code>"
        self.send_message(msg)

    def notify_warning(self, warning_message: str) -> None:
        msg = f"⚠️ <b>[거래 안전 경고]</b>\n<code>{_html(warning_message)}</code>"
        self.send_message(msg)
