import logging
from datetime import datetime, timezone
from typing import Optional
from zoneinfo import ZoneInfo
from app.api.base_broker import BaseBrokerAPI
from app.models.market import MarketSessionInfo
from config.defaults import NY_ZONE

logger = logging.getLogger(__name__)

NY_TZ = ZoneInfo(NY_ZONE)


class MarketCalendarService:
    """Service to verify US Market trading days and hours using Toss API."""

    def __init__(self, broker_api: BaseBrokerAPI):
        self.broker_api = broker_api

    def check_us_market_open(self, date_str: Optional[str] = None) -> MarketSessionInfo:
        """Queries US market calendar to verify if today is a valid regular trading day."""
        resp = self.broker_api.get_us_market_calendar(date_str=date_str)
        today_data = resp.get("today", {})
        previous_data = resp.get("previousBusinessDay", {})
        dt_str = today_data.get("date", date_str or datetime.now(NY_TZ).strftime("%Y-%m-%d"))

        reg_market = today_data.get("regularMarket")
        if reg_market is None:
            logger.info(f"US Market is CLOSED on {dt_str} (holiday or weekend).")
            return MarketSessionInfo(
                is_business_day=False,
                is_regular_market_open=False,
                date_str=dt_str,
            )

        start_time = None
        end_time = None
        if isinstance(reg_market, dict):
            try:
                start_time = datetime.fromisoformat(reg_market["startTime"])
                end_time = datetime.fromisoformat(reg_market["endTime"])
            except Exception:
                pass

        after_start = None
        after_end = None
        after_market = today_data.get("afterMarket")
        if isinstance(after_market, dict):
            try:
                after_start = datetime.fromisoformat(after_market["startTime"])
                after_end = datetime.fromisoformat(after_market["endTime"])
            except Exception:
                pass

        logger.info(
            f"US Market on {dt_str}: Regular ({start_time} ~ {end_time}), "
            f"After-Market ({after_start} ~ {after_end})"
        )
        return MarketSessionInfo(
            is_business_day=True,
            is_regular_market_open=True,
            date_str=dt_str,
            regular_start=start_time,
            regular_end=end_time,
            after_start=after_start,
            after_end=after_end,
            previous_business_date=previous_data.get("date") if isinstance(previous_data, dict) else None,
        )

    @staticmethod
    def is_now_in_regular_session(session: MarketSessionInfo, now: Optional[datetime] = None) -> bool:
        """Checks if current time is within US regular market hours."""
        if not session.is_business_day or not session.regular_start or not session.regular_end:
            return False
        current = now or datetime.now(timezone.utc)
        if current.tzinfo is None:
            raise ValueError("now must be timezone-aware")
        return session.regular_start <= current < session.regular_end
