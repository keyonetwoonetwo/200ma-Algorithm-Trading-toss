from decimal import Decimal
from typing import List
from app.models.market import Candle, IndicatorResult


class IndicatorCalculator:
    """Calculates technical indicators without heavy dependencies (pure Decimal)."""

    @staticmethod
    def calculate_ma(closes: List[Decimal], period: int) -> Decimal:
        if len(closes) < period:
            raise ValueError(f"Insufficient close prices ({len(closes)}) for MA period {period}")
        subset = closes[-period:]
        return sum(subset) / Decimal(period)

    @classmethod
    def calculate_indicators(
        cls,
        candles: List[Candle],
        period: int,
        overheat_multiplier: float,
        symbol: str,
    ) -> IndicatorResult:
        """Calculate current and previous moving averages for the configured signal symbol.

        Expects `candles` to be sorted in chronological order (oldest to newest).
        Requires at least `period + 1` candles (e.g. 201 candles) to compute both today's and yesterday's 200MA.
        """
        if len(candles) < period + 1:
            raise ValueError(
                f"Requires at least {period + 1} candles for today and yesterday's 200MA calculation. Got {len(candles)}"
            )

        closes = [c.close for c in candles]

        # Today (latest candle at index -1)
        current_close = closes[-1]
        ma200 = cls.calculate_ma(closes, period=period)

        # Yesterday (candle at index -2)
        prev_closes = closes[:-1]
        prev_close = prev_closes[-1]
        prev_ma200 = cls.calculate_ma(prev_closes, period=period)

        is_above_ma200 = current_close >= ma200
        is_prev_above_ma200 = prev_close >= prev_ma200
        overheat_price = ma200 * Decimal(str(overheat_multiplier))

        return IndicatorResult(
            symbol=symbol,
            current_close=current_close,
            ma200=ma200,
            prev_close=prev_close,
            prev_ma200=prev_ma200,
            is_above_ma200=is_above_ma200,
            is_prev_above_ma200=is_prev_above_ma200,
            overheat_price=overheat_price,
        )
