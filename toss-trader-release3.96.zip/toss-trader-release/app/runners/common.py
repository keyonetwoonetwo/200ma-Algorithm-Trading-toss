"""Mode-independent prepared strategy input.

Runners own session/data validation only. They must hand the strategy engine the same
shape of input so that no signal-specific strategy implementation can drift.
"""
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional
from decimal import Decimal
from typing import List

from app.models.market import Candle, IndicatorResult, MarketSessionInfo
from config.defaults import DEFAULT_SIGNAL_SYMBOL


class ExpectedNoOp(RuntimeError):
    """A known, safe scheduling condition that must end the run successfully."""


@dataclass(frozen=True)
class PreparedStrategyInput:
    signal_date: str
    decision_price: Decimal
    candles: List[Candle]
    indicators: IndicatorResult
    session: MarketSessionInfo
    execution_policy: Optional[Dict[str, Any]] = None
    signal_symbol: str = DEFAULT_SIGNAL_SYMBOL
    main_lifecycle_price: Optional[Decimal] = None
