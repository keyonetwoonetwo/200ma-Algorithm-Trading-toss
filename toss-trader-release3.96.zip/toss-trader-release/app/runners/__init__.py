from app.runners.close_runner import CloseRunner
from app.runners.minute_runner import MinuteRunner

RUNNERS = {"CLOSE": CloseRunner, "MINUTE": MinuteRunner}

__all__ = ["CloseRunner", "MinuteRunner", "RUNNERS"]
