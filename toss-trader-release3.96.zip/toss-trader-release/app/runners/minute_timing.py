"""Close-relative MINUTE timing shared by the runner and deploy schedulers."""
from dataclasses import dataclass
from datetime import date, datetime, time as clock_time, timedelta
from zoneinfo import ZoneInfo

from app.models.market import MarketSessionInfo
from config.defaults import NY_ZONE


NY_TZ = ZoneInfo(NY_ZONE)
CANONICAL_REGULAR_CLOSE = clock_time(16, 0)
SCHEDULER_REGULAR_CLOSE_CANDIDATES = (clock_time(13, 0), CANONICAL_REGULAR_CLOSE)


def _at(day: date, value: clock_time) -> datetime:
    return datetime.combine(day, value, tzinfo=NY_TZ)


def close_relative_time(configured_time: str, actual_close: clock_time) -> clock_time:
    """Map a 16:00-based configured wall time to a candidate close time."""
    day = date(2000, 1, 1)
    configured = clock_time.fromisoformat(configured_time)
    offset = _at(day, CANONICAL_REGULAR_CLOSE) - _at(day, configured)
    effective = _at(day, actual_close) - offset
    if effective.date() != day:
        raise ValueError("MINUTE close-relative time falls outside the market date")
    return effective.time()


def scheduler_execution_times(signal_time: str, delay: timedelta) -> tuple[str, ...]:
    """Return early-close and regular-close invocation candidates."""
    day = date(2000, 1, 1)
    values = []
    for close in SCHEDULER_REGULAR_CLOSE_CANDIDATES:
        signal = close_relative_time(signal_time, close)
        execution = _at(day, signal) + delay
        if execution.date() != day or execution.time() >= close:
            raise ValueError(
                f"MINUTE execution timer would reach the {close.isoformat()} NY close"
            )
        value = execution.strftime("%H:%M:%S")
        if value not in values:
            values.append(value)
    return tuple(values)


@dataclass(frozen=True)
class MinuteSessionTiming:
    signal_at: datetime
    polling_start: datetime
    order_cutoff: datetime

    @property
    def signal_time(self) -> str:
        return self.signal_at.strftime("%H:%M:%S")


def session_timing(
    session: MarketSessionInfo,
    configured_signal_time: str,
    configured_order_cutoff: str,
) -> MinuteSessionTiming:
    """Shift the configured full-session window by the broker's actual close."""
    if not session.regular_start or not session.regular_end:
        raise ValueError("MINUTE calendar regular session timestamps unavailable")
    if session.regular_start.tzinfo is None or session.regular_end.tzinfo is None:
        raise ValueError("MINUTE calendar regular session timestamps must be timezone-aware")

    start = session.regular_start.astimezone(NY_TZ)
    end = session.regular_end.astimezone(NY_TZ)
    if start >= end or start.date() != end.date():
        raise ValueError("MINUTE calendar regular session timestamps are invalid")

    canonical_close = _at(end.date(), CANONICAL_REGULAR_CLOSE)
    configured_signal = _at(end.date(), clock_time.fromisoformat(configured_signal_time))
    configured_cutoff = _at(end.date(), clock_time.fromisoformat(configured_order_cutoff))
    signal_at = end - (canonical_close - configured_signal)
    polling = signal_at + timedelta(minutes=1)
    cutoff = end - (canonical_close - configured_cutoff)

    if not (start <= signal_at < polling < cutoff < end):
        raise ValueError(
            "MINUTE effective signal window falls outside the Toss regular market session"
        )
    return MinuteSessionTiming(signal_at, polling, cutoff)
