"""Polling-based finalization of the US regular-session daily candle."""
import logging
import time
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Callable, Optional
from zoneinfo import ZoneInfo

from app.market import IndicatorCalculator, MarketCalendarService, MarketDataService
from config.config import AppConfig
from config.defaults import NY_ZONE
from app.runners.common import ExpectedNoOp, PreparedStrategyInput

NY_TZ = ZoneInfo(NY_ZONE)
logger = logging.getLogger(__name__)

CLOSE_POLL_INTERVAL_SECONDS = 10.0
CLOSE_FINALIZATION_WINDOW = timedelta(minutes=6)
CLOSE_STABLE_OBSERVATIONS = 3
CLOSE_POLL_LOG_MAX_BYTES = 5 * 1024 * 1024
CLOSE_POLL_LOG_BACKUP_COUNT = 2


def configure_close_polling_file_log(
    path: Optional[Path] = None,
    max_bytes: int = CLOSE_POLL_LOG_MAX_BYTES,
    backup_count: int = CLOSE_POLL_LOG_BACKUP_COUNT,
) -> RotatingFileHandler:
    """Add one bounded, persistent CLOSE log while retaining stdout propagation."""
    log_path = path or (Path(__file__).resolve().parents[2] / "logs" / "close_polling.log")
    log_path = log_path.resolve()
    for handler in logger.handlers:
        if getattr(handler, "_toss_close_poll_path", None) == str(log_path):
            return handler
    log_path.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        log_path, maxBytes=max_bytes, backupCount=backup_count,
        encoding="utf-8", delay=True,
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    ))
    handler._toss_close_poll_path = str(log_path)
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)
    return handler


class CloseRunner:
    def __init__(
        self,
        now_fn: Optional[Callable[[], datetime]] = None,
        sleep_fn: Optional[Callable[[float], None]] = None,
        poll_interval_seconds: float = CLOSE_POLL_INTERVAL_SECONDS,
    ):
        self.now_fn = now_fn or (lambda: datetime.now(timezone.utc))
        self.sleep_fn = sleep_fn or time.sleep
        self.poll_interval_seconds = poll_interval_seconds

    def _now_ny(self) -> datetime:
        value = self.now_fn()
        if value.tzinfo is None:
            raise ValueError("clock must return a timezone-aware datetime")
        return value.astimezone(NY_TZ)

    @staticmethod
    def _market_date_candle(candles, market_date: str):
        matches = []
        for candle in candles:
            timestamp = candle.timestamp
            ny_timestamp = timestamp.astimezone(NY_TZ) if timestamp.tzinfo else timestamp.replace(tzinfo=NY_TZ)
            if ny_timestamp.date().isoformat() == market_date:
                matches.append(candle)
        if len(matches) != 1:
            return None
        return matches[0]

    def _poll_finalized_daily_candles(
        self,
        market: MarketDataService,
        symbol: str,
        market_date: str,
        regular_end: datetime,
        target_count: int,
    ):
        close_time = regular_end.astimezone(NY_TZ)
        deadline = close_time + CLOSE_FINALIZATION_WINDOW
        now_ny = self._now_ny()
        if now_ny < close_time:
            raise ExpectedNoOp(f"CLOSE polling has not started; regular market ends at {close_time.isoformat()}")
        if now_ny > deadline:
            raise ExpectedNoOp(f"CLOSE candle was not finalized by {deadline.isoformat()}; no trade")

        previous_ohlc = None
        stable_count = 0
        while True:
            observed_at = self._now_ny()
            if observed_at > deadline:
                break
            try:
                # Poll only the latest 1d record.  Fetch the indicator history
                # once, after stability, to avoid multiplying paginated API reads.
                candles = market.fetch_daily_candles(symbol=symbol, target_count=1)
                candle = self._market_date_candle(candles, market_date)
                if candle is None:
                    stable_count = 0
                    previous_ohlc = None
                    logger.warning(
                        "CLOSE poll NY=%s candle_timestamp=NONE OHLC=NONE volume=NONE stable_count=0",
                        observed_at.isoformat(),
                    )
                else:
                    ohlc = (candle.open, candle.high, candle.low, candle.close)
                    stable_count = stable_count + 1 if ohlc == previous_ohlc else 1
                    previous_ohlc = ohlc
                    logger.info(
                        "CLOSE poll NY=%s candle_timestamp=%s OHLC=(%s,%s,%s,%s) volume=%s stable_count=%s",
                        observed_at.isoformat(), candle.timestamp.isoformat(),
                        candle.open, candle.high, candle.low, candle.close, candle.volume, stable_count,
                    )
                    if stable_count >= CLOSE_STABLE_OBSERVATIONS:
                        history = market.fetch_daily_candles(symbol=symbol, target_count=target_count)
                        history_candle = self._market_date_candle(history, market_date)
                        history_ohlc = (
                            (history_candle.open, history_candle.high, history_candle.low, history_candle.close)
                            if history_candle is not None else None
                        )
                        if history_ohlc == ohlc:
                            return history
                        # The history read is newer broker evidence.  It becomes
                        # observation 1 of a new candidate tuple.
                        previous_ohlc = history_ohlc
                        stable_count = 1 if history_ohlc is not None else 0
                        logger.warning(
                            "CLOSE history verification changed NY=%s candle_timestamp=%s OHLC=%s volume=%s stable_count=%s",
                            self._now_ny().isoformat(),
                            history_candle.timestamp.isoformat() if history_candle else "NONE",
                            history_ohlc,
                            history_candle.volume if history_candle else "NONE",
                            stable_count,
                        )
            except Exception as exc:
                # A transient read error is not evidence that a candle is stable.
                stable_count = 0
                previous_ohlc = None
                logger.warning(
                    "CLOSE poll NY=%s candle_timestamp=ERROR OHLC=ERROR volume=ERROR stable_count=0 error=%s",
                    observed_at.isoformat(), exc,
                )

            remaining = (deadline - self._now_ny()).total_seconds()
            if remaining <= 0:
                break
            self.sleep_fn(min(self.poll_interval_seconds, remaining))

        raise ExpectedNoOp(f"CLOSE candle was not operationally finalized by {deadline.isoformat()}; no trade")

    def prepare(self, config: AppConfig, calendar: MarketCalendarService, market: MarketDataService) -> PreparedStrategyInput:
        profile = config.resolved_strategy()
        now_ny = self._now_ny()
        session = calendar.check_us_market_open(date_str=now_ny.date().isoformat())
        if not session.is_business_day or not session.is_regular_market_open:
            raise ExpectedNoOp("미국 시장 휴장 - 실행 없음")
        if not session.regular_end:
            raise ValueError("Toss US regularMarket.endTime is unavailable; CLOSE execution is fail-closed")
        if session.regular_end.tzinfo is None:
            raise ValueError("Toss US regularMarket.endTime must be timezone-aware")
        if not session.after_start or not session.after_end:
            raise ValueError("Toss US afterMarket session is unavailable; CLOSE execution is fail-closed")
        if session.after_start.tzinfo is None or session.after_end.tzinfo is None:
            raise ValueError("Toss US afterMarket session timestamps must be timezone-aware")
        if session.after_start >= session.after_end:
            raise ValueError("Toss US afterMarket session timestamps are invalid")
        signal_symbol = profile.signal_symbol
        candles = self._poll_finalized_daily_candles(
            market, signal_symbol, session.date_str, session.regular_end,
            config.trading.candle_lookback_days,
        )
        finalized = self._market_date_candle(candles, session.date_str)
        if finalized is None:
            raise ExpectedNoOp("Finalized CLOSE candle could not be identified; no trade")
        indicators = IndicatorCalculator.calculate_indicators(
            candles, config.strategy_rules.ma_period,
            profile.overheat_threshold,
            symbol=signal_symbol,
        )
        lifecycle_price = finalized.close
        if signal_symbol != profile.main_symbol:
            main_candles = market.fetch_daily_candles(profile.main_symbol, config.trading.candle_lookback_days)
            market.assert_latest_daily_candle_confirmed(main_candles, session.date_str)
            lifecycle_price = max(main_candles, key=lambda candle: candle.timestamp).close
        return PreparedStrategyInput(
            session.date_str, indicators.current_close, candles, indicators, session,
            {
                "kind": "CLOSE",
                "market_date": session.date_str,
                "regular_market_end": session.regular_end.isoformat(),
                "candle_finalization_deadline": (session.regular_end + CLOSE_FINALIZATION_WINDOW).isoformat(),
                "after_market_start": session.after_start.isoformat(),
                "after_market_end": session.after_end.isoformat(),
            }, signal_symbol, lifecycle_price,
        )
