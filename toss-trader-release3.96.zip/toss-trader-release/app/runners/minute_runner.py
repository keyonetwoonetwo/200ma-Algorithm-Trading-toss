"""Generic finalized NY one-minute signal preparation during regular trading."""
import time
from datetime import datetime, time as clock_time, timedelta, timezone
from typing import Callable, List, Optional
from zoneinfo import ZoneInfo

from app.market import IndicatorCalculator, MarketCalendarService, MarketDataService
from app.models.market import Candle, MarketSessionInfo
from app.runners.common import ExpectedNoOp, PreparedStrategyInput
from app.runners.minute_timing import MinuteSessionTiming, session_timing
from config.config import AppConfig
from config.defaults import NY_ZONE

NY_TZ = ZoneInfo(NY_ZONE)


class MinuteRunner:
    def __init__(self, now_fn: Optional[Callable[[], datetime]] = None, sleep_fn: Optional[Callable[[float], None]] = None):
        self.now_fn = now_fn or (lambda: datetime.now(timezone.utc))
        self.sleep_fn = sleep_fn or time.sleep

    @staticmethod
    def _ny_time(value: str) -> clock_time:
        return clock_time.fromisoformat(value)

    @staticmethod
    def polling_start(signal_time: str) -> clock_time:
        """A completed signal minute is first eligible next minute at :00."""
        parsed = datetime.combine(datetime(2000, 1, 1).date(), MinuteRunner._ny_time(signal_time))
        return (parsed + timedelta(minutes=1)).time()

    def _now_ny(self) -> datetime:
        value = self.now_fn()
        if value.tzinfo is None:
            raise ValueError("clock must return a timezone-aware datetime")
        return value.astimezone(NY_TZ)

    def _in_window(self, session: MarketSessionInfo, timing: MinuteSessionTiming, now: Optional[datetime] = None) -> bool:
        now = now or self._now_ny()
        if not MarketCalendarService.is_now_in_regular_session(session, now):
            return False
        return timing.polling_start <= now <= timing.order_cutoff

    @staticmethod
    def _validate_regular_session(session: MarketSessionInfo) -> None:
        """Preserve fail-closed handling for malformed regular sessions."""
        if not session.regular_start or not session.regular_end:
            raise ValueError("MINUTE calendar regular session timestamps unavailable")
        if session.regular_start.tzinfo is None or session.regular_end.tzinfo is None:
            raise ValueError("MINUTE calendar regular session timestamps must be timezone-aware")
        if session.regular_start >= session.regular_end:
            raise ValueError("MINUTE calendar regular session timestamps are invalid")

    @staticmethod
    def select_signal_candle(candles: List[Candle], market_date: str, signal_time: str) -> Candle:
        target_time = MinuteRunner._ny_time(signal_time)
        target = []
        for candle in candles:
            timestamp = candle.timestamp
            ny_dt = timestamp.astimezone(NY_TZ) if timestamp.tzinfo else timestamp.replace(tzinfo=NY_TZ)
            if ny_dt.date().isoformat() == market_date and ny_dt.time() == target_time:
                target.append(candle)
        if not target:
            raise ValueError(f"Finalized {market_date} {signal_time} America/New_York candle is unavailable")
        if len(target) != 1:
            raise ValueError(f"Ambiguous duplicate {signal_time} candle")
        return target[0]

    def _fetch_signal_with_polling(
        self, market: MarketDataService, config: AppConfig, session: MarketSessionInfo,
        timing: MinuteSessionTiming, symbol: Optional[str] = None,
    ) -> Candle:
        profile = config.resolved_strategy()
        symbol = symbol or profile.main_symbol
        while True:
            candles = market.fetch_intraday_candles(symbol, interval="1m", count=5)
            try:
                return self.select_signal_candle(candles, session.date_str, timing.signal_time)
            except ValueError:
                if self._now_ny() >= timing.order_cutoff:
                    raise ValueError(f"{timing.signal_time} candle unavailable before MINUTE order cutoff")
                self.sleep_fn(config.minute.polling_interval_seconds)

    def prepare(self, config: AppConfig, calendar: MarketCalendarService, market: MarketDataService) -> PreparedStrategyInput:
        profile = config.resolved_strategy()
        now_ny = self._now_ny()
        market_date = now_ny.date().isoformat()
        session = calendar.check_us_market_open(date_str=market_date)
        if not session.is_business_day or not session.is_regular_market_open:
            raise ExpectedNoOp("미국 시장 휴장 - 실행 없음")
        self._validate_regular_session(session)
        timing = session_timing(session, profile.signal_time, config.minute.order_cutoff)
        if not self._in_window(session, timing, now=now_ny):
            raise ExpectedNoOp("MINUTE 실행 시간 외 - 실행 없음")
        decision_candle = self._fetch_signal_with_polling(
            market, config, session, timing, profile.signal_symbol,
        )

        # Never read today's in-progress daily bar.  The signal minute becomes
        # the synthetic current candle on top of confirmed prior daily history.
        dailies = market.fetch_daily_candles(profile.signal_symbol, config.trading.candle_lookback_days + 1)
        prior_dailies = market.exclude_market_date(dailies, session.date_str)
        if len(prior_dailies) < config.strategy_rules.ma_period:
            raise ValueError("Insufficient confirmed prior daily candles for MINUTE")
        if not session.previous_business_date:
            raise ValueError("Broker calendar did not provide previous business date for MINUTE")
        latest_prior = prior_dailies[-1]
        latest_prior_ny = (latest_prior.timestamp.astimezone(NY_TZ) if latest_prior.timestamp.tzinfo else latest_prior.timestamp.replace(tzinfo=NY_TZ)).date().isoformat()
        if latest_prior_ny != session.previous_business_date:
            raise ValueError(f"Latest prior daily candle ({latest_prior_ny}) does not match broker previous business day ({session.previous_business_date})")
        synthetic_today = Candle(decision_candle.timestamp, decision_candle.open, decision_candle.high, decision_candle.low, decision_candle.close, decision_candle.volume, decision_candle.currency)
        strategy_candles = prior_dailies + [synthetic_today]
        indicators = IndicatorCalculator.calculate_indicators(strategy_candles, config.strategy_rules.ma_period, profile.overheat_threshold, symbol=profile.signal_symbol)
        lifecycle_price = decision_candle.close
        if profile.signal_symbol != profile.main_symbol:
            lifecycle_price = self._fetch_signal_with_polling(
                market, config, session, timing, profile.main_symbol,
            ).close
        policy = {
            "kind": "MINUTE_V1",
            "market_date": session.date_str,
            "signal_time": timing.signal_time,
            "configured_signal_time": profile.signal_time,
            "admission_deadline": timing.order_cutoff.isoformat(),
            "new_leg_deadline": session.regular_end.astimezone(NY_TZ).isoformat(),
        }
        return PreparedStrategyInput(session.date_str, decision_candle.close, strategy_candles, indicators, session, policy, profile.signal_symbol, lifecycle_price)
