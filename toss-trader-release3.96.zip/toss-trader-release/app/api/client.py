import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional
from app.api.auth import TossAuthManager

logger = logging.getLogger(__name__)


class TossAPIClient:
    """HTTP Client for interacting with Toss Securities Open API.

    Handles header injection, envelope unwrapping, error mapping, and authentication.
    """

    def __init__(
        self,
        base_url: str,
        auth_manager: TossAuthManager,
        account_seq: Optional[int] = None,
        timeout_seconds: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.auth_manager = auth_manager
        self.account_seq = account_seq
        self.timeout_seconds = timeout_seconds

    def set_account_seq(self, account_seq: int) -> None:
        self.account_seq = account_seq

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        require_account: bool = False,
        retry_on_401: Optional[bool] = None,
    ) -> Any:
        """Executes an authenticated HTTP request and extracts `result` from ApiResponse envelope."""
        method = method.upper()
        # Authentication retry is safe by default only for read-only methods.
        # A mutation may have reached Toss even when its response is a 401, so
        # silently replaying it would violate the no-automatic-resubmission rule.
        if retry_on_401 is None:
            retry_on_401 = method in {"GET", "HEAD", "OPTIONS"}
        token = self.auth_manager.get_access_token()
        req_headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }
        data_bytes: Optional[bytes] = None
        if json_data is not None:
            req_headers["Content-Type"] = "application/json"
            data_bytes = json.dumps(json_data).encode("utf-8")

        if require_account:
            if self.account_seq is None:
                raise ValueError("X-Tossinvest-Account header is required but account_seq is not set.")
            req_headers["X-Tossinvest-Account"] = str(self.account_seq)

        if headers:
            req_headers.update(headers)

        query_str = ""
        if params:
            query_str = "?" + urllib.parse.urlencode(params)

        url = f"{self.base_url}{path}{query_str}"
        logger.debug(f"HTTP {method} {url} json={json_data}")

        req = urllib.request.Request(url, data=data_bytes, headers=req_headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                body_bytes = resp.read()
                body = json.loads(body_bytes.decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 401 and retry_on_401:
                logger.warning("Received 401 Unauthorized. Refreshing token and retrying...")
                new_token = self.auth_manager.issue_token()
                req_headers["Authorization"] = f"Bearer {new_token}"
                retry_req = urllib.request.Request(url, data=data_bytes, headers=req_headers, method=method)
                try:
                    with urllib.request.urlopen(retry_req, timeout=self.timeout_seconds) as resp2:
                        body_bytes = resp2.read()
                        body = json.loads(body_bytes.decode("utf-8"))
                except urllib.error.HTTPError as e2:
                    self._handle_http_error(e2, method, url)
            else:
                self._handle_http_error(e, method, url)
        except Exception as e:
            logger.error(f"Network error on {method} {url}: {e}")
            raise

        # BFF Envelope unwrapping: {"result": ...}
        if isinstance(body, dict) and "result" in body:
            return body["result"]

        return body

    def _handle_http_error(self, e: urllib.error.HTTPError, method: str, url: str) -> None:
        err_body = ""
        try:
            err_body = e.read().decode("utf-8")
            data = json.loads(err_body)
            if isinstance(data, dict) and "error" in data:
                err = data["error"]
                code = err.get("code", "unknown")
                msg = err.get("message", "")
                req_id = err.get("requestId", "")
                err_data = err.get("data", {})
                logger.error(f"API Error [{code}] on {method} {url}: {msg} (req_id={req_id}, data={err_data})")
                raise RuntimeError(f"Toss API Error [{code}]: {msg} (requestId={req_id})")
        except RuntimeError:
            raise
        except Exception:
            pass

        logger.error(f"HTTP Error {e.code} on {method} {url}: {err_body}")
        raise RuntimeError(f"HTTP Error {e.code}: {err_body}")
