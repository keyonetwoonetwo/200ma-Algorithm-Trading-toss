import json
import logging
import time
import urllib.parse
import urllib.request
import urllib.error
from typing import Optional

logger = logging.getLogger(__name__)


class TossAuthManager:
    """Manages OAuth 2.0 access token for Toss Securities Open API.

    Endpoints: POST /oauth2/token
    Grant Type: client_credentials
    Payload: application/x-www-form-urlencoded
    """

    def __init__(self, base_url: str, client_id: str, client_secret: str, timeout_seconds: int = 30):
        self.base_url = base_url.rstrip("/")
        self.client_id = client_id
        self.client_secret = client_secret
        self.timeout_seconds = timeout_seconds

        self._access_token: Optional[str] = None
        self._expires_at: float = 0.0

    @property
    def has_valid_token(self) -> bool:
        # Buffer 60 seconds before expiration
        return bool(self._access_token and time.time() < (self._expires_at - 60))

    def get_access_token(self, force_refresh: bool = False) -> str:
        """Returns valid access token, requesting a new one if expired or forced."""
        if not force_refresh and self.has_valid_token:
            return self._access_token  # type: ignore

        return self.issue_token()

    def issue_token(self) -> str:
        """Issues a new access token using client credentials."""
        if not self.client_id or not self.client_secret:
            raise ValueError("TOSS_CLIENT_ID and TOSS_CLIENT_SECRET must be configured.")

        url = f"{self.base_url}/oauth2/token"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }
        encoded_data = urllib.parse.urlencode(data).encode("utf-8")

        masked_id = self.client_id[:4] + "***" if len(self.client_id) > 4 else "***"
        logger.info(f"Requesting new OAuth2 token for client_id={masked_id}")

        req = urllib.request.Request(url, data=encoded_data, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                status_code = resp.status
                body_bytes = resp.read()
                result = json.loads(body_bytes.decode("utf-8"))
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="replace")
            logger.error(f"OAuth2 token issuance failed: status={e.code}, body={err_body}")
            try:
                err_data = json.loads(err_body)
            except (json.JSONDecodeError, TypeError):
                raise RuntimeError(f"Toss OAuth2 HTTP Error {e.code}: {err_body}")
            if isinstance(err_data, dict):
                err_code = err_data.get("error", "unknown_error")
                err_desc = err_data.get("error_description", "")
                raise RuntimeError(f"Toss OAuth2 Error [{err_code}]: {err_desc}")
            raise RuntimeError(f"Toss OAuth2 HTTP Error {e.code}: {err_body}")
        except Exception as e:
            logger.error(f"Network error while requesting OAuth2 token: {e}")
            raise

        token = result.get("access_token")
        expires_in = result.get("expires_in", 86400)

        if not token:
            raise RuntimeError("OAuth2 response missing access_token.")

        self._access_token = token
        self._expires_at = time.time() + float(expires_in)
        logger.info(f"OAuth2 token issued successfully. Expires in {expires_in}s.")
        return token
