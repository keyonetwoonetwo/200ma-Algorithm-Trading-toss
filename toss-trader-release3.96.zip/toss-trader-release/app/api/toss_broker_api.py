import logging
import time
from typing import Any, Callable, Dict, List, Optional
from app.api.base_broker import BaseBrokerAPI
from app.api.client import TossAPIClient

logger = logging.getLogger(__name__)


class TossBrokerAPI(BaseBrokerAPI):
    """Implementation of BaseBrokerAPI using Toss Securities Open API specification."""

    def __init__(
        self,
        client: TossAPIClient,
        account_lookup_sleep_fn: Optional[Callable[[float], None]] = None,
    ):
        self.client = client
        # Deliberately scoped to the read-only account discovery endpoint.
        # No order or mutation method uses this sleep/retry policy.
        self._account_lookup_sleep_fn = account_lookup_sleep_fn or time.sleep

    @staticmethod
    def _is_account_lookup_rate_limit(error: RuntimeError) -> bool:
        message = str(error)
        return "rate-limit-exceeded" in message or "HTTP Error 429" in message

    def get_us_market_calendar(self, date_str: Optional[str] = None) -> Dict[str, Any]:
        """GET /api/v1/market-calendar/US

        Returns US market calendar for today, previousBusinessDay, and nextBusinessDay.
        """
        params = {}
        if date_str:
            params["date"] = date_str
        return self.client.request("GET", "/api/v1/market-calendar/US", params=params, require_account=False)

    def get_candles(
        self,
        symbol: str,
        interval: str = "1d",
        count: int = 200,
        before: Optional[str] = None,
        adjusted: bool = True,
    ) -> Dict[str, Any]:
        """GET /api/v1/candles

        Returns candles array and nextBefore pagination cursor.
        """
        params = {
            "symbol": symbol,
            "interval": interval,
            "count": min(count, 200),
            "adjusted": "true" if adjusted else "false",
        }
        if before:
            params["before"] = before

        return self.client.request("GET", "/api/v1/candles", params=params, require_account=False)

    def get_prices(self, symbols: List[str]) -> List[Dict[str, Any]]:
        """GET /api/v1/prices

        Returns current price list for given comma-separated symbols.
        """
        if not symbols:
            return []
        params = {"symbols": ",".join(symbols)}
        return self.client.request("GET", "/api/v1/prices", params=params, require_account=False)

    def get_accounts(self) -> List[Dict[str, Any]]:
        """GET /api/v1/accounts

        Returns list of active accounts (e.g. BROKERAGE).
        """
        # Fresh setup resolves account identity twice (initialize, then
        # validate). Toss can rate-limit those consecutive read-only calls.
        # Retry once only for an explicit 429/rate-limit response; every other
        # error remains fail-closed and no mutation endpoint is retried.
        try:
            return self.client.request("GET", "/api/v1/accounts", require_account=False)
        except RuntimeError as error:
            if not self._is_account_lookup_rate_limit(error):
                raise
            logger.warning("Account lookup rate-limited; retrying once after 1 second.")
            self._account_lookup_sleep_fn(1.0)
            return self.client.request("GET", "/api/v1/accounts", require_account=False)

    def get_holdings(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """GET /api/v1/holdings

        Returns holdings overview and list of held assets (with averagePurchasePrice, quantity).
        Requires X-Tossinvest-Account header.
        """
        params = {}
        if symbol:
            params["symbol"] = symbol
        return self.client.request("GET", "/api/v1/holdings", params=params, require_account=True)

    def get_buying_power(self, currency: str = "USD") -> Dict[str, Any]:
        """GET /api/v1/buying-power

        Returns cashBuyingPower in specified currency.
        Requires X-Tossinvest-Account header.
        """
        params = {"currency": currency}
        return self.client.request("GET", "/api/v1/buying-power", params=params, require_account=True)

    def get_sellable_quantity(self, symbol: str) -> Dict[str, Any]:
        """GET /api/v1/sellable-quantity

        Returns sellable quantity for symbol.
        Requires X-Tossinvest-Account header.
        """
        params = {"symbol": symbol}
        return self.client.request("GET", "/api/v1/sellable-quantity", params=params, require_account=True)

    def create_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: Optional[int] = None,
        price: Optional[str] = None,
        time_in_force: Optional[str] = "DAY",
        client_order_id: Optional[str] = None,
        order_amount: Optional[str] = None,
    ) -> Dict[str, Any]:
        """POST /api/v1/orders

        Creates a BUY or SELL order.
        Requires X-Tossinvest-Account header.
        """
        payload: Dict[str, Any] = {
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
        }

        if client_order_id:
            payload["clientOrderId"] = client_order_id

        if quantity is not None:
            payload["quantity"] = str(quantity)
            if order_type == "LIMIT":
                if not price:
                    raise ValueError("Price is required for LIMIT order.")
                payload["price"] = str(price)
            if time_in_force is not None:
                payload["timeInForce"] = time_in_force
        elif order_amount is not None:
            payload["orderAmount"] = str(order_amount)
        else:
            raise ValueError("Either quantity or order_amount must be provided.")

        return self.client.request(
            "POST", "/api/v1/orders", json_data=payload,
            require_account=True, retry_on_401=False,
        )

    def get_orders(self, status: str = "OPEN", symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """GET /api/v1/orders

        Returns orders list matching status (e.g. OPEN).
        Requires X-Tossinvest-Account header.
        """
        params: Dict[str, Any] = {"status": status}
        if symbol:
            params["symbol"] = symbol
        resp = self.client.request("GET", "/api/v1/orders", params=params, require_account=True)
        if isinstance(resp, dict) and "orders" in resp:
            return resp["orders"]
        return resp if isinstance(resp, list) else []

    def get_order_detail(self, order_id: str) -> Dict[str, Any]:
        """GET /api/v1/orders/{orderId}

        Returns full details of an order.
        Requires X-Tossinvest-Account header.
        """
        return self.client.request("GET", f"/api/v1/orders/{order_id}", require_account=True)

    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """POST /api/v1/orders/{orderId}/cancel

        Cancels an open order.
        Requires X-Tossinvest-Account header.
        """
        return self.client.request(
            "POST", f"/api/v1/orders/{order_id}/cancel", json_data={},
            require_account=True, retry_on_401=False,
        )
