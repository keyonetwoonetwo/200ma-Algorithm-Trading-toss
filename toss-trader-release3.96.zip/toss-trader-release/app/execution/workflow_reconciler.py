"""Operator and pre-backup reconciliation against persisted Toss order IDs."""
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, List, Optional

from app.storage.order_ledger_store import OrderLedgerStore
from app.models.order_identity import workflow_client_order_id, workflow_step_client_ids


CANCELED_STATUSES = {"CANCELED", "CANCELLED"}
OPEN_CANCELABLE_STATUSES = {"PENDING"}
KNOWN_TERMINAL_NO_FILL_STATUSES = CANCELED_STATUSES | {"REJECTED"}
KNOWN_UNSAFE_STATUSES = {
    "PENDING_CANCEL", "PENDING_REPLACE", "REPLACED", "SUBMITTED",
    "CANCEL_REJECTED", "REPLACE_REJECTED",
}


@dataclass
class ReconciliationResult:
    outcome: str
    workflow_id: Optional[str] = None
    orders: List[Dict[str, Any]] = field(default_factory=list)
    message: str = ""
    abort_record: Optional[Dict[str, Any]] = None


class WorkflowReconciler:
    """Synchronize ledger orders without guessing when broker truth is incomplete."""

    def __init__(self, ledger_store: OrderLedgerStore, broker_api: Any = None):
        self.ledger_store = ledger_store
        self.broker_api = broker_api

    @staticmethod
    def _parse_detail(order: Dict[str, Any], detail: Dict[str, Any]) -> Dict[str, Any]:
        raw_status = str(detail.get("status") or "UNKNOWN").upper()
        status = "CANCELED" if raw_status in CANCELED_STATUSES else raw_status
        execution = detail.get("execution")
        if not isinstance(execution, dict) or execution.get("filledQuantity") is None:
            raise RuntimeError("broker order detail lacks execution.filledQuantity")
        try:
            requested = Decimal(str(order.get("requested_quantity")))
            filled = Decimal(str(execution.get("filledQuantity") or "0"))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise RuntimeError("broker order quantities are malformed") from exc
        average = execution.get("averageFilledPrice")
        amount = execution.get("filledAmount")
        if requested <= 0 or filled < 0 or filled > requested:
            raise RuntimeError(f"broker order quantities are inconsistent: requested={requested}, filled={filled}")
        if filled > 0 and (status != "FILLED" or filled != requested):
            ledger_status = "PARTIAL_FILLED_BLOCKED"
        elif status == "FILLED":
            try:
                valid_execution = filled == requested and Decimal(str(average)) > 0 and Decimal(str(amount)) > 0
            except (InvalidOperation, TypeError, ValueError):
                valid_execution = False
            ledger_status = "FILLED" if valid_execution else "FILLED_INTEGRITY_ERROR"
        elif status in KNOWN_TERMINAL_NO_FILL_STATUSES | OPEN_CANCELABLE_STATUSES | KNOWN_UNSAFE_STATUSES:
            ledger_status = status
        else:
            ledger_status = "UNKNOWN"
        return {
            "status": ledger_status,
            "broker_status": status,
            "canceled": status == "CANCELED",
            "requested_quantity": str(requested),
            "filled_quantity": str(filled),
            "average_filled_price": str(average) if average is not None else None,
            "filled_amount": str(amount) if amount is not None else None,
        }

    def _workflow_orders(self, ledger: Dict[str, Any], workflow_id: str) -> List[Dict[str, Any]]:
        return [order for order in ledger.get("orders", []) if order.get("workflow_id") == workflow_id]

    def _refresh_order(self, order: Dict[str, Any]) -> Dict[str, Any]:
        order_id = order.get("broker_order_id")
        if not order_id:
            raise RuntimeError(f"persisted broker_order_id is missing for {order.get('client_order_id')}")
        if self.broker_api is None:
            raise RuntimeError("broker API is unavailable")
        detail = self.broker_api.get_order_detail(str(order_id))
        parsed = self._parse_detail(order, detail)
        self.ledger_store.update_order(
            str(order.get("client_order_id", "")),
            status=parsed["status"], broker_order_id=str(order_id),
            filled_quantity=parsed["filled_quantity"],
            average_filled_price=parsed["average_filled_price"],
            filled_amount=parsed["filled_amount"],
        )
        return {**parsed, "broker_order_id": str(order_id), "client_order_id": order.get("client_order_id"), "symbol": order.get("symbol")}

    def pre_backup_cleanup(self) -> ReconciliationResult:
        ledger = self.ledger_store.load_strict()
        workflow = ledger.get("active_workflow")
        if not workflow:
            return ReconciliationResult("CLEAN", message="No active workflow")
        workflow_id = str(workflow["workflow_id"])
        orders = self._workflow_orders(ledger, workflow_id)
        if workflow.get("execution_mode") == "DRY_RUN":
            record = self.ledger_store.abort_workflow(
                "ABORTED_DRY_RUN", "DRY_RUN workflow has no broker-side orders or fills",
                broker_final_order_status="SIMULATED_ONLY", filled_quantity="0", cancel_result="NOT_REQUIRED",
            )
            return ReconciliationResult("DRY_RUN_CLEARED", workflow_id, message=record["abort_reason"], abort_record=record)
        if not orders:
            record = self.ledger_store.abort_workflow(
                "ABORTED_PRE_BACKUP", "Pre-order workflow had no persisted order intents or broker order IDs",
                broker_final_order_status="NOT_SUBMITTED", filled_quantity="0", cancel_result="NOT_REQUIRED",
            )
            return ReconciliationResult("ABORTED", workflow_id, abort_record=record, message=record["abort_reason"])

        refreshed: List[Dict[str, Any]] = []
        cancel_results: List[str] = []
        for order in orders:
            try:
                current = self._refresh_order(order)
            except Exception as exc:
                return ReconciliationResult("BLOCKED", workflow_id, refreshed, f"Broker status unavailable: {exc}")
            refreshed.append(current)
            if Decimal(current["filled_quantity"]) > 0 or current["status"] in {"UNKNOWN", "FILLED_INTEGRITY_ERROR", "PARTIAL_FILLED_BLOCKED"}:
                return ReconciliationResult("BLOCKED", workflow_id, refreshed, "Actual fill or unknown broker result forbids automatic abort")
            if current["status"] in KNOWN_TERMINAL_NO_FILL_STATUSES:
                cancel_results.append("ALREADY_TERMINAL")
                continue
            if current["status"] not in OPEN_CANCELABLE_STATUSES:
                return ReconciliationResult("BLOCKED", workflow_id, refreshed, f"Order is not safely cancelable: {current['status']}")
            try:
                self.broker_api.cancel_order(current["broker_order_id"])
                confirmed = self._refresh_order(order)
            except Exception as exc:
                return ReconciliationResult("BLOCKED", workflow_id, refreshed, f"Cancel result is unconfirmed: {exc}")
            refreshed[-1] = confirmed
            if confirmed["broker_status"] != "CANCELED" or Decimal(confirmed["filled_quantity"]) != 0:
                return ReconciliationResult("BLOCKED", workflow_id, refreshed, "Cancel was not confirmed as CANCELED with zero fill")
            cancel_results.append("REQUESTED_AND_CONFIRMED")

        record = self.ledger_store.abort_workflow(
            "ABORTED_NO_FILL", "Pre-backup broker reconciliation confirmed no fills and terminal cancellation",
            broker_final_order_status=[item["broker_status"] for item in refreshed],
            filled_quantity="0", cancel_result=cancel_results, orders=refreshed,
        )
        return ReconciliationResult("ABORTED", workflow_id, refreshed, record["abort_reason"], record)

    def reconcile_active(self) -> ReconciliationResult:
        """Refresh every persisted order and close only an unambiguous outcome."""
        ledger = self.ledger_store.load_strict()
        workflow = ledger.get("active_workflow")
        if not workflow:
            return ReconciliationResult("CLEAN", message="No active workflow")
        workflow_id = str(workflow["workflow_id"])
        orders = self._workflow_orders(ledger, workflow_id)
        if workflow.get("execution_mode") == "DRY_RUN":
            record = self.ledger_store.abort_workflow(
                "ABORTED_DRY_RUN", "Operator cleared a simulated DRY_RUN workflow without advancing strategy state",
                broker_final_order_status="SIMULATED_ONLY", filled_quantity="0", cancel_result="NOT_REQUIRED",
            )
            return ReconciliationResult("DRY_RUN_CLEARED", workflow_id, message=record["abort_reason"], abort_record=record)
        if not orders:
            record = self.ledger_store.abort_workflow(
                "ABORTED_PRE_BACKUP", "Operator reconciliation confirmed a pre-order workflow with no persisted intents",
                broker_final_order_status="NOT_SUBMITTED", filled_quantity="0", cancel_result="NOT_REQUIRED",
            )
            return ReconciliationResult("ABORTED", workflow_id, message=record["abort_reason"], abort_record=record)
        refreshed = []
        try:
            for order in orders:
                refreshed.append(self._refresh_order(order))
        except Exception as exc:
            return ReconciliationResult("BLOCKED", workflow_id, refreshed, f"Broker query failed: {exc}")
        statuses = {item["status"] for item in refreshed}
        filled_total = sum((Decimal(item["filled_quantity"]) for item in refreshed), Decimal("0"))
        if statuses == {"FILLED"}:
            latest = self.ledger_store.load()["active_workflow"]
            step_client_ids = workflow_step_client_ids(latest)
            if len(step_client_ids) != len(set(step_client_ids)):
                return ReconciliationResult(
                    "BLOCKED", workflow_id, refreshed,
                    "Ambiguous legacy clientOrderId mapping prevents terminal reconciliation",
                )
            current_index = int(latest.get("next_index", 0))
            by_client_id = {
                str(order.get("client_order_id")): order
                for order in self._workflow_orders(self.ledger_store.load(), workflow_id)
            }
            while current_index < len(latest.get("steps", [])):
                leg = str(latest["steps"][current_index].get("leg", ""))
                client_id = workflow_client_order_id(latest, leg)
                if by_client_id.get(client_id, {}).get("status") != "FILLED":
                    break
                current_index += 1
            if current_index != int(latest.get("next_index", 0)):
                self.ledger_store.update_workflow(next_index=current_index)
                latest = self.ledger_store.load()["active_workflow"]
            if int(latest.get("next_index", 0)) < len(latest.get("steps", [])):
                return ReconciliationResult("BLOCKED", workflow_id, refreshed, "Filled orders confirmed, but unprocessed workflow steps remain")
            self.ledger_store.update_workflow(status="READY_TO_COMMIT", blocked_reason=None)
            return ReconciliationResult("READY_TO_COMMIT", workflow_id, refreshed, "All persisted orders are fully FILLED")
        if filled_total == 0 and statuses <= KNOWN_TERMINAL_NO_FILL_STATUSES:
            record = self.ledger_store.abort_workflow(
                "ABORTED_NO_FILL", "Operator reconciliation confirmed terminal orders with zero fills",
                broker_final_order_status=[item["broker_status"] for item in refreshed],
                filled_quantity="0", cancel_result="BROKER_CONFIRMED", orders=refreshed,
            )
            return ReconciliationResult("ABORTED", workflow_id, refreshed, record["abort_reason"], record)
        return ReconciliationResult(
            "BLOCKED", workflow_id, refreshed,
            "PARTIAL, UNKNOWN, non-terminal, or mixed broker outcome remains active and fail-closed",
        )
