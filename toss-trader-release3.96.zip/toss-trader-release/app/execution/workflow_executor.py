"""Stepwise, fail-closed execution of strategy events."""
from decimal import Decimal, ROUND_DOWN
from copy import deepcopy
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.execution.order_manager import OrderManager
from app.models.common import ExecutionMode, OrderSide, OrderStatus, TimeInForce
from app.models.orders import ExecutionRecord, OrderItem, OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState
from app.models.order_identity import (
    CURRENT_CLIENT_ORDER_ID_SCHEME,
    LEGACY_CLIENT_ORDER_ID_SCHEME,
    make_client_order_id,
    workflow_client_order_id,
    workflow_step_client_ids,
)
from app.portfolio.adapter import PortfolioAdapter
from app.storage.order_ledger_store import OrderLedgerStore
from app.execution.close_execution import CloseExecution
from app.execution.minute_execution import MinuteExecution
from config.defaults import DEFAULT_MAIN_SYMBOL, DEFAULT_OVERHEAT_SYMBOL, DEFAULT_SAFE_SYMBOL


BLOCKING_ORDER_STATUSES = {
    "UNKNOWN", "PENDING", "PENDING_CANCEL", "PENDING_REPLACE",
    "PARTIAL_FILLED", "PARTIAL_FILLED_BLOCKED", "REJECTED",
    "FILLED_INTEGRITY_ERROR",
}


class WorkflowBlocked(RuntimeError):
    pass


class WorkflowExecutor:
    """Builds dependent order legs only after preceding legs are FILLED."""

    def __init__(
        self,
        order_manager: OrderManager,
        ledger_store: OrderLedgerStore,
        portfolio_adapter: PortfolioAdapter,
        min_order_amount: Decimal = Decimal("10"),
        now_fn: Optional[Callable[[], datetime]] = None,
        sleep_fn: Optional[Callable[[float], None]] = None,
        poll_interval_seconds: float = 1.0,
    ):
        self.order_manager = order_manager
        self.ledger_store = ledger_store
        self.portfolio_adapter = portfolio_adapter
        self.min_order_amount = min_order_amount
        self.now_fn = now_fn or (lambda: datetime.now(timezone.utc))
        self.sleep_fn = sleep_fn or time.sleep
        self.poll_interval_seconds = poll_interval_seconds
        self.warnings: List[str] = []
        # Diagnostic-only copy for notification when fail-closed execution
        # raises before ``resume`` can return its records to the caller.
        self.last_execution_records: List[ExecutionRecord] = []
        self._virtual_buying_power: Optional[Decimal] = None

    def _now_utc(self) -> datetime:
        now = self.now_fn()
        if now.tzinfo is None:
            raise WorkflowBlocked("Execution clock must be timezone-aware")
        return now.astimezone(timezone.utc)

    @staticmethod
    def _policy_time(policy: Dict[str, Any], name: str) -> datetime:
        raw = policy.get(name)
        if not raw:
            raise WorkflowBlocked(f"MINUTE workflow policy missing {name}")
        try:
            value = datetime.fromisoformat(str(raw))
        except ValueError as exc:
            raise WorkflowBlocked(f"MINUTE workflow policy has invalid {name}") from exc
        if value.tzinfo is None:
            raise WorkflowBlocked(f"MINUTE workflow policy {name} must be timezone-aware")
        return value.astimezone(timezone.utc)

    def _assert_admission_open(self, signal_mode: str, policy: Dict[str, Any]) -> None:
        try:
            if signal_mode == "CLOSE":
                CloseExecution.validate_admission(policy, self._now_utc())
            elif signal_mode == "MINUTE":
                MinuteExecution.validate_admission(policy, self._now_utc())
            else:
                raise ValueError("unsupported execution core")
        except ValueError as exc:
            raise WorkflowBlocked(str(exc)) from exc

    def _assert_step_permitted(self, workflow: Dict[str, Any], step: Dict[str, Any], ledger: Dict[str, Any]) -> None:
        """Apply the workflow's persisted policy, never the current process mode."""
        mode = workflow.get("execution_core")
        policy = workflow.get("execution_policy")
        if mode not in {"CLOSE", "MINUTE"} or not isinstance(policy, dict):
            raise WorkflowBlocked("Active workflow has missing or unsupported signal execution policy")
        try:
            now = self._now_utc()
            allowed = (
                CloseExecution.step_permitted(workflow, step, ledger, now)
                if mode == "CLOSE"
                else MinuteExecution.step_permitted(workflow, step, ledger, now)
            )
        except ValueError as exc:
            raise WorkflowBlocked(str(exc)) from exc
        if allowed:
            return
        if mode == "CLOSE" and now >= CloseExecution._deadline(policy):
            self._reconcile_close_deadline(workflow, ledger)
            reconciled = self.ledger_store.load().get("active_workflow") or {}
            if reconciled.get("status") == "BLOCKED" and reconciled.get("blocked_reason"):
                raise WorkflowBlocked(str(reconciled["blocked_reason"]))
        self.ledger_store.update_workflow(
            status="BLOCKED",
            blocked_reason=(
                "CLOSE after-market deadline reached; no new order leg may be submitted"
                if mode == "CLOSE"
                else "MINUTE execution policy forbids every new order leg at/after regular close"
            ),
        )
        if mode == "CLOSE":
            raise WorkflowBlocked("CLOSE after-market deadline reached; no new order leg may be submitted")
        raise WorkflowBlocked("MINUTE execution policy forbids every new order leg at/after regular close")

    def _reconcile_close_deadline(self, workflow: Dict[str, Any], ledger: Dict[str, Any]) -> None:
        """Cancel and re-check every submitted, non-filled CLOSE order at deadline."""
        deadline = workflow["execution_policy"].get("after_market_end", "unknown")
        failures: List[str] = []
        for order in ledger.get("orders", []):
            if order.get("workflow_id") != workflow.get("workflow_id") or order.get("status") == "FILLED":
                continue
            order_id = order.get("broker_order_id")
            if not order_id:
                failures.append(
                    f"symbol={order.get('symbol')} orderId=NONE side={order.get('side')} "
                    f"status={order.get('status')} filledQty={order.get('filled_quantity', '0')} deadline={deadline}"
                )
                continue
            try:
                detail = self.order_manager.broker_api.get_order_detail(order_id)
                status = str(detail.get("status", "UNKNOWN"))
                execution = detail.get("execution", {})
                filled = str(execution.get("filledQuantity") or "0")
                if status != "FILLED" and self.order_manager.execution_mode == ExecutionMode.LIVE:
                    self.order_manager.broker_api.cancel_order(order_id)
                    detail = self.order_manager.broker_api.get_order_detail(order_id)
                    status = str(detail.get("status", "UNKNOWN"))
                    execution = detail.get("execution", {})
                    filled = str(execution.get("filledQuantity") or "0")
                is_partial = Decimal(filled) > 0 and status != "FILLED"
                ledger_status = "PARTIAL_FILLED_BLOCKED" if is_partial else status
                self.ledger_store.update_order(
                    order.get("client_order_id", ""), status=ledger_status,
                    filled_quantity=filled,
                    average_filled_price=(str(execution["averageFilledPrice"])
                                          if execution.get("averageFilledPrice") is not None else None),
                    filled_amount=(str(execution["filledAmount"])
                                   if execution.get("filledAmount") is not None else None),
                )
                if status != "FILLED":
                    failures.append(
                        f"symbol={order.get('symbol')} orderId={order_id} side={order.get('side')} "
                        f"status={status} filledQty={filled} deadline={deadline}"
                    )
            except Exception as exc:
                failures.append(
                    f"symbol={order.get('symbol')} orderId={order_id} side={order.get('side')} "
                    f"status=RECONCILIATION_ERROR filledQty={order.get('filled_quantity', '0')} "
                    f"deadline={deadline} error={exc}"
                )
        if failures:
            self.ledger_store.update_workflow(status="BLOCKED", blocked_reason="; ".join(failures))

    @staticmethod
    def workflow_id(signal_date: str, decision: StrategyDecision) -> str:
        code = decision.event.lower().replace("_", "-")
        if decision.strategy_name != "generic":
            raise WorkflowBlocked("Only the generic strategy may start a new workflow")
        return f"g-{signal_date.replace('-', '')}-{code}"[:36]

    @staticmethod
    def client_order_id(
        workflow_id: str, leg: str,
        scheme: str = CURRENT_CLIENT_ORDER_ID_SCHEME,
    ) -> str:
        return make_client_order_id(workflow_id, leg, scheme)

    def start(
        self,
        signal_date: str,
        decision: StrategyDecision,
        plan: OrderPlan,
        portfolio: PortfolioState,
        signal_mode: str = "CLOSE",
        execution_policy: Optional[Dict[str, Any]] = None,
        installation_identity: Optional[Dict[str, str]] = None,
    ) -> None:
        """Persist a workflow before any order is created."""
        if self.ledger_store.load().get("active_workflow"):
            raise WorkflowBlocked("Existing workflow must be reconciled first")
        policy = dict(execution_policy or {"kind": "CLOSE", "market_date": signal_date})
        self._assert_admission_open(signal_mode, policy)
        
        main_sym = (installation_identity or {}).get("main_symbol", DEFAULT_MAIN_SYMBOL)
        overheat_sym = (installation_identity or {}).get("overheat_symbol", DEFAULT_OVERHEAT_SYMBOL)
        safe_sym = (installation_identity or {}).get("safe_symbol", DEFAULT_SAFE_SYMBOL)

        steps = self._build_steps(decision, plan, main_sym, overheat_sym, safe_sym)
        workflow = {
            "workflow_id": self.workflow_id(signal_date, decision),
            "client_order_id_scheme": CURRENT_CLIENT_ORDER_ID_SCHEME,
            "signal_date": signal_date,
            "market_date": signal_date,
            "signal_mode": signal_mode,
            "execution_core": signal_mode,
            "execution_mode": self.order_manager.execution_mode.value,
            "strategy_name": decision.strategy_name,
            "installation_identity": dict(installation_identity or {}),
            "execution_policy": policy,
            "event": decision.event,
            "decision": decision.decision,
            "reason": decision.reason,
            "status": "RUNNING",
            "next_index": 0,
            "steps": steps,
            "pending_state_transition": decision.pending_state_transition,
            "main_average_purchase_price": str(portfolio.main_avg_price),
            "tqqq_average_purchase_price": str(portfolio.main_avg_price),
            "entry_split": dict(plan.entry_split) if plan.entry_split else None,
        }
        self.ledger_store.begin_workflow(workflow)

    def _build_steps(
        self,
        decision: StrategyDecision,
        plan: OrderPlan,
        main_symbol: str = DEFAULT_MAIN_SYMBOL,
        overheat_symbol: str = DEFAULT_OVERHEAT_SYMBOL,
        safe_symbol: str = DEFAULT_SAFE_SYMBOL,
    ) -> List[Dict[str, Any]]:
        sells = [order for order in plan.orders if order.side == OrderSide.SELL]
        split = plan.entry_split
        if split and split.get("kind") == "TRANCHE":
            steps = [self._static_step(order, f"SELL_{order.symbol}_ENTRY_{split['tranche_index']}", "SELL_ENTRY_SAFE") for order in sells]
            buys = [order for order in plan.orders if order.side == OrderSide.BUY]
            tranche_order_planned = split.get("tranche_order_planned")
            if tranche_order_planned is None:
                # Compatibility for plans constructed before 3.95. Persisted
                # workflows already contain steps and never pass this builder.
                tranche_order_planned = any(order.symbol == main_symbol for order in buys)
            if tranche_order_planned:
                if not any(order.symbol == main_symbol for order in buys):
                    raise WorkflowBlocked("Entry split metadata has no matching MAIN tranche order")
                steps.append({
                    "leg": f"BUY_{main_symbol}_ENTRY_{split['tranche_index']}",
                    "kind": "BUY_ENTRY_TRANCHE",
                    "symbol": main_symbol,
                    "budget": str(split["budget"]),
                    "required": False,
                })
            new_cash_budget = split.get("new_cash_budget")
            new_cash_symbol = split.get("new_cash_symbol")
            if new_cash_budget is not None:
                if new_cash_symbol not in {main_symbol, overheat_symbol}:
                    raise WorkflowBlocked("Entry split MAIN continuation has an invalid persisted New Cash destination")
                if not any(order.symbol == new_cash_symbol for order in buys):
                    raise WorkflowBlocked("Entry split MAIN continuation New Cash metadata has no matching order")
                required_same_symbol_orders = int(bool(tranche_order_planned and new_cash_symbol == main_symbol)) + 1
                if sum(order.symbol == new_cash_symbol for order in buys) < required_same_symbol_orders:
                    raise WorkflowBlocked("Entry split tranche and New Cash require independent order plans")
                new_cash_kind = (
                    "BUY_NEW_CASH_MAIN" if new_cash_symbol == main_symbol
                    else "BUY_NEW_CASH_OVERHEAT"
                )
                steps.append({
                    "leg": f"BUY_{new_cash_symbol}_NEW_CASH_ENTRY_{split['tranche_index']}",
                    "kind": new_cash_kind,
                    "symbol": new_cash_symbol,
                    "budget": str(new_cash_budget),
                    "required": False,
                })
            return steps
        if split and split.get("kind") == "TERMINATE_OVERHEAT":
            buys = [order for order in plan.orders if order.side == OrderSide.BUY]
            destination_action = split.get("destination_action")
            if destination_action is None and buys:
                # Compatibility for plans created before 3.70.
                destination_action = "SAFE" if buys[0].symbol == safe_symbol else "OVERHEAT"
            if destination_action not in {"SAFE", "OVERHEAT"}:
                raise WorkflowBlocked("Entry split termination has no valid persisted destination")
            destination_symbol = safe_symbol if destination_action == "SAFE" else overheat_symbol
            destination_kind = "BUY_ENTRY_SAFE" if destination_action == "SAFE" else "BUY_ENTRY_OVERHEAT"
            if buys and buys[0].symbol != destination_symbol:
                raise WorkflowBlocked("Entry split termination destination does not match its order plan")
            return ([{
                "leg": f"BUY_{destination_symbol}_ENTRY_TERMINATION",
                "kind": destination_kind,
                "symbol": destination_symbol,
                "budget": str(split["budget"]),
                "required": False,
            }] if buys else [])
        if decision.event == "RISK_OFF":
            return [self._static_step(order, f"SELL_{order.symbol}") for order in sells] + [
                {"leg": f"BUY_{safe_symbol}", "kind": "BUY_ALL_BUYING_POWER", "symbol": safe_symbol, "required": True},
            ]
        if decision.event == "RISK_ON_ENTRY":
            return [self._static_step(order, f"SELL_{order.symbol}") for order in sells] + [
                {"leg": f"BUY_{main_symbol}", "kind": "BUY_ALL_BUYING_POWER", "symbol": main_symbol, "required": True},
            ]
        if decision.event == "RISK_ON_OVERHEAT_ENTRY":
            return [self._static_step(order, f"SELL_{order.symbol}") for order in sells] + [
                {"leg": f"BUY_{overheat_symbol}", "kind": "BUY_ALL_BUYING_POWER", "symbol": overheat_symbol, "required": True},
            ]
        if decision.event == "DRAWDOWN_REDUCE":
            sell_leg = f"SELL_{sells[0].symbol}"
            return [self._static_step(sells[0], sell_leg)] + [
                {"leg": f"BUY_{overheat_symbol}", "kind": "BUY_SELL_PROCEEDS", "symbol": overheat_symbol, "source_leg": sell_leg, "required": True},
            ]
        if decision.event.startswith("MILESTONE_"):
            sell_leg = f"SELL_{sells[0].symbol}"
            return [self._static_step(sells[0], sell_leg)] + [
                {"leg": f"BUY_{overheat_symbol}", "kind": "BUY_MILESTONE_PRINCIPAL", "symbol": overheat_symbol, "source_leg": sell_leg, "required": True},
                {"leg": f"BUY_{safe_symbol}", "kind": "BUY_MILESTONE_PROFIT", "symbol": safe_symbol, "source_leg": sell_leg, "required": True},
            ]
        if decision.cash_target_symbol:
            first_main_transition = (
                decision.cash_target_symbol == main_symbol
                and decision.pending_state_transition.get("cycle_state") == "RISK_ON"
                and decision.pending_state_transition.get("cycle_high_close") is not None
            )
            return [{
                "leg": f"BUY_{decision.cash_target_symbol}", "kind": "BUY_ALL_BUYING_POWER",
                "symbol": decision.cash_target_symbol, "required": first_main_transition,
                "transition_required": first_main_transition,
            }]
        return []

    @staticmethod
    def _static_step(order: OrderItem, leg: str, kind: str = "SELL") -> Dict[str, Any]:
        return {"leg": leg, "kind": kind, "symbol": order.symbol, "quantity": order.quantity, "price": str(order.price) if order.price else None, "required": True}

    def resume(
        self,
        portfolio: PortfolioState,
        refresh_portfolio: Callable[[], PortfolioState],
    ) -> Tuple[List[ExecutionRecord], bool]:
        """Run as many known-safe legs as possible. Returns (records, completed)."""
        self.last_execution_records = []
        ledger = self.ledger_store.load()
        workflow = ledger.get("active_workflow")
        if not workflow:
            return [], False
        # Older unit-level workflow fixtures do not carry a mode. Production
        # startup rejects such persisted active workflows in ledger validation.
        persisted_mode = workflow.get("execution_mode", self.order_manager.execution_mode.value)
        if persisted_mode != self.order_manager.execution_mode.value:
            raise WorkflowBlocked(
                f"Workflow execution mode mismatch: persisted={persisted_mode}, current={self.order_manager.execution_mode.value}"
            )
        workflow = self._ensure_unambiguous_client_order_ids(workflow, ledger)
        ledger = self.ledger_store.load()
        if self.order_manager.execution_mode == ExecutionMode.DRY_RUN:
            self._virtual_buying_power = portfolio.available_cash_usd
            for order in ledger.get("orders", []):
                if order.get("workflow_id") == workflow.get("workflow_id") and order.get("status") == "FILLED":
                    amount = Decimal(str(order.get("filled_amount") or "0"))
                    self._virtual_buying_power += amount if order.get("side") == "SELL" else -amount
        else:
            self._virtual_buying_power = None
        if workflow.get("status") in {"BLOCKED", "UNKNOWN", "PARTIAL_FILLED_BLOCKED", "FILLED_INTEGRITY_ERROR"}:
            if workflow.get("execution_core") == "CLOSE":
                try:
                    deadline_reached = self._now_utc() >= CloseExecution._deadline(workflow["execution_policy"])
                except ValueError:
                    deadline_reached = False
                if deadline_reached:
                    self._reconcile_close_deadline(workflow, ledger)
                    workflow = self.ledger_store.load().get("active_workflow") or workflow
            raise WorkflowBlocked(f"Workflow is blocked: {workflow['status']}")
        records = self.last_execution_records
        current = portfolio
        for index in range(int(workflow.get("next_index", 0)), len(workflow["steps"])):
            step = workflow["steps"][index]
            deterministic_id = workflow_client_order_id(workflow, step["leg"])
            prior = next((x for x in ledger["orders"] if x.get("client_order_id") == deterministic_id), None)
            if prior:
                if prior.get("status") == "FILLED":
                    self.ledger_store.update_workflow(next_index=index + 1)
                    current = refresh_portfolio()
                    ledger = self.ledger_store.load()
                    workflow = ledger["active_workflow"]
                    continue
                if prior.get("status") in {"PENDING", "PENDING_CANCEL", "PENDING_REPLACE", "SUBMITTED"}:
                    item = self._item_from_intent(workflow, prior)
                    record = self._poll_pending_order(workflow, item, ledger, prior.get("broker_order_id"))
                    records.append(record)
                    if record.status == OrderStatus.FILLED:
                        self.ledger_store.update_workflow(next_index=index + 1)
                        current = self._apply_virtual_fill(current, item, record) if self._virtual_buying_power is not None else refresh_portfolio()
                        ledger = self.ledger_store.load()
                        workflow = ledger["active_workflow"]
                        continue
                    self.ledger_store.update_workflow(status="BLOCKED", blocked_reason=record.reason)
                    raise WorkflowBlocked(f"Existing order is not FILLED: {self._ledger_status(item.client_order_id)}")
                if workflow.get("execution_core") == "CLOSE":
                    try:
                        deadline_reached = not CloseExecution.step_permitted(
                            workflow, step, ledger, self._now_utc(),
                        )
                    except ValueError as exc:
                        raise WorkflowBlocked(str(exc)) from exc
                    if deadline_reached:
                        self._reconcile_close_deadline(workflow, ledger)
                        reconciled = self.ledger_store.load().get("active_workflow") or {}
                        if reconciled.get("status") == "BLOCKED" and reconciled.get("blocked_reason"):
                            raise WorkflowBlocked(str(reconciled["blocked_reason"]))
                        ledger = self.ledger_store.load()
                        prior = next((x for x in ledger["orders"] if x.get("client_order_id") == deterministic_id), None)
                        if prior and prior.get("status") == "FILLED":
                            self.ledger_store.update_workflow(next_index=index + 1)
                            current = refresh_portfolio()
                            ledger = self.ledger_store.load()
                            workflow = ledger["active_workflow"]
                            continue
                self.ledger_store.update_workflow(status="BLOCKED", blocked_reason=f"Existing {prior.get('status')} order")
                raise WorkflowBlocked(f"Existing order is not safely resumable: {prior.get('status')}")
            # Existing FILLED intents above are recovery bookkeeping, not a
            # new submission. Apply time policy only before a new broker leg.
            self._assert_step_permitted(workflow, step, ledger)
            item = self._prepare_step(workflow, step, current, ledger)
            if item is None:
                self.ledger_store.update_workflow(next_index=index + 1)
                continue
            self._record_intent(workflow, item, step["leg"])
            record = self.order_manager.submit_ledger_order(item, workflow["decision"], self.ledger_store)
            records.append(record)
            if record.status != OrderStatus.FILLED:
                record = self._poll_pending_order(workflow, item, ledger, self._broker_order_id(item.client_order_id))
                records[-1] = record
            if record.status != OrderStatus.FILLED:
                status = self.ledger_store.load()["orders"][-1].get("status", "UNKNOWN")
                block_status = "PARTIAL_FILLED_BLOCKED" if status == "PARTIAL_FILLED_BLOCKED" else "BLOCKED"
                self.ledger_store.update_workflow(status=block_status, blocked_reason=record.reason)
                raise WorkflowBlocked(f"Order {step['leg']} is not FILLED: {status}")
            self.ledger_store.update_workflow(next_index=index + 1)
            # This refresh is mandatory after every fill; it is the source of
            # truth for the next leg's sellable quantity/buying power.
            current = self._apply_virtual_fill(current, item, record) if self._virtual_buying_power is not None else refresh_portfolio()
            ledger = self.ledger_store.load()
            workflow = ledger["active_workflow"]
        self.ledger_store.update_workflow(status="READY_TO_COMMIT")
        return records, True

    def _broker_order_id(self, client_order_id: Optional[str]) -> Optional[str]:
        if not client_order_id:
            return None
        for order in self.ledger_store.load().get("orders", []):
            if order.get("client_order_id") == client_order_id:
                return order.get("broker_order_id")
        return None

    def _item_from_intent(self, workflow: Dict[str, Any], order: Dict[str, Any]) -> OrderItem:
        price = order.get("price")
        return OrderItem(
            symbol=str(order["symbol"]), side=OrderSide(str(order["side"])),
            quantity=int(order["requested_quantity"]), price=Decimal(str(price)) if price is not None else None,
            reason=str(workflow.get("reason", "")), time_in_force=self._time_in_force_for(workflow),
            client_order_id=str(order["client_order_id"]),
        )

    def _execution_deadline(self, workflow: Dict[str, Any]) -> datetime:
        policy = workflow["execution_policy"]
        return CloseExecution._deadline(policy) if workflow.get("execution_core") == "CLOSE" else MinuteExecution._time(policy, "new_leg_deadline")

    def _poll_pending_order(
        self, workflow: Dict[str, Any], item: OrderItem, ledger: Dict[str, Any], order_id: Optional[str],
    ) -> ExecutionRecord:
        if not order_id:
            raise WorkflowBlocked("Submitted order has no persisted broker orderId")
        while self._now_utc() < self._execution_deadline(workflow):
            record = self.order_manager.refresh_ledger_order(item, workflow["decision"], self.ledger_store, order_id)
            status = self._ledger_status(item.client_order_id)
            if record.status == OrderStatus.FILLED or status not in {"PENDING", "PENDING_CANCEL", "PENDING_REPLACE", "SUBMITTED"}:
                return record
            remaining = (self._execution_deadline(workflow) - self._now_utc()).total_seconds()
            if remaining <= 0:
                break
            self.sleep_fn(min(self.poll_interval_seconds, remaining))
        return self._reconcile_pending_at_deadline(workflow, item, order_id)

    def _ledger_status(self, client_order_id: Optional[str]) -> str:
        for order in self.ledger_store.load().get("orders", []):
            if order.get("client_order_id") == client_order_id:
                return str(order.get("status", "UNKNOWN"))
        return "UNKNOWN"

    def _reconcile_pending_at_deadline(self, workflow: Dict[str, Any], item: OrderItem, order_id: str) -> ExecutionRecord:
        record = self.order_manager.refresh_ledger_order(item, workflow["decision"], self.ledger_store, order_id)
        if record.status == OrderStatus.FILLED:
            return record
        if self.order_manager.execution_mode == ExecutionMode.LIVE:
            try:
                self.order_manager.broker_api.cancel_order(order_id)
            except Exception as exc:
                self.ledger_store.update_order(item.client_order_id or "", status="UNKNOWN", error=f"deadline cancel failed: {exc}")
                return ExecutionRecord(order_id, item.symbol, item.side, item.quantity, OrderStatus.PENDING, client_order_id=item.client_order_id, reason="Deadline cancel failed; trading blocked", strategy=workflow["decision"])
            record = self.order_manager.refresh_ledger_order(item, workflow["decision"], self.ledger_store, order_id)
            if record.status == OrderStatus.FILLED:
                return record
        return record

    def _apply_virtual_fill(self, portfolio: PortfolioState, item: OrderItem, record: ExecutionRecord) -> PortfolioState:
        """Keep DRY_RUN legs internally consistent without mutating broker state."""
        result = deepcopy(portfolio)
        amount = record.filled_amount or (Decimal(item.quantity) * (record.average_filled_price or item.price or Decimal("0")))
        if item.side == OrderSide.SELL:
            self._virtual_buying_power = (self._virtual_buying_power or Decimal("0")) + amount
        else:
            self._virtual_buying_power = max(Decimal("0"), (self._virtual_buying_power or Decimal("0")) - amount)
        result.available_cash_usd = self._virtual_buying_power or Decimal("0")
        position = result.positions.get(item.symbol)
        if position is not None:
            position.quantity += Decimal(item.quantity) if item.side == OrderSide.BUY else -Decimal(item.quantity)
        return result

    def _record_intent(self, workflow: Dict[str, Any], item: OrderItem, leg: str) -> None:
        client_id = workflow_client_order_id(workflow, leg)
        item.client_order_id = client_id
        existing = self.ledger_store.load()
        if any(order.get("client_order_id") == client_id for order in existing["orders"]):
            raise WorkflowBlocked(f"Order intent already exists: {client_id}")
        self.ledger_store.append_intent({
            "client_order_id": client_id,
            "workflow_id": workflow["workflow_id"],
            "leg": leg,
            "symbol": item.symbol,
            "side": item.side.value,
            "requested_quantity": item.quantity,
            "price": str(item.price) if item.price is not None else None,
            "status": "INTENT_RECORDED",
        })

    def _ensure_unambiguous_client_order_ids(
        self, workflow: Dict[str, Any], ledger: Dict[str, Any],
    ) -> Dict[str, Any]:
        ids = workflow_step_client_ids(workflow)
        if len(ids) == len(set(ids)):
            return workflow
        workflow_orders = [
            order for order in ledger.get("orders", [])
            if order.get("workflow_id") == workflow.get("workflow_id")
        ]
        scheme = workflow.get("client_order_id_scheme", LEGACY_CLIENT_ORDER_ID_SCHEME)
        if scheme == LEGACY_CLIENT_ORDER_ID_SCHEME:
            steps = list(workflow.get("steps", []))
            step_legs = [str(step.get("leg", "")) for step in steps]
            orders_by_leg = {}
            safely_migratable = True
            first_unfilled_seen = False
            for leg in step_legs:
                matching = [order for order in workflow_orders if str(order.get("leg", "")) == leg]
                if len(matching) > 1:
                    safely_migratable = False
                    break
                order = matching[0] if matching else None
                if order is None:
                    first_unfilled_seen = True
                    continue
                if first_unfilled_seen:
                    # Sequential execution cannot have a later intent while an
                    # earlier leg has no intent. Treat such data as ambiguous.
                    safely_migratable = False
                    break
                expected_legacy_id = make_client_order_id(
                    str(workflow["workflow_id"]), leg, LEGACY_CLIENT_ORDER_ID_SCHEME,
                )
                if order.get("client_order_id") != expected_legacy_id:
                    safely_migratable = False
                    break
                orders_by_leg[leg] = order
                if order.get("status") != "FILLED":
                    first_unfilled_seen = True
            if len(orders_by_leg) != len(workflow_orders):
                safely_migratable = False
            if safely_migratable:
                overrides = {
                    leg: str(order.get("client_order_id"))
                    for leg, order in orders_by_leg.items()
                }
                next_index = 0
                for leg in step_legs:
                    order = orders_by_leg.get(leg)
                    if not order or order.get("status") != "FILLED":
                        break
                    next_index += 1
                changes = {
                    "client_order_id_scheme": CURRENT_CLIENT_ORDER_ID_SCHEME,
                    "legacy_client_order_id_overrides": overrides,
                    "client_order_id_migrated_from": LEGACY_CLIENT_ORDER_ID_SCHEME,
                    "client_order_id_migrated_at": datetime.now(timezone.utc).isoformat(),
                    # Repair the old collision path that could advance past a
                    # leg for which no durable intent was ever recorded.
                    "next_index": next_index,
                }
                if workflow.get("status") == "READY_TO_COMMIT" and next_index < len(steps):
                    changes.update(status="RUNNING", blocked_reason=None)
                self.ledger_store.update_workflow(**changes)
            if safely_migratable:
                upgraded = self.ledger_store.load().get("active_workflow") or {}
                upgraded_ids = workflow_step_client_ids(upgraded)
                if len(upgraded_ids) == len(set(upgraded_ids)):
                    return upgraded
        reason = (
            "Ambiguous legacy clientOrderId mapping; persisted orders require "
            "operator reconciliation and no new order may be submitted"
        )
        self.ledger_store.update_workflow(status="BLOCKED", blocked_reason=reason)
        raise WorkflowBlocked(reason)

    def _warn_subthreshold_skip(self, workflow: Dict[str, Any], step: Dict[str, Any], amount: Decimal, price: Decimal) -> None:
        message = (
            f"{workflow.get('event', 'WORKFLOW')} {step['leg']} skipped: ${amount:.2f} cannot buy one "
            f"integer share at ${price:.2f}; funds remain as cash"
        )
        self.warnings.append(message)
        prior_warnings = list(workflow.get("warnings", []))
        if message not in prior_warnings:
            prior_warnings.append(message)
            workflow["warnings"] = prior_warnings
            # Production calls always have an active durable workflow.  The
            # guard also keeps this pure preparation helper usable in tests.
            if self.ledger_store.load().get("active_workflow"):
                self.ledger_store.update_workflow(warnings=prior_warnings)

    @staticmethod
    def _normalize_us_limit_price(price: Decimal) -> Decimal:
        """Apply Toss's documented US LIMIT precision by deterministic truncation."""
        quantum = Decimal("0.0001") if price < Decimal("1") else Decimal("0.01")
        normalized = price.quantize(quantum, rounding=ROUND_DOWN)
        if normalized <= 0:
            raise WorkflowBlocked("Normalized LIMIT price is non-positive")
        return normalized

    def _step_price(self, workflow: Dict[str, Any], symbol: str, portfolio: PortfolioState, side: OrderSide) -> Decimal:
        core = workflow.get("execution_core")
        if core not in {"MINUTE", "CLOSE"}:
            price = portfolio.prices.get(symbol)
            if price is None or price <= 0:
                raise WorkflowBlocked(f"No valid price for {symbol}")
            return price
        try:
            reference = self.portfolio_adapter.get_execution_price(symbol)
        except Exception as exc:
            raise WorkflowBlocked(f"No valid current execution quote for {symbol}: {exc}") from exc
        # Both cores use the target symbol's execution quote, never the
        # strategy signal candle. Broker price/session restrictions still apply.
        multiplier = Decimal("1.001") if side == OrderSide.BUY else Decimal("0.999")
        return self._normalize_us_limit_price(reference * multiplier)

    @staticmethod
    def _time_in_force_for(workflow: Dict[str, Any]) -> Optional[TimeInForce]:
        # Toss documents omitted quantity-order TIF as DAY.  CLOSE deliberately
        # sends no after-market-specific enum; MINUTE keeps its existing DAY.
        return None if workflow.get("execution_core") == "CLOSE" else TimeInForce.DAY

    def _prepare_step(self, workflow: Dict[str, Any], step: Dict[str, Any], portfolio: PortfolioState, ledger: Dict[str, Any]) -> Optional[OrderItem]:
        symbol = step["symbol"]

        if str(step["kind"]).startswith("SELL"):
            price = self._step_price(workflow, symbol, portfolio, OrderSide.SELL)
            requested = int(step.get("quantity", 0))
            if requested <= 0:
                return None
            sellable = self.portfolio_adapter.get_sellable_quantity(symbol)
            if sellable < Decimal(requested):
                raise WorkflowBlocked(f"Sellable quantity insufficient for {symbol}: {sellable} < {requested}")
            return OrderItem(
                symbol=symbol, side=OrderSide.SELL, quantity=requested, price=price,
                reason=workflow["reason"], time_in_force=self._time_in_force_for(workflow),
            )

        price = self._step_price(workflow, symbol, portfolio, OrderSide.BUY)
        buying_power = self._virtual_buying_power if self._virtual_buying_power is not None else self.portfolio_adapter.get_buying_power()
        budget = buying_power
        expected_obligation: Optional[Decimal] = None

        if step["kind"] in {"BUY_ENTRY_TRANCHE", "BUY_ENTRY_SAFE", "BUY_ENTRY_OVERHEAT", "BUY_NEW_CASH_MAIN", "BUY_NEW_CASH_OVERHEAT"}:
            try:
                budget = Decimal(str(step["budget"]))
            except Exception as exc:
                raise WorkflowBlocked(f"Invalid entry split budget for {step['leg']}") from exc
            if budget < 0:
                raise WorkflowBlocked(f"Negative entry split budget for {step['leg']}")

        if step["kind"] in {"BUY_SELL_PROCEEDS", "BUY_MILESTONE_PRINCIPAL", "BUY_MILESTONE_PROFIT"}:
            source = next((order for order in ledger["orders"] if order.get("leg") == step["source_leg"]), None)
            if not source or source.get("status") != "FILLED":
                raise WorkflowBlocked(f"Source sell not confirmed for {step['leg']}")
            proceeds = Decimal(str(source.get("filled_amount") or "0"))
            if proceeds <= 0:
                raise WorkflowBlocked("Filled sell is missing filledAmount")
            if step["kind"] in {"BUY_MILESTONE_PRINCIPAL", "BUY_MILESTONE_PROFIT"}:
                avg_buy_raw = workflow.get("main_average_purchase_price")
                if avg_buy_raw is None:
                    avg_buy_raw = workflow.get("tqqq_average_purchase_price")
                try:
                    avg_buy = Decimal(str(avg_buy_raw))
                except Exception as exc:
                    raise WorkflowBlocked(f"Invalid main average purchase price: {avg_buy_raw}") from exc
                if avg_buy <= 0:
                    raise WorkflowBlocked(f"Non-positive main average purchase price for milestone: {avg_buy}")

                avg_fill = Decimal(str(source.get("average_filled_price") or "0"))
                if avg_fill <= 0:
                    raise WorkflowBlocked("Filled sell is missing averageFilledPrice")

                profit_budget = proceeds * max(Decimal("0"), (avg_fill - avg_buy) / avg_fill)
                if step["kind"] == "BUY_MILESTONE_PRINCIPAL":
                    principal_budget = proceeds - profit_budget
                    expected_obligation = principal_budget
                    # Principal proceeds + any external New Cash
                    budget = max(Decimal("0"), buying_power - profit_budget)
                else:
                    expected_obligation = profit_budget
                    budget = profit_budget
            else:
                # BUY_SELL_PROCEEDS (Drawdown): uses all proceeds + external New Cash
                expected_obligation = proceeds
                budget = buying_power

        budget = min(budget, buying_power)
        quantity = int(budget / price)

        if budget < self.min_order_amount or quantity <= 0:
            transition_entries = {"RISK_ON_ENTRY", "RISK_ON_OVERHEAT_ENTRY", "RISK_OFF"}
            budgeted_entry_step = step["kind"] in {"BUY_ENTRY_TRANCHE", "BUY_ENTRY_SAFE", "BUY_ENTRY_OVERHEAT", "BUY_NEW_CASH_MAIN", "BUY_NEW_CASH_OVERHEAT"}
            if not budgeted_entry_step and (workflow.get("event") in transition_entries or step.get("transition_required")):
                raise WorkflowBlocked(
                    f"Required transition BUY {step['leg']} cannot acquire one share "
                    f"(budget=${budget:.2f}, price=${price:.2f}); state transition is forbidden"
                )
            if expected_obligation is not None:
                # A routed amount that can acquire a share is an economic
                # obligation; a zero quantity here means delayed/unavailable BP.
                if expected_obligation >= price and expected_obligation >= self.min_order_amount:
                    raise WorkflowBlocked(
                        f"Required dependent BUY {step['leg']} expected budget ${expected_obligation:.2f} "
                        f"(at least 1 share @ ${price:.2f}), but available buying power is ${buying_power:.2f} "
                        f"(budget=${budget:.2f}, quantity={quantity}); waiting for broker settlement/sync"
                    )
                self._warn_subthreshold_skip(workflow, step, expected_obligation, price)
                return None
            # Pure new-cash allocation is intentionally optional.  There is no
            # preceding sell obligation and its sub-one-share remainder stays cash.
            self._warn_subthreshold_skip(workflow, step, budget, price)
            return None
        return OrderItem(
            symbol=symbol, side=OrderSide.BUY, quantity=quantity, price=price,
            reason=workflow["reason"], time_in_force=self._time_in_force_for(workflow),
        )

    def commit_confirmed_state(self, state_store: Any, portfolio: PortfolioState) -> Dict[str, Any]:
        """Idempotently apply a workflow only after all legs are FILLED."""
        ledger = self.ledger_store.load()
        workflow = ledger.get("active_workflow")
        if not workflow or workflow.get("status") != "READY_TO_COMMIT":
            raise WorkflowBlocked("No workflow ready to commit")
        state = state_store.load_state_strict()
        if state.get("last_completed_workflow_id") != workflow["workflow_id"]:
            state.update(workflow.get("pending_state_transition", {}))
            split = workflow.get("entry_split")
            if isinstance(split, dict):
                step_kinds = {
                    str(step.get("leg")): str(step.get("kind"))
                    for step in workflow.get("steps", []) if isinstance(step, dict)
                }
                filled = [
                    order for order in ledger.get("orders", [])
                    if order.get("workflow_id") == workflow["workflow_id"] and order.get("status") == "FILLED"
                ]
                def filled_amount(kinds: set) -> Decimal:
                    return sum(
                        (Decimal(str(order.get("filled_amount") or "0")) for order in filled
                         if step_kinds.get(str(order.get("leg"))) in kinds),
                        Decimal("0"),
                    )
                reserved_before = Decimal(str(split.get("reserved_before", "0")))
                cash_before = Decimal(str(split.get("cash_reserved_before", "0")))
                if split.get("kind") == "TRANCHE":
                    buy_spend = filled_amount({"BUY_ENTRY_TRANCHE"})
                    safe_proceeds = filled_amount({"SELL_ENTRY_SAFE"})
                    reserved_after = max(Decimal("0"), reserved_before - buy_spend)
                    cash_after = max(Decimal("0"), cash_before + safe_proceeds - buy_spend)
                    if split.get("last"):
                        state["entry_reserved_cash"] = "0"
                        state["entry_reserved_cash_balance"] = "0"
                        state["entry_split_status"] = "COMPLETED"
                    else:
                        state["entry_reserved_cash"] = str(reserved_after)
                        state["entry_reserved_cash_balance"] = str(min(reserved_after, cash_after, portfolio.available_cash_usd))
                        state["entry_split_status"] = "ACTIVE"
                    if portfolio.main_quantity <= 0:
                        state["cycle_state"] = "WAIT"
                        state["cycle_high_close"] = None
                elif split.get("kind") == "TERMINATE_OVERHEAT":
                    # Both configured destinations share one terminal state;
                    # the persisted step kind records which asset received it.
                    destination_spend = filled_amount({"BUY_ENTRY_OVERHEAT", "BUY_ENTRY_SAFE"})
                    reserved_after = max(Decimal("0"), reserved_before - destination_spend)
                    cash_after = max(Decimal("0"), cash_before - destination_spend)
                    state["entry_reserved_cash"] = str(reserved_after)
                    state["entry_reserved_cash_balance"] = str(min(reserved_after, cash_after, portfolio.available_cash_usd))
                    state["entry_split_status"] = "TERMINATED_OVERHEAT"
                    state["entry_split_terminated_reason"] = "OVERHEAT"
            # This marker is committed atomically with strategy state before
            # the workflow is cleared.  A crash at any later point cannot
            # cause the same market date to start a second workflow.
            state["last_execution_date"] = workflow["signal_date"]
            state["last_completed_workflow_id"] = workflow["workflow_id"]
            state["last_account_snapshot"] = state_store.account_snapshot(portfolio)
            state_store.save_state(state)
        self.ledger_store.complete_workflow()
        return state
