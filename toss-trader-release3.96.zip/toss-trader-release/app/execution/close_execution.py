"""CLOSE workflow execution policy.

Market-data finalization belongs to CloseRunner; this class owns only the
durable execution policy for a workflow that was already admitted.
"""
from datetime import datetime, timezone
from typing import Any, Dict


class CloseExecution:
    core_name = "CLOSE"

    @staticmethod
    def _time(policy: Dict[str, Any], name: str) -> datetime:
        raw = policy.get(name)
        if not raw:
            raise ValueError(f"CLOSE workflow has no {name}")
        value = datetime.fromisoformat(str(raw))
        if value.tzinfo is None:
            raise ValueError("CLOSE workflow deadline must be timezone-aware")
        return value.astimezone(timezone.utc)

    @classmethod
    def _deadline(cls, policy: Dict[str, Any]) -> datetime:
        return cls._time(policy, "after_market_end")

    @classmethod
    def validate_admission(cls, policy: Dict[str, Any], now_utc: datetime) -> None:
        if policy.get("kind") != "CLOSE":
            raise ValueError("CLOSE workflow has invalid execution policy")
        if now_utc < cls._time(policy, "after_market_start"):
            raise ValueError("CLOSE after-market session has not started")
        if now_utc >= cls._deadline(policy):
            raise ValueError("CLOSE after-market deadline reached; no workflow was started")

    @classmethod
    def step_permitted(cls, workflow: Dict[str, Any], step: Dict[str, Any], ledger: Dict[str, Any], now_utc: datetime) -> bool:
        policy = workflow["execution_policy"]
        return cls._time(policy, "after_market_start") <= now_utc < cls._deadline(policy)
