from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict


@dataclass
class PositionItem:
    symbol: str
    name: str = ""
    quantity: Decimal = Decimal("0")
    average_purchase_price: Decimal = Decimal("0")
    last_price: Decimal = Decimal("0")
    market_value: Decimal = Decimal("0")
    currency: str = "USD"

    @property
    def return_rate(self) -> Decimal:
        """Calculates profit rate in percentage e.g. 50.0 for +50%."""
        if self.average_purchase_price <= Decimal("0"):
            return Decimal("0")
        return ((self.last_price / self.average_purchase_price) - Decimal("1")) * Decimal("100")


@dataclass
class PortfolioState:
    account_no: str = ""
    account_seq: int = 1
    main_quantity: Decimal = Decimal("0")
    main_avg_price: Decimal = Decimal("0")
    overheat_quantity: Decimal = Decimal("0")
    safe_quantity: Decimal = Decimal("0")
    available_cash_usd: Decimal = Decimal("0")
    positions: Dict[str, PositionItem] = field(default_factory=dict)
    prices: Dict[str, Decimal] = field(default_factory=dict)

    @property
    def total_eval_amount_usd(self) -> Decimal:
        total = self.available_cash_usd
        for sym, pos in self.positions.items():
            price = self.prices.get(sym, pos.last_price)
            total += pos.quantity * price
        return total
