"""Canonical model definitions live in this package's individual modules."""
