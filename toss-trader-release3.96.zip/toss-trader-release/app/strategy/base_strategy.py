from abc import ABC, abstractmethod
from typing import Any, Dict, Tuple
from app.models.market import IndicatorResult
from app.models.portfolio import PortfolioState
from app.models.orders import OrderPlan


class BaseStrategy(ABC):
    @abstractmethod
    def evaluate(
        self,
        indicator: IndicatorResult,
        portfolio: PortfolioState,
        state_data: Dict[str, Any],
    ) -> Tuple[OrderPlan, Dict[str, Any]]:
        """Evaluates market data and portfolio state to produce an OrderPlan and updated strategy state.

        Returns:
            Tuple[OrderPlan, updated_state_dict]
        """
        pass
