"""Generic strategy facade with separate signal and lifecycle assets."""
from dataclasses import replace
from decimal import Decimal
from typing import Any, Dict, Optional, Tuple

from config.config import GenericStrategyConfig, StrategyConfig, TradingConfig
from app.models.market import IndicatorResult
from app.models.orders import OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState
from app.strategy.strategy import StrategyEngine


class GenericStrategy:
    def __init__(
        self,
        profile: GenericStrategyConfig,
        lifecycle_config: Optional[StrategyConfig] = None,
        trading_config: Optional[TradingConfig] = None,
    ) -> None:
        self.profile = profile
        self.strategy_name = "generic"
        base = lifecycle_config or StrategyConfig()
        self.config = replace(
            base,
            main_symbol=profile.main_symbol,
            overheat_symbol=profile.overheat_symbol,
            safe_symbol=profile.safe_symbol,
            wait_days=profile.wait_days,
            entry_split=profile.entry_split,
            entry_split_overheat_action=profile.entry_split_overheat_action,
        )
        self.trading = trading_config or TradingConfig()
        self._core = StrategyEngine(self.config, self.trading)

    def _regime_indicator(self, indicator: IndicatorResult) -> IndicatorResult:
        if indicator.symbol != self.profile.signal_symbol:
            raise ValueError(f"GenericStrategy requires {self.profile.signal_symbol} indicator, got {indicator.symbol}")
        risk = Decimal(str(self.profile.risk_threshold))
        overheat = Decimal(str(self.profile.overheat_threshold))
        ma = indicator.ma200 * risk
        prev_ma = indicator.prev_ma200 * risk
        return IndicatorResult(
            symbol=indicator.symbol,
            current_close=indicator.current_close,
            ma200=ma,
            prev_close=indicator.prev_close,
            prev_ma200=prev_ma,
            is_above_ma200=indicator.current_close >= ma,
            is_prev_above_ma200=indicator.prev_close >= prev_ma,
            overheat_price=indicator.ma200 * overheat,
        )

    def evaluate(
        self, indicator: IndicatorResult, portfolio: PortfolioState,
        state_data: Dict[str, Any], lifecycle_price: Optional[Decimal] = None,
    ) -> Tuple[OrderPlan, Dict[str, Any]]:
        lifecycle = lifecycle_price if lifecycle_price is not None else indicator.current_close
        if lifecycle_price is None and self.profile.signal_symbol != self.profile.main_symbol:
            raise ValueError("GenericStrategy requires an independently finalized main lifecycle price")
        if lifecycle <= 0:
            raise ValueError("GenericStrategy requires a positive finalized main lifecycle price")
        plan, state = self._core.evaluate(self._regime_indicator(indicator), portfolio, state_data, lifecycle)
        plan.strategy_name = self.strategy_name
        return plan, state

    def evaluate_decision(
        self, indicator: IndicatorResult, portfolio: PortfolioState,
        state_data: Dict[str, Any], lifecycle_price: Optional[Decimal] = None,
    ) -> Tuple[StrategyDecision, OrderPlan]:
        lifecycle = lifecycle_price if lifecycle_price is not None else indicator.current_close
        if lifecycle_price is None and self.profile.signal_symbol != self.profile.main_symbol:
            raise ValueError("GenericStrategy requires an independently finalized main lifecycle price")
        regime_indicator = self._regime_indicator(indicator)
        decision, plan = self._core.evaluate_decision(regime_indicator, portfolio, state_data, lifecycle)
        plan.strategy_name = self.strategy_name
        decision.strategy_name = self.strategy_name
        decision.signal_symbol = indicator.symbol
        decision.signal_close = indicator.current_close
        decision.signal_ma200 = indicator.ma200
        decision.risk_on_price = regime_indicator.ma200
        decision.overheat_price = regime_indicator.overheat_price
        if decision.cash_target_symbol == self.profile.main_symbol and decision.decision.startswith("NEW_CASH_"):
            decision.display_decision = "NEW_CASH_MAIN"
        elif decision.cash_target_symbol == self.profile.overheat_symbol and decision.decision.startswith("NEW_CASH_"):
            decision.display_decision = "NEW_CASH_OVERHEAT"
        else:
            decision.display_decision = decision.decision
        return decision, plan
