from app.strategy.generic_strategy import GenericStrategy

__all__ = ["GenericStrategy"]
