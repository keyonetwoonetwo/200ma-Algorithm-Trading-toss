#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
PLATFORM="${INSTALL_PLATFORM:-$(test -f .install-platform && tr -d '\r\n' < .install-platform)}"
if [[ "$PLATFORM" == "termux" ]]; then
    command -v pkg >/dev/null || { echo "오류: Termux pkg 명령을 찾을 수 없습니다." >&2; exit 1; }
    echo "Termux 패키지와 Python 실행 환경을 준비합니다."
    pkg update -y
    pkg upgrade -y
    pkg install -y python python-pip cronie unzip
elif [[ "$PLATFORM" == "linux" ]]; then
    if [[ "$(id -u)" -eq 0 ]]; then
        PRIVILEGE=()
    else
        command -v sudo >/dev/null || { echo "오류: 시스템 패키지 설치에 sudo가 필요하지만 찾을 수 없습니다." >&2; exit 1; }
        PRIVILEGE=(sudo)
    fi
    if command -v apt-get >/dev/null; then
        echo "Linux Python 가상환경 패키지를 apt-get으로 준비합니다."
        "${PRIVILEGE[@]}" apt-get update
        "${PRIVILEGE[@]}" apt-get install -y python3 python3-pip python3-venv
    elif command -v dnf >/dev/null; then
        echo "Linux Python 가상환경 패키지를 dnf로 준비합니다."
        "${PRIVILEGE[@]}" dnf install -y python3 python3-pip
    else
        echo "오류: 지원되는 Linux 패키지 관리자(apt-get 또는 dnf)를 찾을 수 없습니다." >&2
        exit 1
    fi
fi
command -v python3 >/dev/null || { echo "오류: Python 3가 필요합니다." >&2; exit 1; }
python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("오류: Python 3.10 이상이 필요합니다.")
PY
if [[ -e "$ROOT/.venv" && ! -x "$ROOT/.venv/bin/python" ]]; then
    echo "이전 설치 실패로 남은 불완전한 .venv를 안전하게 재생성합니다."
    rm -rf -- "$ROOT/.venv"
fi
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python "$ROOT/scripts/configure.py"
echo "설정 파일을 만들었습니다. 초기화와 DRY_RUN 검증을 계속합니다."
