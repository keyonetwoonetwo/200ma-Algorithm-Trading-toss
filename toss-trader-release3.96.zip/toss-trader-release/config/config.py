import os
import re
from dataclasses import dataclass, field
from datetime import datetime, time as clock_time, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Dict, Optional, Tuple
from config.defaults import (
    DEFAULT_ENTRY_SPLIT_OVERHEAT_ACTION,
    DEFAULT_MAIN_SYMBOL,
    DEFAULT_MINUTE_ORDER_CUTOFF,
    DEFAULT_OVERHEAT_SYMBOL,
    DEFAULT_SAFE_SYMBOL,
    DEFAULT_SIGNAL_SYMBOL,
    DEFAULT_SIGNAL_TIME,
)


def normalize_toss_account_no(value: Optional[str]) -> Optional[str]:
    """Return Toss's canonical numeric account number or reject bad input."""
    if value is None or value == "":
        return None
    canonical = re.sub(r"[-\s]+", "", value)
    if not canonical or not canonical.isdigit():
        raise ValueError("TOSS_ACCOUNT_NO must contain digits only (hyphens and whitespace are allowed separators)")
    return canonical


def _load_env_file(filepath: str = ".env") -> None:
    """Lightweight .env parser using standard library."""
    p = Path(filepath)
    if not p.exists():
        return
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip("'\"")
                if k not in os.environ:
                    os.environ[k] = v
    except Exception:
        pass


_load_env_file()


DEFAULT_MILESTONE_LEVELS: Tuple[int, ...] = (50, 100, 200, 300, 400, 500, 600)
DEFAULT_MILESTONE_SELL_RATIOS: Tuple[Decimal, ...] = (
    Decimal("0.30"), Decimal("0.50"), Decimal("0.50"), Decimal("0.50"),
    Decimal("0.50"), Decimal("0.50"), Decimal("0.50"),
)


def _parse_milestone_levels(raw: str) -> Tuple[int, ...]:
    key = "MILESTONE_LEVELS"
    if not raw.strip():
        raise ValueError(f"{key} must not be empty (received {raw!r})")
    tokens = raw.split(",")
    if any(not token.strip() for token in tokens):
        raise ValueError(f"{key} contains an empty item or invalid comma structure: {raw!r}")
    levels = []
    for index, token in enumerate(tokens, start=1):
        value = token.strip()
        try:
            level = int(value)
        except ValueError as exc:
            raise ValueError(f"{key} item {index} must be an integer, got {value!r} in {raw!r}") from exc
        if level <= 0:
            raise ValueError(f"{key} item {index} must be > 0, got {value!r} in {raw!r}")
        levels.append(level)
    for previous, current in zip(levels, levels[1:]):
        if current == previous:
            raise ValueError(f"{key} must not contain duplicate levels; got {current} in {raw!r}")
        if current < previous:
            raise ValueError(f"{key} must be strictly increasing; got {raw!r}")
    return tuple(levels)


def _parse_milestone_sell_ratios(raw: str) -> Tuple[Decimal, ...]:
    key = "MILESTONE_SELL_RATIOS"
    if not raw.strip():
        raise ValueError(f"{key} must not be empty (received {raw!r})")
    tokens = raw.split(",")
    if any(not token.strip() for token in tokens):
        raise ValueError(f"{key} contains an empty item or invalid comma structure: {raw!r}")
    ratios = []
    for index, token in enumerate(tokens, start=1):
        value = token.strip()
        try:
            ratio = Decimal(value)
        except InvalidOperation as exc:
            raise ValueError(f"{key} item {index} must be numeric, got {value!r} in {raw!r}") from exc
        if not ratio.is_finite() or ratio <= 0 or ratio > 1:
            raise ValueError(f"{key} item {index} must satisfy 0 < ratio <= 1, got {value!r} in {raw!r}")
        ratios.append(ratio)
    return tuple(ratios)


def parse_milestones(levels_raw: str, ratios_raw: str) -> Tuple[Tuple[int, Decimal], ...]:
    levels = _parse_milestone_levels(levels_raw)
    ratios = _parse_milestone_sell_ratios(ratios_raw)
    if len(levels) != len(ratios):
        raise ValueError(
            "MILESTONE_LEVELS and MILESTONE_SELL_RATIOS must contain the same number of items "
            f"(got {len(levels)} from {levels_raw!r} and {len(ratios)} from {ratios_raw!r})"
        )
    return tuple(zip(levels, ratios))


@dataclass
class StrategyConfig:
    main_symbol: str = DEFAULT_MAIN_SYMBOL
    overheat_symbol: str = DEFAULT_OVERHEAT_SYMBOL
    safe_symbol: str = DEFAULT_SAFE_SYMBOL
    ma_period: int = 200
    drawdown_threshold: float = 0.75
    drawdown_sell_ratio: float = 0.50
    milestones: Tuple[Tuple[int, Decimal], ...] = field(
        default_factory=lambda: tuple(zip(DEFAULT_MILESTONE_LEVELS, DEFAULT_MILESTONE_SELL_RATIOS))
    )
    wait_days: int = 1
    entry_split: int = 1
    entry_split_overheat_action: str = DEFAULT_ENTRY_SPLIT_OVERHEAT_ACTION


@dataclass(frozen=True)
class GenericStrategyConfig:
    """Generic strategy profile with a deliberately small durable identity.

    ``signal_symbol`` is deliberately distinct from ``main_symbol``.  The
    former is only allowed to drive regime/rebound calculations; the latter
    owns the configured main-asset lifecycle and every executable main-asset order.
    Tuning values are runtime-selectable.  Decisions and destinations are
    persisted into a workflow before submission, so recovery never reinterprets
    an existing workflow from a changed ``.env``.
    """
    signal_symbol: str = DEFAULT_SIGNAL_SYMBOL
    main_symbol: str = DEFAULT_MAIN_SYMBOL
    overheat_symbol: str = DEFAULT_OVERHEAT_SYMBOL
    safe_symbol: str = DEFAULT_SAFE_SYMBOL
    risk_threshold: float = 1.0
    overheat_threshold: float = 1.05
    signal_time: str = DEFAULT_SIGNAL_TIME
    wait_days: int = 1
    entry_split: int = 1
    entry_split_overheat_action: str = DEFAULT_ENTRY_SPLIT_OVERHEAT_ACTION

    def installation_identity(
        self, signal_mode: str, account_no: Optional[str] = None, account_seq: Optional[int] = None,
    ) -> Dict[str, str]:
        identity = {
            "signal_symbol": self.signal_symbol,
            "main_symbol": self.main_symbol,
            "overheat_symbol": self.overheat_symbol,
            "safe_symbol": self.safe_symbol,
            "signal_time": self.signal_time,
            "signal_mode": signal_mode,
        }
        if account_no is not None and account_seq is not None:
            identity["account_no"] = str(account_no).strip()
            identity["account_seq"] = str(account_seq)
        return identity


@dataclass
class TradingConfig:
    min_order_amount_usd: float = 10.0
    candle_lookback_days: int = 280


@dataclass
class MinuteConfig:
    """All times are interpreted in America/New_York, never server local time."""
    polling_interval_seconds: float = 2.0
    order_cutoff: str = DEFAULT_MINUTE_ORDER_CUTOFF


@dataclass
class StorageConfig:
    state_file: str = "data/state.json"
    daily_history_file: str = "data/history/daily_history.csv"
    trade_history_file: str = "data/history/trade_history.csv"
    order_ledger_file: str = "data/order_ledger.json"
    process_lock_file: str = "data/trader.lock"


@dataclass
class AppConfig:
    execution_mode: str = "DRY_RUN"
    live_trading_enabled: bool = False
    signal_mode: str = "CLOSE"
    timeout_seconds: int = 30

    toss_client_id: str = ""
    toss_client_secret: str = ""
    toss_api_base_url: str = "https://openapi.tossinvest.com"
    toss_account_no: Optional[str] = None

    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    telegram_enabled: bool = False

    strategy_rules: StrategyConfig = field(default_factory=StrategyConfig)
    strategy: GenericStrategyConfig = field(default_factory=GenericStrategyConfig)
    trading: TradingConfig = field(default_factory=TradingConfig)
    minute: MinuteConfig = field(default_factory=MinuteConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)

    def resolved_strategy(self) -> GenericStrategyConfig:
        """Return the single configured generic strategy profile."""
        return self.strategy

    @staticmethod
    def _validate_minute_timing(signal_time: str, minute: MinuteConfig) -> None:
        """Validate the bounded regular-session MINUTE execution window."""
        values = {
            "signal_time": signal_time,
            "order_cutoff": minute.order_cutoff,
        }
        parsed: Dict[str, clock_time] = {}
        for name, value in values.items():
            if not isinstance(value, str) or not re.fullmatch(r"\d{2}:\d{2}:\d{2}", value):
                raise ValueError(f"Invalid MINUTE timing: {name} must be HH:MM:SS")
            try:
                parsed[name] = clock_time.fromisoformat(value)
            except ValueError as exc:
                raise ValueError(f"Invalid MINUTE timing: {name} must be HH:MM:SS") from exc

        signal = parsed["signal_time"]
        order_cutoff = parsed["order_cutoff"]
        regular_start = clock_time(9, 30)
        regular_close = clock_time(16, 0)
        polling_start = (datetime.combine(datetime(2000, 1, 1).date(), signal) + timedelta(minutes=1)).time()

        if signal.second != 0 or signal.microsecond != 0:
            raise ValueError("Invalid MINUTE timing: signal_time must be minute-aligned")
        if signal < regular_start:
            raise ValueError("Invalid MINUTE timing: signal_time must be at or after 09:30:00")
        if not polling_start < order_cutoff:
            raise ValueError("Invalid MINUTE timing: polling start must be before order_cutoff")
        if not order_cutoff < regular_close:
            raise ValueError("Invalid MINUTE timing: order_cutoff must be before 16:00:00")

    @classmethod
    def load(cls) -> "AppConfig":
        _load_env_file()
        strategy_defaults = StrategyConfig()
        trading_defaults = TradingConfig()
        minute_defaults = MinuteConfig()

        mode = os.getenv("EXECUTION_MODE", "DRY_RUN").upper()
        live_enabled_raw = os.getenv("LIVE_TRADING_ENABLED", "false").strip().lower()
        live_enabled = live_enabled_raw == "true"
        signal_mode = os.getenv("TRADING_SIGNAL_MODE", "CLOSE").upper()
        timeout = int(os.getenv("TIMEOUT_SECONDS", "30"))

        generic_values = {
            "signal_symbol": os.getenv("SIGNAL_SYMBOL"),
            "main_symbol": os.getenv("MAIN_SYMBOL"),
            "overheat_symbol": os.getenv("OVERHEAT_SYMBOL"),
            "safe_symbol": os.getenv("SAFE_SYMBOL"),
            "risk_threshold": os.getenv("RISK_THRESHOLD"),
            "overheat_threshold": os.getenv("OVERHEAT_THRESHOLD"),
            "wait_days": os.getenv("WAIT_DAYS", "1"),
            "entry_split": os.getenv("ENTRY_SPLIT", "1"),
            "entry_split_overheat_action": os.getenv(
                "ENTRY_SPLIT_OVERHEAT_ACTION", DEFAULT_ENTRY_SPLIT_OVERHEAT_ACTION,
            ),
            "signal_time": os.getenv("SIGNAL_TIME"),
        }
        required_generic_fields = [
            "signal_symbol", "main_symbol", "overheat_symbol", "safe_symbol",
            "risk_threshold", "overheat_threshold", "signal_time",
        ]
        missing = [name for name in required_generic_fields if generic_values[name] in (None, "")]
        if missing:
            raise ValueError(f"Incomplete generic strategy installation: missing {', '.join(missing)}")
        try:
            wait_days = int(str(generic_values["wait_days"]))
        except (TypeError, ValueError) as exc:
            raise ValueError("WAIT_DAYS must be a non-negative integer") from exc
        if wait_days < 0 or str(generic_values["wait_days"]).strip() != str(wait_days):
            raise ValueError("WAIT_DAYS must be a non-negative integer")
        try:
            entry_split = int(str(generic_values["entry_split"]))
        except (TypeError, ValueError) as exc:
            raise ValueError("ENTRY_SPLIT must be a positive integer") from exc
        if entry_split <= 0 or str(generic_values["entry_split"]).strip() != str(entry_split):
            raise ValueError("ENTRY_SPLIT must be a positive integer")
        entry_split_overheat_action = str(generic_values["entry_split_overheat_action"]).strip().upper()
        if entry_split_overheat_action not in {"SAFE", "OVERHEAT", "MAIN"}:
            raise ValueError("ENTRY_SPLIT_OVERHEAT_ACTION must be SAFE, OVERHEAT, or MAIN")
        generic_cfg = GenericStrategyConfig(
            signal_symbol=str(generic_values["signal_symbol"]).upper(),
            main_symbol=str(generic_values["main_symbol"]).upper(),
            overheat_symbol=str(generic_values["overheat_symbol"]).upper(),
            safe_symbol=str(generic_values["safe_symbol"]).upper(),
            risk_threshold=float(generic_values["risk_threshold"]),
            overheat_threshold=float(generic_values["overheat_threshold"]),
            wait_days=wait_days,
            entry_split=entry_split,
            entry_split_overheat_action=entry_split_overheat_action,
            signal_time=str(generic_values["signal_time"] or ""),
        )
        default_levels = ",".join(str(value) for value in DEFAULT_MILESTONE_LEVELS)
        default_ratios = ",".join(str(value) for value in DEFAULT_MILESTONE_SELL_RATIOS)
        milestones = parse_milestones(
            os.getenv("MILESTONE_LEVELS", default_levels),
            os.getenv("MILESTONE_SELL_RATIOS", default_ratios),
        )
        strategy_rules = StrategyConfig(
            main_symbol=generic_cfg.main_symbol,
            overheat_symbol=generic_cfg.overheat_symbol,
            safe_symbol=generic_cfg.safe_symbol,
            ma_period=int(os.getenv("MA_PERIOD", str(strategy_defaults.ma_period))),
            drawdown_threshold=float(os.getenv("DRAWDOWN_THRESHOLD", str(strategy_defaults.drawdown_threshold))),
            drawdown_sell_ratio=float(os.getenv("DRAWDOWN_SELL_RATIO", str(strategy_defaults.drawdown_sell_ratio))),
            milestones=milestones,
            entry_split=generic_cfg.entry_split,
            entry_split_overheat_action=generic_cfg.entry_split_overheat_action,
        )
        trade_cfg = TradingConfig(
            min_order_amount_usd=float(os.getenv("MIN_ORDER_AMOUNT_USD", str(trading_defaults.min_order_amount_usd))),
            candle_lookback_days=int(os.getenv("CANDLE_LOOKBACK_DAYS", str(trading_defaults.candle_lookback_days))),
        )
        minute_cfg = MinuteConfig(
            polling_interval_seconds=float(os.getenv("MINUTE_POLLING_INTERVAL_SECONDS", str(minute_defaults.polling_interval_seconds))),
            order_cutoff=os.getenv("MINUTE_ORDER_CUTOFF", minute_defaults.order_cutoff),
        )
        if signal_mode == "MINUTE":
            cls._validate_minute_timing(generic_cfg.signal_time, minute_cfg)

        return cls(
            execution_mode=mode,
            live_trading_enabled=live_enabled,
            signal_mode=signal_mode,
            timeout_seconds=timeout,
            toss_client_id=os.getenv("TOSS_CLIENT_ID", ""),
            toss_client_secret=os.getenv("TOSS_CLIENT_SECRET", ""),
            toss_api_base_url=os.getenv("TOSS_API_BASE_URL", "https://openapi.tossinvest.com"),
            toss_account_no=normalize_toss_account_no(os.getenv("TOSS_ACCOUNT_NO", None)),
            telegram_bot_token=os.getenv("TELEGRAM_BOT_TOKEN", ""),
            telegram_chat_id=os.getenv("TELEGRAM_ALERT_CHAT_ID", ""),
            telegram_enabled=os.getenv("TELEGRAM_ENABLED", "false").lower() == "true",
            strategy_rules=strategy_rules,
            strategy=generic_cfg,
            trading=trade_cfg,
            minute=minute_cfg,
            storage=StorageConfig(),
        )
