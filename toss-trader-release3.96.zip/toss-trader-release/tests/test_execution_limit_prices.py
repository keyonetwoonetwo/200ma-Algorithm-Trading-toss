from decimal import Decimal

import pytest

from app.execution.workflow_executor import WorkflowBlocked, WorkflowExecutor
from app.models.common import OrderSide
from app.models.portfolio import PortfolioState


class Adapter:
    def __init__(self, price, cash="200"):
        self.price = Decimal(price)
        self.cash = Decimal(cash)
        self.symbols = []

    def get_execution_price(self, symbol):
        self.symbols.append(symbol)
        return self.price

    def get_buying_power(self, *args):
        return self.cash

    def get_sellable_quantity(self, symbol):
        return Decimal("7")


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
@pytest.mark.parametrize("side,expected", [(OrderSide.BUY, "100.10"), (OrderSide.SELL, "99.90")])
def test_common_limit_price(core, side, expected):
    adapter = Adapter("100")
    executor = WorkflowExecutor(None, None, adapter)
    portfolio = PortfolioState(prices={"SIGNAL": Decimal("999"), "TARGET": Decimal("1")})
    assert executor._step_price({"execution_core": core}, "TARGET", portfolio, side) == Decimal(expected)
    assert adapter.symbols == ["TARGET"]


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
@pytest.mark.parametrize("side,expected", [(OrderSide.BUY, "0.5005"), (OrderSide.SELL, "0.4995")])
def test_sub_dollar_precision(core, side, expected):
    executor = WorkflowExecutor(None, None, Adapter("0.5"))
    assert executor._step_price({"execution_core": core}, "TARGET", PortfolioState(), side) == Decimal(expected)


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
def test_buy_quantity_uses_final_limit_without_exceeding_reserve(core):
    executor = WorkflowExecutor(None, None, Adapter("100"))
    item = executor._prepare_step(
        {"execution_core": core, "reason": "test"},
        {"symbol": "TARGET", "kind": "BUY_ENTRY_TRANCHE", "leg": "entry", "budget": "200"},
        PortfolioState(), {"orders": []},
    )
    assert item.quantity == 1
    assert item.price == Decimal("100.10")
    assert item.quantity * item.price <= Decimal("200")


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
def test_sub_one_share_reserve_does_not_create_zero_order(core, monkeypatch):
    executor = WorkflowExecutor(None, None, Adapter("100"))
    skipped = []
    monkeypatch.setattr(executor, "_warn_subthreshold_skip", lambda *args: skipped.append(args))
    item = executor._prepare_step(
        {"execution_core": core, "reason": "test"},
        {"symbol": "TARGET", "kind": "BUY_ENTRY_TRANCHE", "leg": "entry", "budget": "100"},
        PortfolioState(), {"orders": []},
    )
    assert item is None
    assert len(skipped) == 1


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
def test_sell_quantity_unchanged(core):
    executor = WorkflowExecutor(None, None, Adapter("100"))
    item = executor._prepare_step(
        {"execution_core": core, "reason": "test"},
        {"symbol": "TARGET", "kind": "SELL_MAIN", "leg": "sell", "quantity": 7},
        PortfolioState(), {"orders": []},
    )
    assert item.quantity == 7
    assert item.price == Decimal("99.90")


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
def test_missing_quote_remains_fail_closed(core):
    class Missing(Adapter):
        def get_execution_price(self, symbol):
            raise RuntimeError("unavailable")

    with pytest.raises(WorkflowBlocked):
        WorkflowExecutor(None, None, Missing("100"))._step_price(
            {"execution_core": core}, "TARGET", PortfolioState(), OrderSide.BUY,
        )
