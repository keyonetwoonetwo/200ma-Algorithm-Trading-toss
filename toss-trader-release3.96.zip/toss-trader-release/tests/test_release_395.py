from config.defaults import DEFAULT_CLOSE_EXECUTION_TIME
from scripts.platform_deploy import cron_block
from scripts.setup_wizard import trading_schedule
from version import RELEASE_VERSION


def test_release_version_and_regular_close_default():
    assert RELEASE_VERSION == "3.96"
    assert DEFAULT_CLOSE_EXECUTION_TIME == "16:00:00"


def test_close_schedulers_cover_regular_and_early_close(tmp_path):
    values = {"TRADING_SIGNAL_MODE": "CLOSE", "CLOSE_EXECUTION_TIME": "16:05:00"}
    block = cron_block(tmp_path, values, False)
    assert "0 13,16 * * 1-5" in block
    _, execution, schedule = trading_schedule(values)
    assert execution == "16:00:00"
    assert "13,16:00:00" in schedule
