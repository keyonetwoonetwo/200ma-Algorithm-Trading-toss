import hashlib
import io
import json
import os
import tarfile
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.models.portfolio import PortfolioState
from app.storage.order_ledger_store import DEFAULT_LEDGER
from app.storage.state_store import DEFAULT_STATE, StateIntegrityError, StateStore
from scripts import backup_common, recover_backup, recovery_scheduler
from scripts.recover_backup import recover


IDENTITY = {
    "account_no": "12345678", "account_seq": "7", "signal_symbol": "SIG",
    "main_symbol": "MAIN", "overheat_symbol": "HOT", "safe_symbol": "SAFE",
    "signal_mode": "CLOSE", "signal_time": "15:57:00",
}


def portfolio(main="2"):
    return PortfolioState(
        account_no="12345678", account_seq=7, main_quantity=Decimal(main),
        main_avg_price=Decimal("100"), overheat_quantity=Decimal("1"),
        safe_quantity=Decimal("3"), available_cash_usd=Decimal("45"),
        prices={"MAIN": Decimal("110"), "HOT": Decimal("80"), "SAFE": Decimal("100")},
    )


def state_bytes(identity=None):
    value = dict(DEFAULT_STATE)
    value.update({
        "installation_identity": dict(identity or IDENTITY), "cycle_state": "RISK_ON",
        "cycle_high_close": 110, "last_account_snapshot": StateStore.account_snapshot(portfolio()),
    })
    return json.dumps(value).encode()


def ledger_bytes(active=None, orders=None):
    value = dict(DEFAULT_LEDGER)
    value.update(active_workflow=active, orders=orders or [])
    return json.dumps(value).encode()


def archive(tmp_path, state=None, ledger=None, omit=None):
    contents = {
        "state.json": state or state_bytes(),
        "order_ledger.json": ledger or ledger_bytes(),
    }
    if omit:
        contents.pop(omit)
    archive_identity = json.loads(contents["state.json"])["installation_identity"] if "state.json" in contents else IDENTITY
    manifest = {
        "backup_format_version": 1,
        "installation_identity_hash": hashlib.sha256(json.dumps(archive_identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "account_hash": hashlib.sha256(b"12345678").hexdigest(),
        "included_files": {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()},
    }
    path = tmp_path / "toss-trader-backup-20261002-201500-UTC.tar.gz"
    with tarfile.open(path, "w:gz") as bundle:
        for name, data in contents.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            bundle.addfile(info, io.BytesIO(data))
        raw = json.dumps(manifest).encode()
        info = tarfile.TarInfo("manifest.json")
        info.size = len(raw)
        bundle.addfile(info, io.BytesIO(raw))
    return path


class Broker:
    def __init__(self, detail=None, fail=False):
        self.detail = detail
        self.fail = fail
        self.created = 0

    def get_prices(self, symbols):
        if self.fail:
            raise RuntimeError("account unavailable")
        return [{"symbol": symbol, "lastPrice": "100"} for symbol in symbols]

    def get_order_detail(self, order_id):
        if self.fail:
            raise RuntimeError("order unavailable")
        return self.detail

    def create_order(self, *args, **kwargs):
        self.created += 1
        raise AssertionError("recovery must never submit an order")


class Adapter:
    def __init__(self, value):
        self.value = value

    def get_portfolio_state(self, *args, **kwargs):
        return self.value


class Scheduler:
    def __init__(self, fail=False):
        self.quiesced = self.installed = self.rolled_back = False
        self.fail = fail
        self.values = None

    def quiesce(self):
        self.quiesced = True

    def install(self, values):
        self.installed = True
        self.values = dict(values)
        if self.fail:
            raise RuntimeError("scheduler failed")
        return SimpleNamespace(
            platform="linux", trading="INSTALLED", backup="DISABLED",
            public_ip_monitor="NOT_APPLICABLE", termux_boot="NOT_APPLICABLE", crond="NOT_APPLICABLE",
        )

    def rollback(self):
        self.rolled_back = True


def context(root, broker=None, actual=None, identity=None):
    broker = broker or Broker()
    actual = actual or portfolio()
    config = SimpleNamespace(
        execution_mode="DRY_RUN", live_trading_enabled=False, toss_account_no="12345678",
        storage=SimpleNamespace(process_lock_file=str(root / "data" / "recovery.lock")),
        resolved_strategy=lambda: SimpleNamespace(main_symbol="MAIN", overheat_symbol="HOT", safe_symbol="SAFE"),
    )
    return lambda: (config, broker, Adapter(actual), None, None, identity or dict(IDENTITY))


VALUES = {
    "EXECUTION_MODE": "DRY_RUN", "LIVE_TRADING_ENABLED": "false",
    "TRADING_SIGNAL_MODE": "CLOSE", "SIGNAL_TIME": "15:57:00",
}


def write_env(root, values):
    root.mkdir(parents=True, exist_ok=True)
    (root / ".env").write_text(
        "# keep this comment\n" + "".join(f"{key}={value}\n" for key, value in values.items()),
        encoding="utf-8",
    )


def signal_identity(mode, signal_time):
    return dict(IDENTITY, signal_mode=mode, signal_time=signal_time)


def env_context(root, broker=None, actual=None):
    def factory():
        values = {}
        for line in (root / ".env").read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                values[key] = value
        identity = signal_identity(values["TRADING_SIGNAL_MODE"], values["SIGNAL_TIME"])
        return context(root, broker, actual, identity)()
    return factory


def test_normal_391_backup_recovers_missing_local_pair_and_installs_scheduler(tmp_path):
    root = tmp_path / "app"
    scheduler = Scheduler()
    broker = Broker()
    report = recover(archive(tmp_path), context(root, broker), scheduler, root, dict(VALUES))
    assert json.loads((root / "data" / "state.json").read_text())["cycle_high_close"] == 110
    assert json.loads((root / "data" / "order_ledger.json").read_text())["active_workflow"] is None
    assert scheduler.quiesced and scheduler.installed and not scheduler.rolled_back
    assert report["reconciliation"].outcome == "CLEAN"
    assert broker.created == 0


def test_incomplete_local_pair_is_preserved_and_safely_replaced(tmp_path):
    root = tmp_path / "app"
    (root / "data").mkdir(parents=True)
    (root / "data" / "state.json").write_text("incomplete")
    report = recover(archive(tmp_path), context(root), Scheduler(), root, dict(VALUES))
    assert (report["local_backup"] / "state.json").read_text() == "incomplete"
    assert (report["local_backup"] / "manifest.json").is_file()


def test_identity_mismatch_is_fail_closed_before_install(tmp_path):
    root = tmp_path / "app"
    scheduler = Scheduler()
    wrong = dict(IDENTITY, main_symbol="OTHER")
    with pytest.raises(StateIntegrityError, match="MAIN_SYMBOL"):
        recover(archive(tmp_path), context(root, identity=wrong), scheduler, root, dict(VALUES))
    assert not scheduler.installed and scheduler.rolled_back
    assert not (root / "data" / "state.json").exists()


def test_corrupt_or_incomplete_archive_changes_nothing(tmp_path):
    bad = tmp_path / "bad.tar.gz"
    bad.write_bytes(b"not a tar")
    scheduler = Scheduler()
    with pytest.raises(RuntimeError, match="corrupted"):
        recover(bad, context(tmp_path / "app"), scheduler, tmp_path / "app", dict(VALUES))
    assert not scheduler.quiesced
    with pytest.raises(RuntimeError, match="unexpected or missing"):
        recover(archive(tmp_path, omit="state.json"), context(tmp_path / "app"), scheduler, tmp_path / "app", dict(VALUES))


def test_account_or_portfolio_failure_blocks_scheduler(tmp_path):
    root = tmp_path / "app"
    scheduler = Scheduler()
    with pytest.raises(RuntimeError, match="account unavailable"):
        recover(archive(tmp_path), context(root, Broker(fail=True)), scheduler, root, dict(VALUES))
    assert not scheduler.installed and scheduler.rolled_back
    scheduler = Scheduler()
    with pytest.raises(StateIntegrityError, match="main_quantity"):
        recover(archive(tmp_path), context(root, actual=portfolio("9")), scheduler, root, dict(VALUES))
    assert not scheduler.installed and scheduler.rolled_back


def active_ledger(status):
    workflow = {
        "workflow_id": "wf", "execution_core": "CLOSE", "execution_policy": {},
        "execution_mode": "LIVE", "steps": [{"leg": "BUY_MAIN", "kind": "BUY", "symbol": "MAIN"}],
        "status": "BLOCKED", "next_index": 0, "installation_identity": dict(IDENTITY),
    }
    order = {
        "workflow_id": "wf", "client_order_id": "wf-buy_main", "leg": "BUY_MAIN",
        "symbol": "MAIN", "side": "BUY", "requested_quantity": 2,
        "broker_order_id": "order-1", "status": "UNKNOWN",
    }
    detail = {"status": status, "execution": {
        "filledQuantity": "1" if status == "PARTIAL" else "0",
        "averageFilledPrice": "100" if status == "PARTIAL" else None,
        "filledAmount": "100" if status == "PARTIAL" else None,
    }}
    return ledger_bytes(workflow, [order]), detail


def test_broker_confirmed_filled_workflow_commits_then_installs_scheduler(tmp_path):
    root = tmp_path / "app"
    workflow = {
        "workflow_id": "wf", "execution_core": "CLOSE", "execution_policy": {},
        "execution_mode": "LIVE", "steps": [{"leg": "BUY_MAIN", "kind": "BUY", "symbol": "MAIN"}],
        "status": "BLOCKED", "next_index": 0, "installation_identity": dict(IDENTITY),
        "signal_date": "2026-10-09", "pending_state_transition": {}, "entry_split": None,
    }
    order = {
        "workflow_id": "wf", "client_order_id": "wf-buy_main", "leg": "BUY_MAIN",
        "symbol": "MAIN", "side": "BUY", "requested_quantity": 2,
        "broker_order_id": "order-1", "status": "UNKNOWN",
    }
    detail = {"status": "FILLED", "execution": {
        "filledQuantity": "2", "averageFilledPrice": "100", "filledAmount": "200",
    }}
    broker = Broker(detail)
    scheduler = Scheduler()
    result = recover(
        archive(tmp_path, ledger=ledger_bytes(workflow, [order])),
        context(root, broker, portfolio("4")), scheduler, root, dict(VALUES),
    )
    restored = json.loads((root / "data" / "state.json").read_text())
    assert restored["last_completed_workflow_id"] == "wf"
    assert restored["last_account_snapshot"]["main_quantity"] == "4"
    assert json.loads((root / "data" / "order_ledger.json").read_text())["active_workflow"] is None
    assert result["reconciliation"].outcome == "COMPLETED"
    assert scheduler.installed and broker.created == 0


@pytest.mark.parametrize("status", ["PARTIAL", "MYSTERY"])
def test_partial_or_unknown_blocks_scheduler_and_never_orders(tmp_path, status):
    root = tmp_path / "app"
    ledger, detail = active_ledger(status)
    broker = Broker(detail)
    scheduler = Scheduler()
    with pytest.raises(RuntimeError, match="workflow reconciliation blocked"):
        recover(archive(tmp_path, ledger=ledger), context(root, broker), scheduler, root, dict(VALUES))
    assert not scheduler.installed and scheduler.rolled_back
    assert broker.created == 0


def test_scheduler_failure_rolls_back_existing_local_pair(tmp_path):
    root = tmp_path / "app"
    (root / "data").mkdir(parents=True)
    old_state = b"old-state"
    old_ledger = b"old-ledger"
    (root / "data" / "state.json").write_bytes(old_state)
    (root / "data" / "order_ledger.json").write_bytes(old_ledger)
    scheduler = Scheduler(fail=True)
    with pytest.raises(RuntimeError, match="scheduler failed"):
        recover(archive(tmp_path), context(root), scheduler, root, dict(VALUES))
    assert (root / "data" / "state.json").read_bytes() == old_state
    assert (root / "data" / "order_ledger.json").read_bytes() == old_ledger
    assert scheduler.rolled_back


@pytest.mark.parametrize(
    "mode,signal_time",
    [("CLOSE", "16:00:00"), ("MINUTE", "15:57:00")],
)
def test_matching_trading_method_recovers_without_prompt(tmp_path, mode, signal_time):
    root = tmp_path / "app"
    values = dict(VALUES, TRADING_SIGNAL_MODE=mode, SIGNAL_TIME=signal_time)
    identity = signal_identity(mode, signal_time)
    scheduler = Scheduler()
    report = recover(
        archive(tmp_path, state=state_bytes(identity)),
        context(root, identity=identity), scheduler, root, values,
        input_fn=lambda _: pytest.fail("matching identity must not prompt"),
    )
    assert report["signal_recovery"] == "CURRENT"
    assert scheduler.values["TRADING_SIGNAL_MODE"] == mode


@pytest.mark.parametrize(
    "backup_mode,backup_time,current_mode,current_time",
    [
        ("CLOSE", "16:00:00", "MINUTE", "15:57:00"),
        ("MINUTE", "15:57:00", "CLOSE", "16:00:00"),
    ],
)
def test_choice_1_keeps_current_env_and_migrates_restored_identity(
    tmp_path, backup_mode, backup_time, current_mode, current_time,
):
    root = tmp_path / "app"
    values = dict(VALUES, TRADING_SIGNAL_MODE=current_mode, SIGNAL_TIME=current_time)
    write_env(root, values)
    before = (root / ".env").read_bytes()
    backup_identity = signal_identity(backup_mode, backup_time)
    current_identity = signal_identity(current_mode, current_time)
    scheduler = Scheduler()
    report = recover(
        archive(tmp_path, state=state_bytes(backup_identity)),
        context(root, identity=current_identity), scheduler, root, values,
        recovery_choice="1",
    )
    restored = json.loads((root / "data" / "state.json").read_text())
    assert (root / ".env").read_bytes() == before
    assert restored["installation_identity"] == current_identity
    assert restored["cycle_high_close"] == 110
    assert report["signal_recovery"] == "CURRENT"
    assert scheduler.values["TRADING_SIGNAL_MODE"] == current_mode
    assert scheduler.values["SIGNAL_TIME"] == current_time


@pytest.mark.parametrize(
    "backup_mode,backup_time,current_mode,current_time",
    [
        ("CLOSE", "16:00:00", "MINUTE", "15:57:00"),
        ("MINUTE", "15:57:00", "CLOSE", "16:00:00"),
    ],
)
def test_choice_2_updates_env_identity_and_scheduler_from_backup(
    tmp_path, monkeypatch, backup_mode, backup_time, current_mode, current_time,
):
    root = tmp_path / "app"
    values = dict(VALUES, TRADING_SIGNAL_MODE=current_mode, SIGNAL_TIME=current_time)
    write_env(root, values)
    monkeypatch.setenv("TRADING_SIGNAL_MODE", current_mode)
    monkeypatch.setenv("SIGNAL_TIME", current_time)
    backup_identity = signal_identity(backup_mode, backup_time)
    scheduler = Scheduler()
    report = recover(
        archive(tmp_path, state=state_bytes(backup_identity)),
        env_context(root), scheduler, root, values, recovery_choice="2",
    )
    env_text = (root / ".env").read_text(encoding="utf-8")
    restored = json.loads((root / "data" / "state.json").read_text())
    assert "# keep this comment" in env_text
    assert f"TRADING_SIGNAL_MODE={backup_mode}" in env_text
    assert f"SIGNAL_TIME={backup_time}" in env_text
    assert restored["installation_identity"] == backup_identity
    assert report["signal_recovery"] == "BACKUP"
    assert scheduler.values["TRADING_SIGNAL_MODE"] == backup_mode
    assert scheduler.values["SIGNAL_TIME"] == backup_time


@pytest.mark.parametrize("field", [
    "account_no", "account_seq", "signal_symbol", "main_symbol",
    "overheat_symbol", "safe_symbol",
])
def test_recovery_choice_never_relaxes_immutable_identity(tmp_path, field):
    root = tmp_path / "app"
    current = dict(IDENTITY)
    current[field] = "DIFFERENT"
    scheduler = Scheduler()
    with pytest.raises(StateIntegrityError):
        recover(
            archive(tmp_path), context(root, identity=current), scheduler, root,
            dict(VALUES), recovery_choice="1",
        )
    assert not scheduler.installed and scheduler.rolled_back


def test_choice_2_scheduler_failure_rolls_back_env_and_local_pair(tmp_path, monkeypatch):
    root = tmp_path / "app"
    values = dict(VALUES, TRADING_SIGNAL_MODE="MINUTE", SIGNAL_TIME="15:57:00")
    write_env(root, values)
    original_env = (root / ".env").read_bytes()
    (root / "data").mkdir(parents=True)
    (root / "data" / "state.json").write_bytes(b"old-state")
    (root / "data" / "order_ledger.json").write_bytes(b"old-ledger")
    monkeypatch.setenv("TRADING_SIGNAL_MODE", "MINUTE")
    monkeypatch.setenv("SIGNAL_TIME", "15:57:00")
    backup_identity = signal_identity("CLOSE", "16:00:00")
    scheduler = Scheduler(fail=True)
    with pytest.raises(RuntimeError, match="scheduler failed"):
        recover(
            archive(tmp_path, state=state_bytes(backup_identity)),
            env_context(root), scheduler, root, values, recovery_choice="2",
        )
    assert (root / ".env").read_bytes() == original_env
    assert (root / "data" / "state.json").read_bytes() == b"old-state"
    assert (root / "data" / "order_ledger.json").read_bytes() == b"old-ledger"
    assert os.environ["TRADING_SIGNAL_MODE"] == "MINUTE"


def test_invalid_recovery_choice_changes_nothing(tmp_path):
    root = tmp_path / "app"
    values = dict(VALUES, TRADING_SIGNAL_MODE="MINUTE")
    scheduler = Scheduler()
    with pytest.raises(RuntimeError, match="must be 1 or 2"):
        recover(archive(tmp_path), context(root), scheduler, root, values, recovery_choice="3")
    assert not scheduler.quiesced


def test_choice_2_env_write_failure_is_fail_closed(monkeypatch, tmp_path):
    root = tmp_path / "app"
    values = dict(VALUES, TRADING_SIGNAL_MODE="MINUTE")
    write_env(root, values)
    before = (root / ".env").read_bytes()
    scheduler = Scheduler()
    monkeypatch.setattr(
        recover_backup, "_atomic_update_signal_env",
        lambda *args: (_ for _ in ()).throw(PermissionError("env denied")),
    )
    with pytest.raises(PermissionError, match="env denied"):
        recover(
            archive(tmp_path), context(root), scheduler, root, values,
            recovery_choice="2",
        )
    assert (root / ".env").read_bytes() == before
    assert not scheduler.quiesced and not scheduler.installed
    assert not (root / "data" / "state.json").exists()


def test_termux_cron_and_boot_reuse_existing_helpers(tmp_path):
    from scripts.platform_deploy import cron_block

    values = {"TRADING_SIGNAL_MODE": "CLOSE"}
    assert recovery_scheduler.install_termux_cron.__module__ == "scripts.platform_deploy"
    block = cron_block(tmp_path, values, True, "17:20:00")
    assert "CRON_TZ=America/New_York" in block
    assert "20 17 * * *" in block and "backup.sh" in block
    assert "CRON_TZ=Asia/Seoul" in block and "check_public_ip.py" in block
    boot = recovery_scheduler.install_termux_boot(tmp_path, tmp_path / "home")
    assert "crond" in boot.read_text()


def test_linux_install_reuses_existing_timer_builder(monkeypatch, tmp_path):
    monkeypatch.setattr(recovery_scheduler, "selected_platform", lambda root: "linux")
    calls = []
    monkeypatch.setattr(recovery_scheduler, "enable_timer", lambda *args: calls.append(args) or "ok")
    runner = lambda *args, **kwargs: SimpleNamespace(returncode=1, stdout="", stderr="")
    scheduler = recovery_scheduler.RecoveryScheduler(tmp_path, run=runner)
    report = scheduler.install({"TRADING_SIGNAL_MODE": "CLOSE", "TELEGRAM_ENABLED": "false"})
    assert report.trading == "INSTALLED"
    assert len(calls) == 1
    assert calls[0][1] == "toss-trader.timer"
