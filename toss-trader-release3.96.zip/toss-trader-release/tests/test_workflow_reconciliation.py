import json
from decimal import Decimal

import pytest

from app.execution.workflow_executor import WorkflowExecutor
from app.execution.workflow_reconciler import WorkflowReconciler
from app.models.portfolio import PortfolioState
from app.storage.order_ledger_store import OrderLedgerStore
from scripts.reconcile_workflow import _commit_ready_live, _portfolio


def workflow(mode="LIVE", *, next_index=0):
    return {
        "workflow_id": "g-20260914-test", "execution_core": "CLOSE",
        "execution_policy": {"kind": "CLOSE"}, "steps": [], "status": "BLOCKED",
        "next_index": next_index, "execution_mode": mode, "signal_date": "2026-09-14",
        "pending_state_transition": {}, "entry_split": None,
    }


def store(tmp_path, active=None):
    ledger = OrderLedgerStore(str(tmp_path / "order_ledger.json"))
    ledger.save({"schema_version": 1, "active_workflow": active, "orders": [], "workflow_history": []})
    return ledger


def add_order(ledger, *, status="SUBMITTED", order_id="O1", quantity=10):
    data = ledger.load()
    data["active_workflow"]["steps"] = [{"leg": "BUY_MAIN", "kind": "BUY", "symbol": "TQQQ"}]
    ledger.save(data)
    ledger.append_intent({
        "client_order_id": "g-20260914-test-buy_main", "workflow_id": "g-20260914-test",
        "leg": "BUY_MAIN", "symbol": "TQQQ", "side": "BUY",
        "requested_quantity": quantity, "status": status,
    })
    ledger.update_order("g-20260914-test-buy_main", broker_order_id=order_id, status=status)


def detail(status, filled="0", avg=None, amount=None):
    execution = {"filledQuantity": filled}
    if avg is not None:
        execution["averageFilledPrice"] = avg
    if amount is not None:
        execution["filledAmount"] = amount
    return {"status": status, "execution": execution}


class Broker:
    def __init__(self, responses, cancel_response=None):
        self.responses = list(responses)
        self.cancel_response = cancel_response or {}
        self.cancelled = []

    def get_order_detail(self, order_id):
        value = self.responses.pop(0) if len(self.responses) > 1 else self.responses[0]
        if isinstance(value, Exception):
            raise value
        return value

    def cancel_order(self, order_id):
        self.cancelled.append(order_id)
        if isinstance(self.cancel_response, Exception):
            raise self.cancel_response
        return self.cancel_response


def test_prebackup_without_active_workflow_is_clean(tmp_path):
    assert WorkflowReconciler(store(tmp_path)).pre_backup_cleanup().outcome == "CLEAN"


@pytest.mark.parametrize(
    ("mode", "outcome", "terminal_status"),
    [("DRY_RUN", "DRY_RUN_CLEARED", "ABORTED_DRY_RUN"), ("LIVE", "ABORTED", "ABORTED_PRE_BACKUP")],
)
def test_preorder_without_intent_is_aborted_with_history(tmp_path, mode, outcome, terminal_status):
    ledger = store(tmp_path, workflow(mode))
    result = WorkflowReconciler(ledger).pre_backup_cleanup()
    saved = ledger.load()
    assert result.outcome == outcome
    assert saved["active_workflow"] is None
    assert saved["workflow_history"][-1]["terminal_status"] == terminal_status
    assert saved["workflow_history"][-1]["order_count"] == 0


def test_submitted_zero_fill_cancel_confirmed_aborts(tmp_path):
    ledger = store(tmp_path, workflow())
    add_order(ledger)
    broker = Broker([detail("PENDING"), detail("CANCELLED")])
    result = WorkflowReconciler(ledger, broker).pre_backup_cleanup()
    assert result.outcome == "ABORTED"
    assert broker.cancelled == ["O1"]
    saved = ledger.load()
    assert saved["active_workflow"] is None
    history = saved["workflow_history"][-1]
    assert history["terminal_status"] == "ABORTED_NO_FILL"
    assert history["filled_quantity"] == "0"
    assert history["cancel_result"] == ["REQUESTED_AND_CONFIRMED"]


@pytest.mark.parametrize(
    "broker_detail",
    [detail("PARTIAL_FILLED", "2", "10", "20"), detail("SOMETHING_NEW"), detail("CANCEL_REJECTED")],
)
def test_partial_and_unknown_never_auto_abort(tmp_path, broker_detail):
    ledger = store(tmp_path, workflow())
    add_order(ledger)
    result = WorkflowReconciler(ledger, Broker([broker_detail])).pre_backup_cleanup()
    assert result.outcome == "BLOCKED"
    assert ledger.load()["active_workflow"] is not None


def test_unconfirmed_cancel_never_auto_aborts(tmp_path):
    ledger = store(tmp_path, workflow())
    add_order(ledger)
    result = WorkflowReconciler(ledger, Broker([detail("PENDING"), detail("PENDING")])).pre_backup_cleanup()
    assert result.outcome == "BLOCKED"
    assert ledger.load()["active_workflow"] is not None


def test_operator_canceled_zero_fill_closes_without_manual_json_edit(tmp_path):
    ledger = store(tmp_path, workflow())
    add_order(ledger)
    result = WorkflowReconciler(ledger, Broker([detail("CANCELED")])).reconcile_active()
    assert result.outcome == "ABORTED"
    assert ledger.load()["active_workflow"] is None


def test_operator_filled_syncs_ledger_and_becomes_ready_to_commit(tmp_path):
    ledger = store(tmp_path, workflow(next_index=0))
    add_order(ledger)
    result = WorkflowReconciler(ledger, Broker([detail("FILLED", "10", "12", "120")])).reconcile_active()
    assert result.outcome == "READY_TO_COMMIT"
    saved = ledger.load()
    assert saved["active_workflow"]["status"] == "READY_TO_COMMIT"
    assert saved["orders"][-1]["average_filled_price"] == "12"


def test_confirmed_fill_commit_preserves_unrelated_cycle_memory(tmp_path):
    ledger = store(tmp_path, workflow(next_index=0))
    add_order(ledger)
    assert WorkflowReconciler(ledger, Broker([detail("FILLED", "10", "12", "120")])).reconcile_active().outcome == "READY_TO_COMMIT"

    class State:
        def __init__(self):
            self.value = {
                "cycle_state": "RISK_ON", "cycle_high_close": 321,
                "last_milestone": 100, "drawdown_triggered_at_high": 300,
                "entry_split_done": 2, "last_completed_workflow_id": None,
            }

        def load_state_strict(self):
            return dict(self.value)

        def save_state(self, value):
            self.value = value

        @staticmethod
        def account_snapshot(portfolio):
            return {"available_cash_usd": str(portfolio.available_cash_usd)}

    state = State()
    WorkflowExecutor(None, ledger, None).commit_confirmed_state(
        state, PortfolioState(available_cash_usd=Decimal("5")),
    )
    assert state.value["cycle_high_close"] == 321
    assert state.value["last_milestone"] == 100
    assert state.value["drawdown_triggered_at_high"] == 300
    assert state.value["entry_split_done"] == 2
    assert ledger.load()["active_workflow"] is None


@pytest.mark.parametrize("broker_detail", [detail("PARTIAL_FILLED", "1", "12", "12"), detail("UNKNOWN")])
def test_operator_partial_and_unknown_remain_active(tmp_path, broker_detail):
    ledger = store(tmp_path, workflow(next_index=1))
    add_order(ledger)
    assert WorkflowReconciler(ledger, Broker([broker_detail])).reconcile_active().outcome == "BLOCKED"
    assert ledger.load()["active_workflow"] is not None


def test_operator_broker_query_failure_is_fail_closed(tmp_path):
    ledger = store(tmp_path, workflow())
    add_order(ledger)
    result = WorkflowReconciler(ledger, Broker([RuntimeError("offline")])).reconcile_active()
    assert result.outcome == "BLOCKED"
    assert ledger.load()["active_workflow"] is not None


def test_operator_dry_run_never_queries_order_detail_or_advances_strategy_state(tmp_path):
    ledger = store(tmp_path, workflow("DRY_RUN", next_index=1))
    add_order(ledger, status="INTENT_RECORDED", order_id="SIM-123")
    cycle_memory = {"cycle_state": "RISK_ON", "cycle_high_close": 321, "last_milestone": 100}

    class MustNotQuery:
        def get_order_detail(self, order_id):
            raise AssertionError("DRY_RUN must not query a simulated order at Toss")

    result = WorkflowReconciler(ledger, MustNotQuery()).reconcile_active()
    assert result.outcome == "DRY_RUN_CLEARED"
    assert ledger.load()["active_workflow"] is None
    assert ledger.load()["workflow_history"][-1]["terminal_status"] == "ABORTED_DRY_RUN"
    assert cycle_memory == {"cycle_state": "RISK_ON", "cycle_high_close": 321, "last_milestone": 100}


def test_operator_cli_defense_never_commits_ready_dry_run():
    result = type("Result", (), {"outcome": "READY_TO_COMMIT", "message": ""})()
    calls = []

    def forbidden_executor(mode):
        calls.append(mode)
        raise AssertionError("DRY_RUN must not construct a committing executor")

    committed = _commit_ready_live(
        result, {"execution_mode": "DRY_RUN"}, forbidden_executor, object(), object(),
    )
    assert committed is False
    assert calls == []
    assert result.outcome == "BLOCKED"
    assert "Non-LIVE" in result.message


def test_reconciliation_does_not_touch_cycle_state_file(tmp_path):
    state_path = tmp_path / "state.json"
    original = {"cycle_state": "RISK_ON", "cycle_high_close": 321, "last_milestone": 100, "entry_split_done": 2}
    state_path.write_text(json.dumps(original), encoding="utf-8")
    ledger = store(tmp_path, workflow())
    add_order(ledger)
    WorkflowReconciler(ledger, Broker([detail("CANCELED")])).reconcile_active()
    assert json.loads(state_path.read_text(encoding="utf-8")) == original


def test_operator_command_refreshes_current_portfolio_roles_and_cash():
    class Config:
        @staticmethod
        def resolved_strategy():
            return type("Profile", (), {"main_symbol": "MAIN", "overheat_symbol": "HOT", "safe_symbol": "SAFE"})()

    class PriceBroker:
        def get_prices(self, symbols):
            assert symbols == ["MAIN", "HOT", "SAFE"]
            return [{"symbol": symbol, "lastPrice": str(index + 10)} for index, symbol in enumerate(symbols)]

    class Adapter:
        def __init__(self):
            self.args = None

        def get_portfolio_state(self, *args):
            self.args = args
            return "portfolio-refreshed"

    adapter = Adapter()
    result = _portfolio(Config(), PriceBroker(), adapter, {"account_seq": "7", "account_no": "123"})
    assert result == "portfolio-refreshed"
    assert adapter.args[0:2] == (7, "123")
    assert adapter.args[2] == {"MAIN": Decimal("10"), "HOT": Decimal("11"), "SAFE": Decimal("12")}
