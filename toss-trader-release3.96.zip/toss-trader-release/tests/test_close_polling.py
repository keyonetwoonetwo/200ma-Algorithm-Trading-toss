from datetime import datetime, timedelta
from decimal import Decimal
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest

from app.models.market import Candle, MarketSessionInfo
from app.runners.close_runner import (
    CLOSE_POLL_LOG_BACKUP_COUNT,
    CLOSE_POLL_LOG_MAX_BYTES,
    CloseRunner,
    configure_close_polling_file_log,
    logger as close_logger,
)
from app.runners.common import ExpectedNoOp


NY = ZoneInfo("America/New_York")


class Clock:
    def __init__(self, value):
        self.value = value

    def now(self):
        return self.value

    def sleep(self, seconds):
        self.value += timedelta(seconds=seconds)


class Calendar:
    def __init__(self, date="2026-09-14"):
        self.date = date

    def check_us_market_open(self, date_str=None):
        close = datetime.fromisoformat(f"{self.date}T16:00:00").replace(tzinfo=NY)
        return MarketSessionInfo(
            True, True, self.date,
            regular_start=close.replace(hour=9, minute=30), regular_end=close,
            after_start=close, after_end=close.replace(hour=20),
        )


def candle(label, *, volume="100", date="2026-09-14"):
    base = {"A": ("10", "12", "9", "11"), "B": ("10", "13", "9", "12"), "C": ("11", "14", "10", "13")}[label]
    return Candle(datetime.fromisoformat(f"{date}T16:00:00").replace(tzinfo=NY), *(Decimal(x) for x in base), Decimal(volume))


class Market:
    def __init__(self, observations):
        self.observations = list(observations)
        self.calls = 0

    def fetch_daily_candles(self, symbol, target_count=280):
        value = self.observations[min(self.calls, len(self.observations) - 1)]
        self.calls += 1
        if isinstance(value, Exception):
            raise value
        history = [
            Candle(datetime(2026, 9, 10 - index, 16, tzinfo=NY), Decimal("9"), Decimal("10"), Decimal("8"), Decimal("9"), Decimal("100"))
            for index in range(3)
        ]
        return history + ([] if value is None else [value])


class Config:
    trading = SimpleNamespace(candle_lookback_days=4)
    strategy_rules = SimpleNamespace(ma_period=2)

    @staticmethod
    def resolved_strategy():
        return SimpleNamespace(signal_symbol="TQQQ", main_symbol="TQQQ", overheat_threshold=Decimal("1.05"))


def prepare(observations, start="16:00:00"):
    clock = Clock(datetime.fromisoformat(f"2026-09-14T{start}").replace(tzinfo=NY))
    market = Market(observations)
    result = CloseRunner(clock.now, clock.sleep).prepare(Config(), Calendar(), market)
    return result, market, clock


def test_three_identical_ohlc_observations_finalize():
    result, market, _ = prepare([candle("A"), candle("A"), candle("A")])
    assert result.decision_price == Decimal("11")
    assert market.calls == 4


def test_two_identical_then_change_resets_count():
    result, market, _ = prepare([candle("A"), candle("A"), candle("B"), candle("B"), candle("B")])
    assert result.decision_price == Decimal("12")
    assert market.calls == 6


def test_last_deadline_observation_can_complete_three_stable_reads():
    result, market, clock = prepare([candle("C"), candle("C"), candle("C")], start="16:05:40")
    assert result.decision_price == Decimal("13")
    assert market.calls == 4
    assert clock.value.strftime("%H:%M:%S") == "16:06:00"


def test_unstable_through_1606_is_no_trade():
    with pytest.raises(ExpectedNoOp, match="not operationally finalized"):
        prepare([candle("A" if index % 2 == 0 else "B") for index in range(40)])


def test_volume_changes_do_not_reset_ohlc_stability():
    result, market, _ = prepare([candle("A", volume="100"), candle("A", volume="200"), candle("A", volume="300")])
    assert result.decision_price == Decimal("11")
    assert market.calls == 4


def test_close_price_change_invalidates_prior_count():
    result, market, _ = prepare([candle("A"), candle("A"), candle("B"), candle("B"), candle("B")])
    assert result.decision_price == Decimal("12")
    assert market.calls == 6


def test_missing_current_market_date_candle_fails_closed():
    with pytest.raises(ExpectedNoOp, match="not operationally finalized"):
        prepare([None])


def test_transient_api_error_does_not_count_as_stable():
    result, market, _ = prepare([candle("A"), RuntimeError("temporary"), candle("A"), candle("A"), candle("A")])
    assert result.decision_price == Decimal("11")
    assert market.calls == 6


def test_close_polling_has_bounded_persistent_file_with_full_observations(tmp_path):
    path = tmp_path / "close_polling.log"
    handler = configure_close_polling_file_log(path)
    try:
        prepare([
            candle("A", volume="100"), candle("A", volume="200"), candle("A", volume="300"),
        ])
        handler.flush()
        contents = path.read_text(encoding="utf-8")
        assert "stable_count=1" in contents
        assert "stable_count=2" in contents
        assert "stable_count=3" in contents
        assert "NY=2026-09-14T16:00:00-04:00" in contents
        assert "OHLC=(10,12,9,11)" in contents
        assert "volume=300" in contents
        assert handler.maxBytes == CLOSE_POLL_LOG_MAX_BYTES
        assert handler.backupCount == CLOSE_POLL_LOG_BACKUP_COUNT
    finally:
        close_logger.removeHandler(handler)
        handler.close()
