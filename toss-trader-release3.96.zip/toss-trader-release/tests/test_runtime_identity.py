from copy import deepcopy
from decimal import Decimal

import pytest

from app.models.market import IndicatorResult
from app.models.portfolio import PortfolioState
from app.storage.state_store import StateIntegrityError, StateStore
from app.strategy.strategy import StrategyEngine
from config.config import AppConfig, GenericStrategyConfig, StrategyConfig


def identity(profile=None, mode="CLOSE", account="123", seq=7):
    return (profile or GenericStrategyConfig()).installation_identity(mode, account, seq)


def legacy_identity():
    value = identity()
    value.update({
        "risk_threshold": "1.0", "overheat_threshold": "1.05",
        "wait_days": "1", "entry_split": "3",
    })
    return value


@pytest.mark.parametrize("field,value", [
    ("risk_threshold", 0.98), ("overheat_threshold", 1.01),
    ("wait_days", 0), ("entry_split", 5),
    ("entry_split_overheat_action", "OVERHEAT"),
])
def test_runtime_generic_setting_is_not_identity(field, value):
    base = identity()
    changed = identity(GenericStrategyConfig(**{field: value}))
    assert changed == base
    StateStore.assert_installation_identity({"installation_identity": legacy_identity()}, changed)


def test_all_other_runtime_and_secret_settings_are_absent_from_identity():
    runtime_keys = {
        "risk_threshold", "overheat_threshold", "wait_days", "entry_split",
        "entry_split_overheat_action", "ma_period", "drawdown_threshold",
        "drawdown_sell_ratio", "milestone_levels", "milestone_sell_ratios",
        "min_order_amount_usd", "candle_lookback_days",
        "minute_polling_interval_seconds", "minute_order_cutoff",
        "timeout_seconds", "close_execution_time", "toss_client_id",
        "toss_client_secret", "telegram_enabled", "telegram_bot_token",
        "telegram_alert_chat_id", "telegram_backup_chat_id",
    }
    assert runtime_keys.isdisjoint(identity())


@pytest.mark.parametrize("field,value,label", [
    ("signal_symbol", "QQQ", "SIGNAL_SYMBOL"),
    ("main_symbol", "UPRO", "MAIN_SYMBOL"),
    ("overheat_symbol", "SSO", "OVERHEAT_SYMBOL"),
    ("safe_symbol", "BIL", "SAFE_SYMBOL"),
    ("signal_time", "15:56:00", "SIGNAL_TIME"),
])
def test_protected_profile_change_reports_exact_field(field, value, label):
    with pytest.raises(StateIntegrityError, match=label):
        StateStore.assert_installation_identity(
            {"installation_identity": legacy_identity()},
            identity(GenericStrategyConfig(**{field: value})),
        )


def test_signal_mode_and_account_identity_remain_protected():
    approved = {"installation_identity": legacy_identity()}
    with pytest.raises(StateIntegrityError, match="TRADING_SIGNAL_MODE"):
        StateStore.assert_installation_identity(approved, identity(mode="MINUTE"))
    with pytest.raises(StateIntegrityError, match="TOSS_ACCOUNT_NO"):
        StateStore.assert_installation_identity(approved, identity(account="999"))
    with pytest.raises(StateIntegrityError, match="account_seq"):
        StateStore.assert_installation_identity(approved, identity(seq=8))


def active_state():
    return {
        "cycle_state": "RISK_ON", "cycle_high_close": 110,
        "last_milestone": 100, "entry_split_total": 3,
        "entry_split_done": 1, "entry_base_cash": "900",
        "entry_reserved_cash": "600", "entry_reserved_cash_balance": "600",
        "entry_split_status": "ACTIVE", "entry_split_terminated_reason": None,
        "wait_confirmation_count": 0,
    }


def test_active_split_uses_persisted_total_after_runtime_setting_change():
    engine = StrategyEngine(StrategyConfig(entry_split=9))
    state = active_state()
    portfolio = PortfolioState(
        main_quantity=Decimal("1"), main_avg_price=Decimal("100"),
        available_cash_usd=Decimal("600"), prices={"MAIN": Decimal("100"), "SAFE": Decimal("100")},
    )
    plan, updated = engine._entry_tranche_plan(
        deepcopy(state), portfolio, "MAIN", "SAFE", Decimal("100"), Decimal("100"),
        Decimal("110"), Decimal("900"), Decimal("600"), Decimal("600"), 1, False,
    )
    assert plan.entry_split["total"] == 3
    assert plan.entry_split["tranche_index"] == 2
    assert updated["entry_split_total"] == 3
    assert updated["last_milestone"] == 100


def test_new_split_uses_new_runtime_total():
    engine = StrategyEngine(StrategyConfig(entry_split=4))
    state = active_state()
    state.update(entry_split_status="INACTIVE", entry_split_total=0, entry_split_done=0)
    portfolio = PortfolioState(available_cash_usd=Decimal("800"))
    plan, updated = engine._entry_tranche_plan(
        deepcopy(state), portfolio, "MAIN", "SAFE", Decimal("100"), Decimal("100"),
        Decimal("110"), Decimal("800"), Decimal("800"), Decimal("800"), 0, True,
    )
    assert plan.entry_split["total"] == 4
    assert updated["entry_split_total"] == 4


def test_legacy_workflow_identity_accepts_runtime_differences_only():
    configured = identity(GenericStrategyConfig(entry_split=9, risk_threshold=.98))
    StateStore.assert_identity_values(legacy_identity(), configured)
    bad = legacy_identity()
    bad["main_symbol"] = "WRONG"
    with pytest.raises(StateIntegrityError, match="MAIN_SYMBOL"):
        StateStore.assert_identity_values(bad, configured)


def set_required_env(monkeypatch):
    values = {
        "SIGNAL_SYMBOL": "SIG", "MAIN_SYMBOL": "MAIN", "OVERHEAT_SYMBOL": "HOT",
        "SAFE_SYMBOL": "SAFE", "RISK_THRESHOLD": "1.00", "OVERHEAT_THRESHOLD": "1.05",
        "SIGNAL_TIME": "15:57:00", "TRADING_SIGNAL_MODE": "CLOSE",
        "TOSS_ACCOUNT_NO": "123", "TOSS_CLIENT_ID": "old-id",
        "TOSS_CLIENT_SECRET": "old-secret", "TELEGRAM_ENABLED": "false",
        "TELEGRAM_BOT_TOKEN": "old-token", "TELEGRAM_ALERT_CHAT_ID": "old-chat",
    }
    for key, value in values.items():
        monkeypatch.setenv(key, value)


def test_env_runtime_values_reload_without_identity_change(monkeypatch):
    set_required_env(monkeypatch)
    before = AppConfig.load()
    changed = {
        "RISK_THRESHOLD": "0.98", "OVERHEAT_THRESHOLD": "1.01", "WAIT_DAYS": "0",
        "ENTRY_SPLIT": "4", "ENTRY_SPLIT_OVERHEAT_ACTION": "OVERHEAT",
        "MA_PERIOD": "180", "DRAWDOWN_THRESHOLD": "0.70", "DRAWDOWN_SELL_RATIO": "0.40",
        "MILESTONE_LEVELS": "25,75,150", "MILESTONE_SELL_RATIOS": "0.1,0.2,0.5",
        "MIN_ORDER_AMOUNT_USD": "12", "CANDLE_LOOKBACK_DAYS": "320",
        "MINUTE_POLLING_INTERVAL_SECONDS": "3", "MINUTE_ORDER_CUTOFF": "15:58:40",
        "TIMEOUT_SECONDS": "45", "CLOSE_EXECUTION_TIME": "16:05:00",
        "TOSS_CLIENT_ID": "new-id", "TOSS_CLIENT_SECRET": "new-secret",
        "TELEGRAM_ENABLED": "true", "TELEGRAM_BOT_TOKEN": "new-token",
        "TELEGRAM_ALERT_CHAT_ID": "new-chat", "TELEGRAM_BACKUP_CHAT_ID": "backup-chat",
    }
    for key, value in changed.items():
        monkeypatch.setenv(key, value)
    after = AppConfig.load()
    assert before.resolved_strategy().installation_identity("CLOSE", "123", 7) == after.resolved_strategy().installation_identity("CLOSE", "123", 7)
    assert after.strategy.risk_threshold == .98
    assert after.strategy.overheat_threshold == 1.01
    assert (after.strategy.wait_days, after.strategy.entry_split, after.strategy.entry_split_overheat_action) == (0, 4, "OVERHEAT")
    assert after.strategy_rules.ma_period == 180
    assert (after.strategy_rules.drawdown_threshold, after.strategy_rules.drawdown_sell_ratio) == (.70, .40)
    assert [level for level, _ in after.strategy_rules.milestones] == [25, 75, 150]
    assert after.trading.min_order_amount_usd == 12
    assert after.trading.candle_lookback_days == 320
    assert after.minute.polling_interval_seconds == 3
    assert after.minute.order_cutoff == "15:58:40"
    assert after.timeout_seconds == 45
    assert (after.toss_client_id, after.toss_client_secret) == ("new-id", "new-secret")
    assert (after.telegram_enabled, after.telegram_bot_token, after.telegram_chat_id) == (True, "new-token", "new-chat")


def test_milestone_validation_still_rejects_mismatched_arrays(monkeypatch):
    set_required_env(monkeypatch)
    monkeypatch.setenv("MILESTONE_LEVELS", "50,100")
    monkeypatch.setenv("MILESTONE_SELL_RATIOS", "0.5")
    with pytest.raises(ValueError, match="same number"):
        AppConfig.load()
