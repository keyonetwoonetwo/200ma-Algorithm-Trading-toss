from datetime import datetime, timedelta
from decimal import Decimal
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest

from app.market.market_data import MarketDataService
from app.models.market import Candle, MarketSessionInfo
from app.runners.close_runner import CloseRunner
from app.runners.common import ExpectedNoOp
from app.runners.minute_runner import MinuteRunner
from app.runners.minute_timing import session_timing
from scripts.platform_deploy import cron_block
from scripts.setup_wizard import timer_unit, trading_schedule


NY = ZoneInfo("America/New_York")
DAY = "2026-11-27"


def session(close_hour=16, *, open_day=True):
    if not open_day:
        return MarketSessionInfo(False, False, DAY)
    start = datetime(2026, 11, 27, 9, 30, tzinfo=NY)
    end = datetime(2026, 11, 27, close_hour, 0, tzinfo=NY)
    return MarketSessionInfo(
        True, True, DAY, start, end, end, end.replace(hour=17),
        previous_business_date="2026-11-25",
    )


class Calendar:
    def __init__(self, value):
        self.value = value

    def check_us_market_open(self, date_str=None):
        return self.value


class MinuteMarket:
    def __init__(self, signal_time):
        self.signal_time = signal_time

    def fetch_intraday_candles(self, symbol, interval="1m", count=5):
        timestamp = datetime.fromisoformat(f"{DAY}T{self.signal_time}").replace(tzinfo=NY)
        return [Candle(timestamp, Decimal("100"), Decimal("101"), Decimal("99"), Decimal("100"), Decimal("10"))]

    def fetch_daily_candles(self, symbol, target_count=280):
        return [
            Candle(datetime(2026, 11, 24, 16, tzinfo=NY), Decimal("90"), Decimal("91"), Decimal("89"), Decimal("90"), Decimal("10")),
            Candle(datetime(2026, 11, 25, 16, tzinfo=NY), Decimal("95"), Decimal("96"), Decimal("94"), Decimal("95"), Decimal("10")),
        ]

    exclude_market_date = staticmethod(MarketDataService.exclude_market_date)


class MinuteConfig:
    minute = SimpleNamespace(order_cutoff="15:58:50", polling_interval_seconds=2)
    trading = SimpleNamespace(candle_lookback_days=3)
    strategy_rules = SimpleNamespace(ma_period=2)

    @staticmethod
    def resolved_strategy():
        return SimpleNamespace(
            signal_time="15:57:00", signal_symbol="SIGNAL", main_symbol="SIGNAL",
            overheat_threshold=Decimal("1.05"),
        )


@pytest.mark.parametrize(
    ("close_hour", "effective_signal", "effective_cutoff"),
    [(16, "15:57:00", "15:58:50"), (13, "12:57:00", "12:58:50")],
)
def test_effective_signal_time_is_relative_to_actual_regular_close(
    close_hour, effective_signal, effective_cutoff,
):
    timing = session_timing(session(close_hour), "15:57:00", "15:58:50")
    assert timing.signal_time == effective_signal
    assert timing.order_cutoff.strftime("%H:%M:%S") == effective_cutoff


@pytest.mark.parametrize(("close_hour", "signal_time", "run_time"), [
    (16, "15:57:00", "15:58:10"),
    (13, "12:57:00", "12:58:10"),
])
def test_minute_prepare_trades_on_regular_and_early_close(
    close_hour, signal_time, run_time,
):
    now = datetime.fromisoformat(f"{DAY}T{run_time}").replace(tzinfo=NY)
    prepared = MinuteRunner(lambda: now, lambda _: None).prepare(
        MinuteConfig(), Calendar(session(close_hour)), MinuteMarket(signal_time),
    )
    assert prepared.decision_price == Decimal("100")
    assert prepared.execution_policy["signal_time"] == signal_time
    assert prepared.execution_policy["configured_signal_time"] == "15:57:00"
    assert prepared.execution_policy["admission_deadline"].endswith(
        ("15:58:50-05:00" if close_hour == 16 else "12:58:50-05:00")
    )


def test_scheduler_has_early_and_regular_minute_candidates(tmp_path):
    values = {"TRADING_SIGNAL_MODE": "MINUTE", "SIGNAL_TIME": "15:57:00"}
    _, execution, schedule = trading_schedule(values)
    assert execution == "15:58:10"
    assert schedule.splitlines() == [
        "Mon..Fri *-*-* 12:58:10 America/New_York",
        "Mon..Fri *-*-* 15:58:10 America/New_York",
    ]
    unit = timer_unit("trade", schedule, "toss-trader.service")
    assert unit.count("OnCalendar=") == 2
    cron = cron_block(tmp_path, values, False)
    assert "58 12 * * 1-5" in cron
    assert "58 15 * * 1-5" in cron


@pytest.mark.parametrize(("close_hour", "candidate"), [(16, "12:58:10"), (13, "15:58:10")])
def test_wrong_scheduler_candidate_is_noop(close_hour, candidate):
    now = datetime.fromisoformat(f"{DAY}T{candidate}").replace(tzinfo=NY)
    with pytest.raises(ExpectedNoOp, match="MINUTE"):
        MinuteRunner(lambda: now).prepare(
            MinuteConfig(), Calendar(session(close_hour)), MinuteMarket("15:57:00"),
        )


def test_only_one_scheduler_candidate_is_admitted_per_market_date():
    for close_hour, admitted in ((16, "15:58:10"), (13, "12:58:10")):
        current_session = session(close_hour)
        timing = session_timing(current_session, "15:57:00", "15:58:50")
        results = []
        for candidate in ("12:58:10", "15:58:10"):
            now = datetime.fromisoformat(f"{DAY}T{candidate}").replace(tzinfo=NY)
            results.append(MinuteRunner(lambda: now)._in_window(current_session, timing, now))
        assert results.count(True) == 1
        assert results[("12:58:10", "15:58:10").index(admitted)]


def test_holiday_remains_no_trade():
    now = datetime(2026, 11, 27, 12, 58, 10, tzinfo=NY)
    with pytest.raises(ExpectedNoOp, match="휴장"):
        MinuteRunner(lambda: now).prepare(
            MinuteConfig(), Calendar(session(open_day=False)), MinuteMarket("12:57:00"),
        )


class CloseMarket:
    def __init__(self, close_hour):
        self.close_hour = close_hour

    def fetch_daily_candles(self, symbol, target_count=280):
        history = [
            Candle(datetime(2026, 11, 24, 16, tzinfo=NY), Decimal("90"), Decimal("91"), Decimal("89"), Decimal("90"), Decimal("10")),
            Candle(datetime(2026, 11, 25, 16, tzinfo=NY), Decimal("95"), Decimal("96"), Decimal("94"), Decimal("95"), Decimal("10")),
        ]
        today = Candle(
            datetime(2026, 11, 27, self.close_hour, tzinfo=NY),
            Decimal("99"), Decimal("101"), Decimal("98"), Decimal("100"), Decimal("10"),
        )
        return [today] if target_count == 1 else history + [today]


@pytest.mark.parametrize("close_hour", [16, 13])
def test_close_mode_regular_and_early_close_regression(close_hour):
    now = datetime(2026, 11, 27, close_hour, 0, tzinfo=NY)
    config = SimpleNamespace(
        trading=SimpleNamespace(candle_lookback_days=3),
        strategy_rules=SimpleNamespace(ma_period=2),
        resolved_strategy=lambda: SimpleNamespace(
            signal_symbol="SIGNAL", main_symbol="SIGNAL", overheat_threshold=Decimal("1.05"),
        ),
    )
    result = CloseRunner(lambda: now, lambda _: None).prepare(
        config, Calendar(session(close_hour)), CloseMarket(close_hour),
    )
    assert result.decision_price == Decimal("100")
    assert result.execution_policy["regular_market_end"].endswith(
        f"T{close_hour:02d}:00:00-05:00"
    )
