from datetime import datetime, timezone
from decimal import Decimal

import pytest

from app.execution.order_manager import OrderManager
from app.execution.workflow_executor import WorkflowBlocked, WorkflowExecutor
from app.models.common import ExecutionMode
from app.models.market import IndicatorResult
from app.models.order_identity import workflow_step_client_ids
from app.models.portfolio import PortfolioState
from app.storage.order_ledger_store import OrderLedgerStore
from app.strategy.strategy import StrategyEngine
from config.config import StrategyConfig


def indicator(overheat=False, risk_on=True):
    close = Decimal("110") if overheat else Decimal("102")
    if not risk_on:
        close = Decimal("80")
    return IndicatorResult(
        "SIGNAL", close, Decimal("100"), Decimal("105"),
        Decimal("100"), risk_on, True, Decimal("105"),
    )


def active_state():
    return {
        "cycle_state": "RISK_ON", "cycle_high_close": 110,
        "last_milestone": 0, "drawdown_triggered_at_high": None,
        "entry_split_total": 3, "entry_split_done": 1,
        "entry_base_cash": "1200", "entry_reserved_cash": "800",
        "entry_reserved_cash_balance": "800",
        "entry_split_status": "ACTIVE", "entry_split_terminated_reason": None,
    }


def portfolio(cash="1000", main_price="100"):
    return PortfolioState(
        main_quantity=Decimal("6"), main_avg_price=Decimal("100"),
        available_cash_usd=Decimal(cash),
        prices={
            "MAIN": Decimal(main_price), "HOT": Decimal("80"),
            "SAFE": Decimal("100"),
        },
    )


def engine(action="SAFE", milestones=None):
    options = {
        "main_symbol": "MAIN", "overheat_symbol": "HOT", "safe_symbol": "SAFE",
        "entry_split": 3, "entry_split_overheat_action": action,
    }
    if milestones is not None:
        options["milestones"] = milestones
    return StrategyEngine(StrategyConfig(**options))


def test_main_active_split_keeps_tranche_and_new_cash_as_two_budgets():
    plan, updated = engine().evaluate(indicator(), portfolio(), active_state(), Decimal("102"))
    assert [(order.symbol, order.quantity) for order in plan.orders] == [("MAIN", 4), ("MAIN", 2)]
    assert plan.entry_split["budget"] == "400"
    assert plan.entry_split["new_cash_budget"] == "200"
    assert plan.entry_split["new_cash_symbol"] == "MAIN"
    assert updated["entry_split_done"] == 2


def test_main_new_cash_does_not_change_reserve_or_split_progress():
    without_new_cash_plan, without_new_cash_state = engine().evaluate(
        indicator(), portfolio("800"), active_state(), Decimal("102"),
    )
    with_new_cash_plan, with_new_cash_state = engine().evaluate(
        indicator(), portfolio("1000"), active_state(), Decimal("102"),
    )
    assert len(without_new_cash_plan.orders) == 1
    assert len(with_new_cash_plan.orders) == 2
    for key in (
        "entry_split_total", "entry_split_done", "entry_base_cash",
        "entry_reserved_cash", "entry_reserved_cash_balance", "entry_split_status",
    ):
        assert with_new_cash_state[key] == without_new_cash_state[key]
    assert with_new_cash_state["entry_split_done"] == active_state()["entry_split_done"] + 1


def test_main_split_workflow_has_independent_steps_and_client_ids():
    decision, plan = engine().evaluate_decision(
        indicator(), portfolio(), active_state(), Decimal("102"),
    )
    executor = WorkflowExecutor(None, None, None)
    steps = executor._build_steps(decision, plan, "MAIN", "HOT", "SAFE")
    assert steps == [
        {
            "leg": "BUY_MAIN_ENTRY_2", "kind": "BUY_ENTRY_TRANCHE",
            "symbol": "MAIN", "budget": "400", "required": False,
        },
        {
            "leg": "BUY_MAIN_NEW_CASH_ENTRY_2", "kind": "BUY_NEW_CASH_MAIN",
            "symbol": "MAIN", "budget": "200", "required": False,
        },
    ]
    workflow = {
        "workflow_id": executor.workflow_id("2026-10-11", decision),
        "client_order_id_scheme": "HASH_V2", "steps": steps,
    }
    client_ids = workflow_step_client_ids(workflow)
    assert len(client_ids) == len(set(client_ids)) == 2
    assert all(len(value) <= 36 for value in client_ids)


class ExecutionAdapter:
    def get_execution_price(self, symbol):
        return Decimal("100")

    def get_buying_power(self):
        return Decimal("1000")


class StrategyState:
    def __init__(self, value):
        self.value = dict(value)

    def load_state_strict(self):
        return dict(self.value)

    def save_state(self, value):
        self.value = dict(value)

    @staticmethod
    def account_snapshot(portfolio_state):
        return {"available_cash_usd": str(portfolio_state.available_cash_usd)}


def test_resume_executes_each_main_budget_once_with_independent_idempotency(tmp_path):
    decision, plan = engine().evaluate_decision(
        indicator(), portfolio(), active_state(), Decimal("102"),
    )
    ledger = OrderLedgerStore(str(tmp_path / "ledger.json"))
    ledger.initialize_approved_ledger()
    now = datetime(2026, 10, 11, 20, 0, tzinfo=timezone.utc)
    executor = WorkflowExecutor(
        OrderManager(None, ExecutionMode.DRY_RUN), ledger, ExecutionAdapter(),
        now_fn=lambda: now,
    )
    executor.start(
        "2026-10-11", decision, plan, portfolio(), signal_mode="CLOSE",
        execution_policy={
            "kind": "CLOSE", "market_date": "2026-10-11",
            "after_market_start": "2026-10-11T19:00:00+00:00",
            "after_market_end": "2026-10-11T21:00:00+00:00",
        },
        installation_identity={
            "main_symbol": "MAIN", "overheat_symbol": "HOT", "safe_symbol": "SAFE",
        },
    )
    records, completed = executor.resume(portfolio(), lambda: portfolio())
    assert completed and len(records) == 2
    persisted = ledger.load()["orders"]
    assert [order["requested_quantity"] for order in persisted] == [3, 1]
    assert len({order["client_order_id"] for order in persisted}) == 2
    repeated, repeated_complete = executor.resume(portfolio(), lambda: portfolio())
    assert repeated_complete and repeated == []
    assert len(ledger.load()["orders"]) == 2

    tranche_fill = Decimal(ledger.load()["orders"][0]["filled_amount"])
    new_cash_fill = Decimal(ledger.load()["orders"][1]["filled_amount"])
    final_portfolio = portfolio(str(Decimal("1000") - tranche_fill - new_cash_fill))
    state_store = StrategyState(active_state())
    committed = executor.commit_confirmed_state(state_store, final_portfolio)
    expected_reserve = Decimal("800") - tranche_fill
    assert Decimal(committed["entry_reserved_cash"]) == expected_reserve
    assert Decimal(committed["entry_reserved_cash_balance"]) == expected_reserve
    assert Decimal(committed["entry_reserved_cash"]) != Decimal("800") - tranche_fill - new_cash_fill
    assert committed["entry_split_done"] == 2


def test_new_cash_main_cannot_masquerade_as_missing_tranche_order():
    decision, plan = engine().evaluate_decision(
        indicator(), portfolio(), active_state(), Decimal("102"),
    )
    plan.orders = plan.orders[1:]
    with pytest.raises(WorkflowBlocked, match="independent order plans|MAIN tranche"):
        WorkflowExecutor(None, None, None)._build_steps(decision, plan, "MAIN", "HOT", "SAFE")


def test_overheat_main_still_routes_split_to_main_and_new_cash_to_overheat():
    decision, plan = engine("MAIN").evaluate_decision(
        indicator(overheat=True), portfolio(), active_state(), Decimal("110"),
    )
    steps = WorkflowExecutor(None, None, None)._build_steps(
        decision, plan, "MAIN", "HOT", "SAFE",
    )
    assert [(step["kind"], step["symbol"], step["budget"]) for step in steps] == [
        ("BUY_ENTRY_TRANCHE", "MAIN", "400"),
        ("BUY_NEW_CASH_OVERHEAT", "HOT", "200"),
    ]


def test_risk_off_drawdown_and_milestone_keep_priority_over_split_new_cash():
    risk_off, _ = engine().evaluate(indicator(risk_on=False), portfolio(), active_state(), Decimal("80"))
    assert risk_off.decision == "RISK_OFF"

    drawdown_state = active_state()
    drawdown_state["cycle_high_close"] = 200
    drawdown, _ = engine().evaluate(indicator(), portfolio(), drawdown_state, Decimal("100"))
    assert drawdown.decision == "DRAWDOWN_REDUCE"
    assert drawdown.entry_split is None

    holdings = portfolio()
    holdings.main_avg_price = Decimal("50")
    milestone, _ = engine(milestones=((100, Decimal("0.5")),)).evaluate(
        indicator(), holdings, active_state(), Decimal("110"),
    )
    assert milestone.decision == "MILESTONE_100"
    assert milestone.entry_split is None
