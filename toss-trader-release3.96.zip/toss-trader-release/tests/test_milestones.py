from decimal import Decimal

import pytest

from app.models.common import OrderSide
from app.models.market import IndicatorResult
from app.models.orders import OrderItem, OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState
from app.execution.workflow_executor import BLOCKING_ORDER_STATUSES, WorkflowBlocked, WorkflowExecutor
from app.strategy.strategy import StrategyEngine
from config.config import (
    AppConfig,
    DEFAULT_MILESTONE_LEVELS,
    DEFAULT_MILESTONE_SELL_RATIOS,
    GenericStrategyConfig,
    StrategyConfig,
    parse_milestones,
)


DEFAULT_MILESTONES = tuple(zip(DEFAULT_MILESTONE_LEVELS, DEFAULT_MILESTONE_SELL_RATIOS))


def indicator(*, risk_on=True):
    return IndicatorResult(
        symbol="TQQQ",
        current_close=Decimal("100") if risk_on else Decimal("40"),
        ma200=Decimal("50"),
        prev_close=Decimal("100"),
        prev_ma200=Decimal("50"),
        is_above_ma200=risk_on,
        is_prev_above_ma200=True,
        overheat_price=Decimal("105"),
    )


def portfolio(price, quantity=100, cash="0"):
    price = Decimal(str(price))
    return PortfolioState(
        main_quantity=Decimal(quantity),
        main_avg_price=Decimal("100"),
        available_cash_usd=Decimal(cash),
        prices={"TQQQ": price, "SPYM": Decimal("50"), "SGOV": Decimal("100")},
    )


def evaluate(price, *, last=0, milestones=DEFAULT_MILESTONES, quantity=100, cycle_high=None, risk_on=True):
    engine = StrategyEngine(StrategyConfig(milestones=milestones))
    state = {
        "cycle_state": "RISK_ON",
        "cycle_high_close": float(price if cycle_high is None else cycle_high),
        "last_milestone": last,
    }
    return engine.evaluate(indicator(risk_on=risk_on), portfolio(price, quantity), state, Decimal(str(price)))


def test_default_values_parse():
    assert parse_milestones(
        "50,100,200,300,400,500,600",
        "0.30,0.50,0.50,0.50,0.50,0.50,0.50",
    ) == DEFAULT_MILESTONES


def test_whitespace_values_parse():
    assert parse_milestones("50, 100, 200, 400", "0.30, 0.50, 0.50, 1") == (
        (50, Decimal("0.30")), (100, Decimal("0.50")),
        (200, Decimal("0.50")), (400, Decimal("1")),
    )


@pytest.mark.parametrize(
    ("levels", "ratios", "message"),
    [
        ("", "0.3", "MILESTONE_LEVELS"),
        ("50", "", "MILESTONE_SELL_RATIOS"),
        ("50,100,200", "0.3,0.5", "same number"),
        ("50,ABC", "0.3,0.5", "MILESTONE_LEVELS"),
        ("100,50,200", "0.3,0.5,0.5", "strictly increasing"),
        ("50,50,100", "0.3,0.5,0.5", "duplicate"),
        ("0,50", "0.3,0.5", "must be > 0"),
        ("50,100", "0,0.5", "0 < ratio <= 1"),
        ("50,100", "0.3,1.2", "0 < ratio <= 1"),
        ("50,,100", "0.3,0.5,0.5", "empty item"),
        ("50,100", "0.3,NOPE", "MILESTONE_SELL_RATIOS"),
    ],
)
def test_invalid_values_fail_fast(levels, ratios, message):
    with pytest.raises(ValueError, match=message):
        parse_milestones(levels, ratios)


@pytest.mark.parametrize(
    ("price", "last", "decision", "sell_quantity", "ratio"),
    [
        (150, 0, "MILESTONE_50", 30, Decimal("0.30")),
        (200, 50, "MILESTONE_100", 50, Decimal("0.50")),
        (700, 500, "MILESTONE_600", 50, Decimal("0.50")),
    ],
)
def test_default_milestones_use_current_holding_ratio(price, last, decision, sell_quantity, ratio):
    plan, state = evaluate(price, last=last)
    assert plan.decision == decision
    assert plan.orders[0].side == OrderSide.SELL
    assert plan.orders[0].quantity == sell_quantity
    assert state["last_milestone"] == int(decision.rsplit("_", 1)[1])
    event, _ = StrategyEngine(StrategyConfig()).evaluate_decision(
        indicator(), portfolio(price), {"cycle_state": "RISK_ON", "cycle_high_close": price, "last_milestone": last},
        Decimal(price),
    )
    assert event.sell_ratio == ratio


def test_no_automatic_milestone_after_configured_maximum():
    plan, state = evaluate(1000, last=600)
    assert plan.decision == "HOLD_RISK_ON"
    assert not plan.orders
    assert state["last_milestone"] == 600


def test_custom_milestones_and_highest_reached_unexecuted_only():
    custom = parse_milestones("10,25,50,100,200,400", "0.10,0.10,0.10,0.50,0.50,0.50")
    plan, state = evaluate(220, last=10, milestones=custom)
    assert plan.decision == "MILESTONE_100"
    assert plan.orders[0].quantity == 50
    assert state["last_milestone"] == 100


def test_new_lower_levels_are_not_applied_retroactively():
    custom = parse_milestones("50,75,100,150,300", "0.3,0.3,0.5,0.5,0.5")
    plan, state = evaluate(260, last=100, milestones=custom)
    assert plan.decision == "MILESTONE_150"
    assert state["last_milestone"] == 150


def test_last_milestone_need_not_exist_in_new_configuration():
    custom = parse_milestones("50,100,150,300", "0.3,0.5,0.5,0.5")
    plan, state = evaluate(410, last=200, milestones=custom)
    assert plan.decision == "MILESTONE_300"
    assert state["last_milestone"] == 300


def test_drawdown_still_has_priority_over_milestone():
    plan, state = evaluate(200, last=0, cycle_high=300)
    assert plan.decision == "DRAWDOWN_REDUCE"
    assert state["last_milestone"] == 0


def test_risk_off_still_has_priority_and_resets_cycle():
    plan, state = evaluate(200, last=100, risk_on=False)
    assert plan.decision == "RISK_OFF"
    assert state["last_milestone"] == 0


def test_principal_and_profit_routing_is_unchanged():
    plan, _ = evaluate(200, last=50)
    assert [(order.symbol, order.side, order.quantity) for order in plan.orders] == [
        ("TQQQ", OrderSide.SELL, 50),
        ("SPYM", OrderSide.BUY, 100),
        ("SGOV", OrderSide.BUY, 50),
    ]


def test_milestones_are_not_part_of_installation_identity():
    identity = GenericStrategyConfig().installation_identity("CLOSE", "1234", 1)
    assert all("milestone" not in key.lower() for key in identity)


def test_entry_split_setting_is_runtime_not_installation_identity():
    assert StrategyConfig().entry_split == 1
    assert "entry_split" not in GenericStrategyConfig(entry_split=3).installation_identity("CLOSE")


@pytest.mark.parametrize(
    ("entry_split", "expected_quantity", "expected_status"),
    [(1, 3, None), (3, 1, "ACTIVE")],
)
def test_entry_split_one_and_multiple_regression(entry_split, expected_quantity, expected_status):
    engine = StrategyEngine(StrategyConfig(entry_split=entry_split))
    entry_portfolio = PortfolioState(
        available_cash_usd=Decimal("300"),
        prices={"TQQQ": Decimal("100"), "SPYM": Decimal("50"), "SGOV": Decimal("100")},
    )
    plan, state = engine.evaluate(indicator(), entry_portfolio, {}, Decimal("100"))
    assert plan.decision == "RISK_ON_ENTRY"
    assert plan.orders[-1].symbol == "TQQQ"
    assert plan.orders[-1].quantity == expected_quantity
    assert state.get("entry_split_status") == expected_status


def test_milestone_state_transition_remains_conditional_for_durable_workflow():
    engine = StrategyEngine(StrategyConfig())
    decision, plan = engine.evaluate_decision(
        indicator(), portfolio(200),
        {"cycle_state": "RISK_ON", "cycle_high_close": 200, "last_milestone": 50},
        Decimal("200"),
    )
    assert plan.decision == "MILESTONE_100"
    assert decision.pending_state_transition["last_milestone"] == 100
    assert decision.milestone == 100
    assert decision.sell_ratio == Decimal("0.50")


def test_app_config_loads_env_milestones(monkeypatch):
    required = {
        "SIGNAL_SYMBOL": "TQQQ", "MAIN_SYMBOL": "TQQQ", "OVERHEAT_SYMBOL": "SPYM",
        "SAFE_SYMBOL": "SGOV", "RISK_THRESHOLD": "1", "OVERHEAT_THRESHOLD": "1.05",
        "SIGNAL_TIME": "15:57:00", "MILESTONE_LEVELS": "10, 25, 50",
        "MILESTONE_SELL_RATIOS": "0.1, 0.2, 0.5",
    }
    for key, value in required.items():
        monkeypatch.setenv(key, value)
    assert AppConfig.load().strategy_rules.milestones == (
        (10, Decimal("0.1")), (25, Decimal("0.2")), (50, Decimal("0.5")),
    )


class FakeLedger:
    def __init__(self, data):
        self.data = data

    def load(self):
        return self.data


def test_milestone_workflow_keeps_dependent_principal_and_profit_legs():
    executor = WorkflowExecutor(None, FakeLedger({"orders": []}), None)
    sell = OrderItem("TQQQ", OrderSide.SELL, 25, price=Decimal("175"))
    plan = OrderPlan("generic", "MILESTONE_75", "custom milestone", [sell])
    decision = StrategyDecision("generic", plan.decision, plan.reason, plan.decision)
    steps = executor._build_steps(decision, plan, "TQQQ", "SPYM", "SGOV")
    assert [step["kind"] for step in steps] == [
        "SELL", "BUY_MILESTONE_PRINCIPAL", "BUY_MILESTONE_PROFIT",
    ]


def test_duplicate_order_intent_remains_fail_closed():
    workflow = {"workflow_id": "g-20260909-milestone-75"}
    client_id = WorkflowExecutor.client_order_id(workflow["workflow_id"], "SELL_MAIN")
    executor = WorkflowExecutor(None, FakeLedger({"orders": [{"client_order_id": client_id}]}), None)
    item = OrderItem("TQQQ", OrderSide.SELL, 25, price=Decimal("175"))
    with pytest.raises(WorkflowBlocked, match="Order intent already exists"):
        executor._record_intent(workflow, item, "SELL_MAIN")


@pytest.mark.parametrize("status", ["UNKNOWN", "PARTIAL_FILLED_BLOCKED"])
def test_unknown_and_partial_workflows_cannot_commit_state(status):
    ledger = FakeLedger({"active_workflow": {"status": status}})
    executor = WorkflowExecutor(None, ledger, None)
    with pytest.raises(WorkflowBlocked, match="No workflow ready to commit"):
        executor.commit_confirmed_state(None, portfolio(175))
    assert status in BLOCKING_ORDER_STATUSES
