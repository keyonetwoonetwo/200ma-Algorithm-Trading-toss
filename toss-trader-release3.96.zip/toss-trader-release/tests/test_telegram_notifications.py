from decimal import Decimal

from app.models.common import OrderSide, OrderStatus
from app.models.market import IndicatorResult
from app.models.orders import ExecutionRecord
from app.models.portfolio import PortfolioState
from app.notification.telegram import TelegramNotifier
from app.strategy.generic_strategy import GenericStrategy
from config.config import GenericStrategyConfig


def indicator(symbol: str, close: str, ma200: str = "100") -> IndicatorResult:
    return IndicatorResult(
        symbol=symbol,
        current_close=Decimal(close),
        ma200=Decimal(ma200),
        prev_close=Decimal("99"),
        prev_ma200=Decimal(ma200),
        is_above_ma200=False,
        is_prev_above_ma200=False,
        overheat_price=Decimal("0"),
    )


def notifier_messages():
    messages = []
    notifier = TelegramNotifier("", "", enabled=False)
    notifier.send_message = lambda message: messages.append(message) or True
    return notifier, messages


def test_signal_and_main_roles_and_exact_engine_thresholds_are_distinct():
    profile = GenericStrategyConfig(
        signal_symbol="QQQ",
        main_symbol="TQQQ",
        overheat_symbol="SPYM",
        safe_symbol="SGOV",
        risk_threshold=0.98,
        overheat_threshold=1.05,
        wait_days=0,
        entry_split=3,
        entry_split_overheat_action="OVERHEAT",
    )
    portfolio = PortfolioState(
        main_quantity=Decimal("0"),
        main_avg_price=Decimal("0"),
        available_cash_usd=Decimal("108.33"),
        prices={"TQQQ": Decimal("70"), "SPYM": Decimal("89.31"), "SGOV": Decimal("100")},
    )
    strategy = GenericStrategy(profile)
    decision, plan = strategy.evaluate_decision(indicator("QQQ", "106"), portfolio, {}, Decimal("69.27"))

    assert decision.decision == "RISK_ON_OVERHEAT_ENTRY"
    assert decision.signal_ma200 == Decimal("100")
    assert decision.risk_on_price == Decimal("98.00")
    assert decision.overheat_price == Decimal("105.00")
    assert "2-day" not in decision.reason

    notifier, messages = notifier_messages()
    notifier.notify_decision(
        decision, plan, portfolio,
        main_symbol=profile.main_symbol,
        overheat_symbol=profile.overheat_symbol,
        safe_symbol=profile.safe_symbol,
        wait_days=profile.wait_days,
        entry_split=profile.entry_split,
        entry_split_overheat_action=profile.entry_split_overheat_action,
    )
    message = messages[0]
    assert "- 신호 종목: QQQ" in message
    assert "- 신호 종가: <b>$106.00</b>" in message
    assert "- 200MA: $100.00" in message
    assert "- Risk-On 기준: $98.00" in message
    assert "- Overheat 기준: $105.00" in message
    assert "- 메인 종목: TQQQ" in message
    assert "- TQQQ 종가:" not in message
    assert "대기 0일 | ENTRY_SPLIT=3 | 미진입 tranche=OVERHEAT" in message
    assert "분할 진입:" not in message


def test_actual_entry_split_tranche_is_shown_but_setting_is_not_mislabeled():
    profile = GenericStrategyConfig(
        signal_symbol="SIGNAL",
        main_symbol="MAIN",
        overheat_symbol="HOT",
        safe_symbol="SAFE",
        wait_days=0,
        entry_split=3,
    )
    portfolio = PortfolioState(
        available_cash_usd=Decimal("300"),
        prices={"MAIN": Decimal("50"), "HOT": Decimal("25"), "SAFE": Decimal("100")},
    )
    decision, plan = GenericStrategy(profile).evaluate_decision(
        indicator("SIGNAL", "101"), portfolio, {}, Decimal("50"),
    )
    assert plan.entry_split["kind"] == "TRANCHE"
    assert plan.entry_split["tranche_index"] == 1
    assert plan.entry_split["total"] == 3

    notifier, messages = notifier_messages()
    notifier.notify_decision(
        decision, plan, portfolio,
        main_symbol="MAIN", overheat_symbol="HOT", safe_symbol="SAFE",
        wait_days=0, entry_split=3,
    )
    assert "- 진입 설정: 대기 0일 | ENTRY_SPLIT=3 | 미진입 tranche=SAFE" in messages[0]
    assert "- 분할 진입: 1/3" in messages[0]


def test_main_return_uses_existing_portfolio_price_without_new_quote():
    profile = GenericStrategyConfig(
        signal_symbol="SIGNAL", main_symbol="MAIN", overheat_symbol="HOT", safe_symbol="SAFE", wait_days=0,
    )
    portfolio = PortfolioState(
        main_quantity=Decimal("2"), main_avg_price=Decimal("80"),
        prices={"MAIN": Decimal("100"), "HOT": Decimal("25"), "SAFE": Decimal("100")},
    )
    decision, plan = GenericStrategy(profile).evaluate_decision(
        indicator("SIGNAL", "101"), portfolio, {}, Decimal("100"),
    )
    notifier, messages = notifier_messages()
    notifier.notify_decision(decision, plan, portfolio, main_symbol="MAIN", overheat_symbol="HOT", safe_symbol="SAFE")
    assert "보유 MAIN: 2주 (평단: $80.00, 수익률: 25.0%)" in messages[0]


def record(status: OrderStatus, *, order_id: str = "order-1", requested: int = 2, filled: str = "2"):
    return ExecutionRecord(
        order_id=order_id,
        symbol="SPYM",
        side=OrderSide.BUY,
        quantity=requested,
        status=status,
        filled_quantity=Decimal(filled),
        average_filled_price=Decimal("89.31") if Decimal(filled) > 0 else None,
        reason="a long strategy reason that must not be repeated",
    )


def test_filled_execution_is_concise_and_uses_share_units():
    notifier, messages = notifier_messages()
    notifier.notify_execution([record(OrderStatus.FILLED, requested=1, filled="1")])
    message = messages[0]
    assert message.startswith("⚡")
    assert "- 주문: BUY SPYM" in message
    assert "- 체결상태: <code>FILLED</code>" in message
    assert "- 체결수량: 1주" in message
    assert "사유:" not in message
    assert "건" not in message


def test_partial_and_unknown_execution_are_warning_results():
    notifier, messages = notifier_messages()
    notifier.notify_execution([record(OrderStatus.PARTIAL_FILLED, requested=2, filled="1")])
    partial = messages[0]
    assert partial.startswith("⚠️")
    assert "<code>PARTIAL</code>" in partial
    assert "- 요청수량: 2주" in partial
    assert "- 조치: 자동 진행 중단" in partial

    notifier.notify_execution([record(OrderStatus.PENDING, order_id="UNKNOWN", requested=2, filled="0")])
    unknown = messages[1]
    assert unknown.startswith("⚠️")
    assert "<code>UNKNOWN</code>" in unknown
    assert "- 체결단가: N/A" in unknown
    assert "- 조치: 자동 진행 중단" in unknown


def test_telegram_html_escaping_is_preserved():
    profile = GenericStrategyConfig(
        signal_symbol="SIG<&", main_symbol="MAIN", overheat_symbol="HOT", safe_symbol="SAFE", wait_days=0,
    )
    portfolio = PortfolioState(prices={"MAIN": Decimal("10"), "HOT": Decimal("10"), "SAFE": Decimal("10")})
    decision, plan = GenericStrategy(profile).evaluate_decision(
        indicator("SIG<&", "101"), portfolio, {}, Decimal("10"),
    )
    notifier, messages = notifier_messages()
    notifier.notify_decision(decision, plan, portfolio, main_symbol="MAIN", overheat_symbol="HOT", safe_symbol="SAFE")
    assert "SIG&lt;&amp;" in messages[0]
    assert "SIG<&" not in messages[0]
