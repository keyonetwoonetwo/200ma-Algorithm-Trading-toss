#!/usr/bin/env python3
"""Explicit account-bound first initialization; never migrates existing data."""
try:
    from release_common import ROOT, runtime_context
except ModuleNotFoundError:  # package import in regression tests
    from scripts.release_common import ROOT, runtime_context


def initialize_approved_state(require_confirmation: bool = True) -> None:
    """Create fresh approved state. Only setup_wizard uses the trusted bypass."""
    config, broker, adapter, state_store, ledger_store, identity = runtime_context(require_dry=True)
    if state_store.state_file_path.exists() or ledger_store.path.exists():
        raise RuntimeError("state or ledger already exists; automatic migration/overwrite is forbidden")
    profile = config.resolved_strategy()
    prices = {item["symbol"]: item["lastPrice"] for item in broker.get_prices([profile.main_symbol, profile.overheat_symbol, profile.safe_symbol])}
    portfolio = adapter.get_portfolio_state(int(identity["account_seq"]), identity["account_no"], {key: __import__("decimal").Decimal(str(value)) for key, value in prices.items()}, profile.main_symbol, profile.overheat_symbol, profile.safe_symbol)
    # A fresh automatic initializer only accepts an unambiguous no-risk-assets state.
    if portfolio.main_quantity > 0 or portfolio.overheat_quantity > 0:
        raise RuntimeError("managed main/overheat holdings exist; use an operator-approved manual recovery, not automatic initialization")
    masked = "*" * max(0, len(identity["account_no"]) - 3) + identity["account_no"][-3:]
    print(f"Account: {masked} (seq {identity['account_seq']})\nSignal/Main/Overheat/Safe: {profile.signal_symbol}/{profile.main_symbol}/{profile.overheat_symbol}/{profile.safe_symbol}")
    if require_confirmation and input("Type INITIALIZE APPROVED STATE to continue: ").strip() != "INITIALIZE APPROVED STATE":
        raise SystemExit("Initialization cancelled.")
    state_store.initialize_approved_state({
        "installation_identity": identity,
        "last_account_snapshot": state_store.account_snapshot(portfolio),
        "cycle_state": "RISK_OFF",
    })
    ledger_store.initialize_approved_ledger()
    print("Approved account-bound state and empty ledger initialized.")


def initialize_from_fresh_setup() -> None:
    """Internal setup-wizard path; guard checks above remain mandatory.

    This is intentionally not exposed as a CLI option. The wizard calls it
    only after configure approval, fresh-state preflight, and DRY_RUN checks.
    """
    initialize_approved_state(require_confirmation=False)


def main() -> None:
    initialize_approved_state(require_confirmation=True)


if __name__ == "__main__":
    main()
