"""Transactional reuse of the existing Linux/Termux scheduler installers."""
from dataclasses import dataclass
from pathlib import Path
import subprocess
import tempfile
from typing import Dict, Optional

try:
    from platform_deploy import (
        install_termux_boot, install_termux_cron, replace_marker_block,
        selected_platform, validate_termux_runtime,
    )
    from setup_wizard import enable_timer, service_unit, timer_unit, trading_schedule
    from release_common import ROOT
except ModuleNotFoundError:
    from scripts.platform_deploy import (
        install_termux_boot, install_termux_cron, replace_marker_block,
        selected_platform, validate_termux_runtime,
    )
    from scripts.setup_wizard import enable_timer, service_unit, timer_unit, trading_schedule
    from scripts.release_common import ROOT
from config.defaults import DEFAULT_BACKUP_TIME, NY_ZONE


LINUX_UNITS = (
    "toss-trader.service", "toss-trader.timer",
    "toss-trader-backup.service", "toss-trader-backup.timer",
)


def backup_enabled(values: Dict[str, str]) -> bool:
    chat = values.get("TELEGRAM_BACKUP_CHAT_ID", "").strip() or values.get("TELEGRAM_ALERT_CHAT_ID", "").strip()
    return (
        values.get("TELEGRAM_ENABLED", "false").lower() == "true"
        and bool(values.get("TELEGRAM_BOT_TOKEN", "").strip()) and bool(chat)
    )


@dataclass
class SchedulerReport:
    platform: str
    trading: str = "NOT_INSTALLED"
    backup: str = "DISABLED"
    public_ip_monitor: str = "NOT_APPLICABLE"
    termux_boot: str = "NOT_APPLICABLE"
    crond: str = "NOT_APPLICABLE"


class RecoveryScheduler:
    """Quiesce before recovery, install after reconcile, and rollback on error."""

    def __init__(self, root: Path = ROOT, run=subprocess.run):
        self.root = root
        self.run = run
        self.platform = selected_platform(root)
        self._cron: Optional[str] = None
        self._boot_existed = False
        self._boot_contents: Optional[bytes] = None
        self._linux_units: Dict[str, Optional[bytes]] = {}
        self._linux_enabled = False
        self._linux_active = False

    def quiesce(self) -> None:
        if self.platform == "termux":
            validate_termux_runtime()
            result = self.run(["crontab", "-l"], text=True, capture_output=True)
            if result.returncode == 0:
                self._cron = result.stdout
            elif "no crontab" in (result.stderr or "").lower():
                self._cron = ""
            else:
                raise RuntimeError(f"existing crontab unavailable: {(result.stderr or '').strip()}")
            cleaned = replace_marker_block(self._cron, "")
            self.run(["crontab", "-"], input=cleaned, text=True, check=True)
            boot = Path.home() / ".termux" / "boot" / "start-toss-trader"
            self._boot_existed = boot.exists()
            self._boot_contents = boot.read_bytes() if boot.exists() else None
            return

        unit_root = Path("/etc/systemd/system")
        self._linux_units = {
            name: (unit_root / name).read_bytes() if (unit_root / name).exists() else None
            for name in LINUX_UNITS
        }
        self._linux_enabled = self.run(
            ["systemctl", "is-enabled", "toss-trader.timer"], capture_output=True, text=True,
        ).returncode == 0
        self._linux_active = self.run(
            ["systemctl", "is-active", "toss-trader.timer"], capture_output=True, text=True,
        ).returncode == 0
        self.run(["sudo", "systemctl", "disable", "--now", "toss-trader.timer"], check=False, text=True)

    def install(self, values: Dict[str, str]) -> SchedulerReport:
        enabled = backup_enabled(values)
        backup_time = values.get("BACKUP_TIME", DEFAULT_BACKUP_TIME).strip() or DEFAULT_BACKUP_TIME
        _, _, schedule = trading_schedule(values)
        if self.platform == "termux":
            install_termux_cron(self.root, values, enabled, backup_time)
            install_termux_boot(self.root)
            self.run(["sh", "-c", "pgrep -x crond >/dev/null 2>&1 || crond"], check=True, text=True)
            return SchedulerReport(
                "termux", "INSTALLED", "INSTALLED" if enabled else "DISABLED",
                "INSTALLED", "INSTALLED", "RUNNING",
            )

        if enabled:
            enable_timer(
                "toss-trader-backup.service", "toss-trader-backup.timer",
                service_unit(self.root, "toss-trader-backup.service", "backup.sh", "Toss Trader state backup"),
                timer_unit("Schedule Toss Trader state backup", f"*-*-* {backup_time} {NY_ZONE}", "toss-trader-backup.service"),
            )
        enable_timer(
            "toss-trader.service", "toss-trader.timer",
            service_unit(self.root, "toss-trader.service", "run.sh", "Toss Trader one-shot run"),
            timer_unit("Schedule Toss Trader one-shot run", schedule, "toss-trader.service"),
        )
        return SchedulerReport("linux", "INSTALLED", "INSTALLED" if enabled else "DISABLED")

    def rollback(self) -> None:
        if self.platform == "termux":
            if self._cron is not None:
                self.run(["crontab", "-"], input=self._cron, text=True, check=False)
            boot = Path.home() / ".termux" / "boot" / "start-toss-trader"
            if self._boot_existed and self._boot_contents is not None:
                boot.parent.mkdir(parents=True, exist_ok=True)
                boot.write_bytes(self._boot_contents)
                boot.chmod(0o700)
            elif not self._boot_existed:
                boot.unlink(missing_ok=True)
            return

        for name, contents in self._linux_units.items():
            target = f"/etc/systemd/system/{name}"
            if contents is None:
                self.run(["sudo", "rm", "-f", target], check=False, text=True)
            else:
                with tempfile.NamedTemporaryFile("wb", delete=False) as handle:
                    handle.write(contents)
                    temporary = handle.name
                try:
                    self.run(["sudo", "install", "-m", "0644", temporary, target], check=False, text=True)
                finally:
                    Path(temporary).unlink(missing_ok=True)
        self.run(["sudo", "systemctl", "daemon-reload"], check=False, text=True)
        if self._linux_enabled:
            self.run(["sudo", "systemctl", "enable", "toss-trader.timer"], check=False, text=True)
        if self._linux_active:
            self.run(["sudo", "systemctl", "start", "toss-trader.timer"], check=False, text=True)
