"""Shared fail-closed helpers for installation and release operations."""
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Tuple

ROOT = Path(__file__).resolve().parents[1]
# ``python scripts/<tool>.py`` otherwise puts only ``scripts/`` on sys.path.
# Keep direct maintenance invocations as reliable as the shell entrypoints.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
ENV_PATH = ROOT / ".env"
VALIDATION_PATH = ROOT / "data" / "dry_run_validation.json"


def read_env(path: Path = ENV_PATH) -> Dict[str, str]:
    if not path.exists():
        raise RuntimeError(".env is missing; run ./configure.sh first")
    values: Dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    return values


def write_env(values: Dict[str, str], backup: bool = True) -> None:
    if backup and ENV_PATH.exists():
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        ENV_PATH.replace(ROOT / f".env.backup.{stamp}")
    body = "\n".join(f"{key}={value}" for key, value in values.items()) + "\n"
    temp = ENV_PATH.with_suffix(".tmp")
    temp.write_text(body, encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(ENV_PATH)
    os.chmod(ENV_PATH, 0o600)


def identity_hash(identity: Dict[str, str]) -> str:
    encoded = json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def runtime_context(require_dry: bool = False) -> Tuple[object, object, object, object, object, Dict[str, str]]:
    """Read-only Toss validation context. It never creates, cancels, or modifies orders."""
    os.chdir(ROOT)
    from app.api import TossAPIClient, TossAuthManager, TossBrokerAPI
    from app.notification import TelegramNotifier
    from app.portfolio import PortfolioAdapter
    from app.storage import OrderLedgerStore, StateStore
    from config.config import AppConfig

    values = read_env()
    config = AppConfig.load()
    if require_dry and (config.execution_mode != "DRY_RUN" or config.live_trading_enabled):
        raise RuntimeError("operation requires EXECUTION_MODE=DRY_RUN and LIVE_TRADING_ENABLED=false")
    TelegramNotifier(config.telegram_bot_token, config.telegram_chat_id, config.telegram_enabled)
    auth = TossAuthManager(config.toss_api_base_url, config.toss_client_id, config.toss_client_secret, config.timeout_seconds)
    client = TossAPIClient(config.toss_api_base_url, auth, timeout_seconds=config.timeout_seconds)
    broker = TossBrokerAPI(client)
    adapter = PortfolioAdapter(broker, client)
    account_seq = adapter.resolve_account_seq(config.toss_account_no)
    profile = config.resolved_strategy()
    identity = profile.installation_identity(config.signal_mode, config.toss_account_no or "", account_seq)
    state_store = StateStore(config.storage.state_file)
    ledger_store = OrderLedgerStore(config.storage.order_ledger_file)
    return config, broker, adapter, state_store, ledger_store, identity


def write_validation_record(identity: Dict[str, str], values: Dict[str, str]) -> None:
    VALIDATION_PATH.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "schema_version": 1,
        "validated_at": datetime.now(timezone.utc).isoformat(),
        "result": "PASS",
        "execution_mode": "DRY_RUN",
        "live_trading_enabled": False,
        "identity_hash": identity_hash(identity),
        "account_no": identity["account_no"],
        "account_seq": identity["account_seq"],
        "spec_confirmations": values.get("SPEC_CONFIRMATIONS", ""),
    }
    temp = VALIDATION_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(record, indent=2), encoding="utf-8")
    temp.replace(VALIDATION_PATH)
