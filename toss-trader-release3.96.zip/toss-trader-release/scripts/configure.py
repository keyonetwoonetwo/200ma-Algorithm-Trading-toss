#!/usr/bin/env python3
"""Interactive creation of a secret-safe .env file."""
from decimal import Decimal, InvalidOperation
from getpass import getpass
from pathlib import Path
try:
    from release_common import ENV_PATH, ROOT, read_env, write_env
except ModuleNotFoundError:
    from scripts.release_common import ENV_PATH, ROOT, read_env, write_env
from config.config import AppConfig, MinuteConfig, StrategyConfig, TradingConfig, normalize_toss_account_no
from config.defaults import DEFAULT_BACKUP_TIME


def ask_symbol(label: str) -> str:
    value = input(f"{label}: ").strip().upper()
    if not value or any(ch in value for ch in "=\n\r"):
        raise ValueError(f"{label} must be a non-empty symbol")
    return value


def ask_decimal(label: str) -> str:
    value = input(f"{label}: ").strip()
    try:
        if Decimal(value) <= 0:
            raise ValueError
    except (InvalidOperation, ValueError):
        raise ValueError(f"{label} must be a positive Decimal")
    return value


def ask_wait_days(default: int) -> str:
    value = input(f"재진입 대기일 [{default}]: ").strip() or str(default)
    if not value.isdigit():
        raise ValueError("WAIT_DAYS는 0 이상의 정수여야 합니다.")
    return str(int(value))


def ask_entry_split(default: int) -> str:
    value = input(f"초기 분할매수 횟수 ENTRY_SPLIT [{default}]: ").strip() or str(default)
    if not value.isdigit() or int(value) <= 0:
        raise ValueError("ENTRY_SPLIT은 1 이상의 정수여야 합니다.")
    return str(int(value))


def ask_entry_split_overheat_action(default: str) -> str:
    value = input(f"Overheat 발생 시 ACTIVE split 처리 [SAFE/OVERHEAT/MAIN, {default}]: ").strip().upper() or default
    if value not in {"SAFE", "OVERHEAT", "MAIN"}:
        raise ValueError("ENTRY_SPLIT_OVERHEAT_ACTION은 SAFE, OVERHEAT 또는 MAIN이어야 합니다.")
    return value


def ask_yes_no(label: str) -> bool:
    value = input(f"{label} [y/N]: ").strip().lower()
    return value in {"y", "yes"}


def ask_yes_no_default_yes(label: str) -> bool:
    value = input(f"{label} [Y/n]: ").strip().lower()
    return value not in {"n", "no"}


def main() -> None:
    app_defaults = AppConfig()
    strategy_defaults = StrategyConfig()
    trading_defaults = TradingConfig()
    minute_defaults = MinuteConfig()
    old_values = read_env() if ENV_PATH.exists() else None
    if old_values is not None and not ask_yes_no("기존 .env가 있습니다. 백업 후 덮어쓰시겠습니까?"):
        raise SystemExit("변경된 파일이 없습니다.")
    print("모든 신호 시각은 America/New_York 기준입니다. 설치는 항상 DRY_RUN으로 시작합니다.")
    mode = input("실행 방식 TRADING_SIGNAL_MODE [CLOSE/MINUTE]: ").strip().upper()
    if mode not in {"CLOSE", "MINUTE"}:
        raise ValueError("TRADING_SIGNAL_MODE는 CLOSE 또는 MINUTE여야 합니다.")
    signal_time = input("신호 시각 SIGNAL_TIME [HH:MM:SS]: ").strip()
    from datetime import time
    import re
    if not re.fullmatch(r"\d{2}:\d{2}:\d{2}", signal_time):
        raise ValueError("SIGNAL_TIME은 정확한 HH:MM:SS 형식이어야 합니다.")
    time.fromisoformat(signal_time)
    if mode == "MINUTE":
        AppConfig._validate_minute_timing(signal_time, minute_defaults)
    values = {
        "EXECUTION_MODE": "DRY_RUN", "LIVE_TRADING_ENABLED": "false",
        "SIGNAL_SYMBOL": ask_symbol("SIGNAL_SYMBOL"), "MAIN_SYMBOL": ask_symbol("MAIN_SYMBOL"),
        "OVERHEAT_SYMBOL": ask_symbol("OVERHEAT_SYMBOL"), "SAFE_SYMBOL": ask_symbol("SAFE_SYMBOL"),
        "RISK_THRESHOLD": ask_decimal("RISK_THRESHOLD"), "OVERHEAT_THRESHOLD": ask_decimal("OVERHEAT_THRESHOLD"),
        "WAIT_DAYS": ask_wait_days(strategy_defaults.wait_days),
        "ENTRY_SPLIT": ask_entry_split(strategy_defaults.entry_split),
        "ENTRY_SPLIT_OVERHEAT_ACTION": ask_entry_split_overheat_action(
            strategy_defaults.entry_split_overheat_action,
        ),
        "TRADING_SIGNAL_MODE": mode, "SIGNAL_TIME": signal_time,
        "MA_PERIOD": str(strategy_defaults.ma_period),
        "DRAWDOWN_THRESHOLD": str(strategy_defaults.drawdown_threshold),
        "DRAWDOWN_SELL_RATIO": str(strategy_defaults.drawdown_sell_ratio),
        # Milestones are intentionally not wizard questions. Advanced users
        # may edit these explicit defaults in .env after setup.
        "MILESTONE_LEVELS": ",".join(str(level) for level, _ in strategy_defaults.milestones),
        "MILESTONE_SELL_RATIOS": ",".join(str(ratio) for _, ratio in strategy_defaults.milestones),
        "MIN_ORDER_AMOUNT_USD": str(trading_defaults.min_order_amount_usd),
        "CANDLE_LOOKBACK_DAYS": str(trading_defaults.candle_lookback_days),
        "MINUTE_POLLING_INTERVAL_SECONDS": str(minute_defaults.polling_interval_seconds),
        "MINUTE_ORDER_CUTOFF": minute_defaults.order_cutoff,
        "TIMEOUT_SECONDS": str(app_defaults.timeout_seconds),
        "BACKUP_TIME": DEFAULT_BACKUP_TIME,
        "TOSS_CLIENT_ID": input("TOSS_CLIENT_ID: ").strip(), "TOSS_CLIENT_SECRET": getpass("TOSS_CLIENT_SECRET: "),
        "TOSS_API_BASE_URL": input("TOSS_API_BASE_URL [https://openapi.tossinvest.com]: ").strip() or "https://openapi.tossinvest.com",
        "TOSS_ACCOUNT_NO": normalize_toss_account_no(input("TOSS_ACCOUNT_NO: ").strip()) or "",
    }
    if not values["TOSS_CLIENT_ID"] or not values["TOSS_CLIENT_SECRET"] or not values["TOSS_ACCOUNT_NO"]:
        raise ValueError("Toss client credentials and account number are required")
    telegram = ask_yes_no_default_yes("Telegram 알림을 사용하시겠습니까?")
    values["TELEGRAM_ENABLED"] = "true" if telegram else "false"
    values["TELEGRAM_BOT_TOKEN"] = getpass("Telegram Bot Token: ") if telegram else ""
    values["TELEGRAM_ALERT_CHAT_ID"] = input("데이터 및 거래 알림 Chat ID: ").strip() if telegram else ""
    values["TELEGRAM_BACKUP_CHAT_ID"] = input("백업 데이터 Chat ID [Enter = 알림 대화방과 동일]: ").strip() if telegram else ""
    if telegram and not values["TELEGRAM_BOT_TOKEN"]:
        raise ValueError("Telegram 기능에는 Bot Token이 필요합니다.")
    if telegram and not values["TELEGRAM_ALERT_CHAT_ID"]:
        raise ValueError("Telegram 일반 알림에는 TELEGRAM_ALERT_CHAT_ID가 필요합니다.")
    identity_keys = {
        "SIGNAL_SYMBOL", "MAIN_SYMBOL", "OVERHEAT_SYMBOL", "SAFE_SYMBOL", "RISK_THRESHOLD",
        "OVERHEAT_THRESHOLD", "WAIT_DAYS", "ENTRY_SPLIT", "TRADING_SIGNAL_MODE", "SIGNAL_TIME", "TOSS_ACCOUNT_NO",
    }
    if old_values is not None and any(old_values.get(key, "") != values[key] for key in identity_keys):
        if (ROOT / "data" / "state.json").exists() or (ROOT / "data" / "order_ledger.json").exists():
            raise RuntimeError("identity fields changed while approved state/ledger exists; disable/recover then explicitly reinitialize")
    masked = "*" * max(0, len(values["TOSS_ACCOUNT_NO"]) - 3) + values["TOSS_ACCOUNT_NO"][-3:]
    print("\n설치 설정 요약 (민감정보 숨김):")
    for key in ("SIGNAL_SYMBOL", "MAIN_SYMBOL", "OVERHEAT_SYMBOL", "SAFE_SYMBOL", "RISK_THRESHOLD", "OVERHEAT_THRESHOLD", "WAIT_DAYS", "ENTRY_SPLIT", "ENTRY_SPLIT_OVERHEAT_ACTION", "TRADING_SIGNAL_MODE", "SIGNAL_TIME"):
        print(f"{key}: {values[key]}")
    backup_target = "별도 백업 대화방" if values["TELEGRAM_BACKUP_CHAT_ID"] else "알림 대화방과 동일"
    print(f"토스 계좌: {masked}\nTelegram: {'활성' if telegram else '비활성'}\nTelegram 백업: {backup_target if telegram else '비활성'}\n실행 모드: DRY_RUN\n실거래: 비활성")
    if not ask_yes_no("이 설정으로 .env를 생성하시겠습니까?"):
        raise SystemExit("변경된 파일이 없습니다.")
    write_env(values, backup=ENV_PATH.exists())
    print(".env를 권한 0600으로 생성했습니다. 다음 단계는 ./initialize.sh입니다.")


if __name__ == "__main__":
    main()
