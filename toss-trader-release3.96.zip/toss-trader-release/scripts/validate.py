#!/usr/bin/env python3
"""Read-only DRY_RUN installation validation and approval-record writer."""
from decimal import Decimal
from release_common import read_env, runtime_context, write_validation_record


def main() -> None:
    config, broker, adapter, state_store, ledger_store, identity = runtime_context(require_dry=True)
    state = state_store.load_state_strict()
    state_store.assert_installation_identity(state, identity)
    ledger = ledger_store.load_strict()
    if ledger.get("active_workflow"):
        raise RuntimeError("active workflow exists; validation cannot approve an unresolved installation")
    profile = config.resolved_strategy()
    prices = broker.get_prices([profile.main_symbol, profile.overheat_symbol, profile.safe_symbol])
    portfolio = adapter.get_portfolio_state(int(identity["account_seq"]), identity["account_no"], {x["symbol"]: Decimal(str(x["lastPrice"])) for x in prices}, profile.main_symbol, profile.overheat_symbol, profile.safe_symbol)
    state_store.assert_reconciled(state, portfolio, identity)
    broker.get_candles(profile.signal_symbol, interval="1d", count=1, adjusted=True)
    broker.get_us_market_calendar()
    write_validation_record(identity, read_env())
    print("DRY_RUN 검증 통과.\n브로커 주문/변경 API는 호출되지 않았습니다.")


if __name__ == "__main__":
    main()
