"""Refresh only the selected platform's scheduler after configuration."""
from pathlib import Path

try:
    from platform_deploy import install_termux_cron, selected_platform, validate_termux_runtime
    from release_common import ROOT, read_env
except ModuleNotFoundError:
    from scripts.platform_deploy import install_termux_cron, selected_platform, validate_termux_runtime
    from scripts.release_common import ROOT, read_env


def main() -> None:
    platform = selected_platform(ROOT)
    if platform == "linux":
        print("플랫폼: Linux. 기존 systemd scheduler는 변경하지 않았습니다.")
        return
    validate_termux_runtime()
    boot_script = Path.home() / ".termux" / "boot" / "start-toss-trader"
    if not boot_script.exists():
        print("Termux:Boot 시작 스크립트가 없어 거래 자동실행을 활성화하지 않았습니다. setup.sh에서 Termux:Boot 확인 후 구성하세요.")
        return
    values = read_env()
    effective_chat = values.get("TELEGRAM_BACKUP_CHAT_ID", "") or values.get("TELEGRAM_ALERT_CHAT_ID", "")
    backup_enabled = (
        values.get("TELEGRAM_ENABLED", "false").lower() == "true"
        and bool(values.get("TELEGRAM_BOT_TOKEN", ""))
        and bool(effective_chat)
    )
    install_termux_cron(ROOT, values, backup_enabled)
    print("기존 사용자 cron을 보존하고 Toss Trader cron marker block을 한 번만 갱신했습니다.")


if __name__ == "__main__":
    main()
