"""Platform-specific deployment helpers; trading execution stays in run.sh."""
from datetime import datetime, timedelta
from pathlib import Path
import os
import re
import shutil
import subprocess
from config.defaults import DEFAULT_BACKUP_TIME, DEFAULT_CLOSE_EXECUTION_TIME, NY_ZONE, SEOUL_ZONE
from app.runners.minute_timing import scheduler_execution_times

BEGIN = "# BEGIN TOSS-TRADER"
END = "# END TOSS-TRADER"
def _cron_time(value: str, *, next_minute: bool = False) -> tuple[int, int, str]:
    """Return cron minute/hour/weekdays for an NY wall-clock setting."""
    try:
        parsed = datetime.strptime(value, "%H:%M:%S")
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"잘못된 scheduler 시각: {value!r}; HH:MM:SS 형식이어야 합니다.") from exc
    if next_minute:
        original_date = parsed.date()
        parsed += timedelta(minutes=1)
        weekdays = "2-6" if parsed.date() != original_date else "1-5"
    else:
        weekdays = "1-5"
    return parsed.minute, parsed.hour, weekdays


def selected_platform(root: Path) -> str:
    value = os.environ.get("INSTALL_PLATFORM", "").strip() or (root / ".install-platform").read_text(encoding="utf-8").strip()
    if value not in {"linux", "termux"}:
        raise RuntimeError("설치 플랫폼 metadata가 없거나 올바르지 않습니다. setup.sh를 다시 실행하세요.")
    return value


def cron_block(root: Path, values: dict, backup_enabled: bool, backup_time: str = DEFAULT_BACKUP_TIME) -> str:
    root_text = root.as_posix()
    backup_path = "'" + f"{root_text}/backup.sh".replace("'", "'\\''") + "'"
    python_path = "'" + f"{root_text}/.venv/bin/python".replace("'", "'\\''") + "'"
    monitor_path = "'" + f"{root_text}/scripts/check_public_ip.py".replace("'", "'\\''") + "'"
    cron_runner_path = "'" + f"{root_text}/scripts/run_cron.py".replace("'", "'\\''") + "'"
    mode = values.get("TRADING_SIGNAL_MODE", "CLOSE").upper()
    if mode == "MINUTE":
        candidates = scheduler_execution_times(
            values.get("SIGNAL_TIME", ""), timedelta(minutes=1),
        )
        trades = []
        for candidate in candidates:
            minute, hour, weekdays = _cron_time(candidate)
            trades.append(
                f"{minute} {hour} * * {weekdays} {python_path} {cron_runner_path} minute"
            )
    elif mode == "CLOSE":
        # 13:00 covers documented US early-close sessions; the runner reads
        # regularMarket.endTime and exits immediately when that is not today's close.
        trades = [f"0 13,16 * * 1-5 {python_path} {cron_runner_path} close"]
    else:
        raise RuntimeError(f"지원하지 않는 TRADING_SIGNAL_MODE: {mode}")
    lines = [BEGIN, f"CRON_TZ={NY_ZONE}", *trades]
    if backup_enabled:
        hour, minute, _ = backup_time.split(":")
        lines.append(f"{int(minute)} {int(hour)} * * * {backup_path}")
    lines.extend([f"CRON_TZ={SEOUL_ZONE}", f"0 22 * * * {python_path} {monitor_path}"])
    lines.append(END)
    return "\n".join(lines) + "\n"


def replace_marker_block(existing: str, block: str) -> str:
    pattern = re.compile(rf"(?ms)^\s*{re.escape(BEGIN)}\s*$.*?^\s*{re.escape(END)}\s*$\n?")
    preserved = pattern.sub("", existing).rstrip()
    return (preserved + "\n\n" if preserved else "") + block


def install_termux_cron(root: Path, values: dict, backup_enabled: bool, backup_time: str = DEFAULT_BACKUP_TIME) -> None:
    (root / "logs").mkdir(parents=True, exist_ok=True)
    current = ""
    result = subprocess.run(["crontab", "-l"], text=True, capture_output=True)
    if result.returncode == 0:
        current = result.stdout
    elif "no crontab" not in result.stderr.lower():
        raise RuntimeError(f"기존 crontab을 읽지 못했습니다: {result.stderr.strip()}")
    updated = replace_marker_block(current, cron_block(root, values, backup_enabled, backup_time))
    subprocess.run(["crontab", "-"], input=updated, text=True, check=True)


def install_termux_boot(root: Path, home: Path | None = None) -> Path:
    home = home or Path.home()
    target = home / ".termux" / "boot" / "start-toss-trader"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("#!/data/data/com.termux/files/usr/bin/sh\npgrep -x crond >/dev/null 2>&1 || crond\n", encoding="utf-8")
    target.chmod(0o700)
    return target


def validate_termux_runtime() -> None:
    prefix = os.environ.get("PREFIX", "")
    if not (prefix.startswith("/data/data/com.termux/") or re.match(r"/data/user/\d+/com\.termux/", prefix)):
        raise RuntimeError("실제 Termux 환경이 아닙니다. 설치를 안전하게 중단합니다.")
    for command in ("crontab", "crond"):
        if not shutil.which(command):
            raise RuntimeError(f"필수 Termux 명령을 찾을 수 없습니다: {command}")
