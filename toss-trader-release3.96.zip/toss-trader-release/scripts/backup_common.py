#!/usr/bin/env python3
"""Secret-free, lock-consistent application-state backup primitives."""
import hashlib
import json
import os
import shutil
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from version import RELEASE_VERSION

FORMAT_VERSION = 1
REQUIRED_MEMBERS = {"state.json", "order_ledger.json", "manifest.json"}
OPTIONAL_MEMBERS = {"dry_run_validation.json"}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def masked_account(value: str) -> str:
    return "*" * max(0, len(value) - 3) + value[-3:]


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-UTC")


def enforce_clean_checkpoint(result: object, notifier: object, workflow_id: str) -> None:
    """Stop archive creation unless reconciliation produced a safe checkpoint."""
    outcome = getattr(result, "outcome", None)
    message = str(getattr(result, "message", ""))
    if outcome in {"ABORTED", "DRY_RUN_CLEARED"}:
        notifier.notify_warning(f"Pre-backup workflow {workflow_id} safely closed: {message}")
        return
    if outcome == "BLOCKED":
        notifier.notify_warning(
            f"Clean backup blocked; workflow {workflow_id} remains active: {message}"
        )
        raise RuntimeError(
            f"clean backup blocked; active workflow {workflow_id} was not safely terminal: {message}"
        )
    raise RuntimeError(
        f"clean backup blocked; workflow {workflow_id} returned unexpected reconciliation outcome: {outcome}"
    )


def snapshot_under_process_lock() -> Tuple[Dict[str, bytes], Dict[str, object]]:
    """Read both durable files while holding the trading ProcessLock."""
    from config.config import AppConfig
    from app.storage import OrderLedgerStore, ProcessLock, StateStore
    from app.execution import WorkflowReconciler
    from app.notification import TelegramNotifier

    os.chdir(ROOT)
    config = AppConfig.load()
    state_store = StateStore(config.storage.state_file)
    ledger_store = OrderLedgerStore(config.storage.order_ledger_file)
    with ProcessLock(config.storage.process_lock_file):
        state = state_store.load_state_strict()
        ledger = ledger_store.load_strict()
        identity = state.get("installation_identity")
        if not isinstance(identity, dict):
            raise RuntimeError("state.json lacks approved installation identity")
        active = ledger.get("active_workflow")
        if active:
            workflow_id = str(active.get("workflow_id", "unknown"))
            workflow_orders = [
                order for order in ledger.get("orders", [])
                if order.get("workflow_id") == workflow_id
            ]
            broker = None
            if workflow_orders and active.get("execution_mode") != "DRY_RUN":
                from app.api import TossAPIClient, TossAuthManager, TossBrokerAPI
                from app.portfolio import PortfolioAdapter

                auth = TossAuthManager(
                    config.toss_api_base_url, config.toss_client_id,
                    config.toss_client_secret, config.timeout_seconds,
                )
                client = TossAPIClient(
                    config.toss_api_base_url, auth,
                    timeout_seconds=config.timeout_seconds,
                )
                broker = TossBrokerAPI(client)
                adapter = PortfolioAdapter(broker, client)
                account_seq = adapter.resolve_account_seq(config.toss_account_no)
                current_identity = config.resolved_strategy().installation_identity(
                    config.signal_mode, config.toss_account_no or "", account_seq,
                )
                state_store.assert_installation_identity(state, current_identity)
                state_store.assert_identity_values(
                    active.get("installation_identity") or {}, current_identity,
                )

            result = WorkflowReconciler(ledger_store, broker).pre_backup_cleanup()
            notifier = TelegramNotifier(
                config.telegram_bot_token, config.telegram_chat_id, config.telegram_enabled,
            )
            enforce_clean_checkpoint(result, notifier, workflow_id)
            ledger_store.load_strict()

        files = {
            "state.json": state_store.state_file_path.read_bytes(),
            "order_ledger.json": ledger_store.path.read_bytes(),
        }
        validation = ROOT / "data" / "dry_run_validation.json"
        if validation.exists():
            files["dry_run_validation.json"] = validation.read_bytes()
    return files, identity


def build_archive(output_dir: Path) -> Tuple[Path, Dict[str, object]]:
    """Create one archive from a single lock-protected state/ledger snapshot."""
    files, identity = snapshot_under_process_lock()
    timestamp = datetime.now(timezone.utc).isoformat()
    account_no = str(identity.get("account_no", ""))
    if not account_no:
        raise RuntimeError("installation identity has no account number")
    manifest = {
        "backup_format_version": FORMAT_VERSION,
        "backup_timestamp_utc": timestamp,
        "installation_identity_hash": sha256_bytes(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()),
        "account_hash": sha256_bytes(account_no.encode()),
        "account_masked": masked_account(account_no),
        "release_version": RELEASE_VERSION,
        "included_files": {name: sha256_bytes(contents) for name, contents in sorted(files.items())},
    }
    archive = output_dir / f"toss-trader-backup-{utc_stamp()}.tar.gz"
    with tarfile.open(archive, "w:gz") as bundle:
        for name, contents in files.items():
            path = output_dir / name
            path.write_bytes(contents)
            bundle.add(path, arcname=name, recursive=False)
        manifest_path = output_dir / "manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        bundle.add(manifest_path, arcname="manifest.json", recursive=False)
    return archive, manifest


def verify_archive(archive: Path) -> Tuple[Dict[str, bytes], Dict[str, object]]:
    """Reject malformed, secret-bearing, or checksum-invalid backup bundles."""
    try:
        with tarfile.open(archive, "r:gz") as bundle:
            members = bundle.getmembers()
            names = {member.name for member in members}
            if names != REQUIRED_MEMBERS and names != REQUIRED_MEMBERS | OPTIONAL_MEMBERS:
                raise RuntimeError("backup archive has unexpected or missing members")
            if any(not member.isfile() or Path(member.name).name != member.name for member in members):
                raise RuntimeError("backup archive has unsafe member structure")
            contents = {name: bundle.extractfile(name).read() for name in names}
    except (tarfile.TarError, OSError) as exc:
        raise RuntimeError(f"backup archive is corrupted: {exc}") from exc
    try:
        manifest = json.loads(contents.pop("manifest.json").decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"backup manifest is unreadable: {exc}") from exc
    if not isinstance(manifest, dict) or manifest.get("backup_format_version") != FORMAT_VERSION:
        raise RuntimeError("backup manifest has unsupported format")
    listed = manifest.get("included_files")
    if not isinstance(listed, dict) or set(listed) != set(contents):
        raise RuntimeError("backup manifest file list mismatch")
    if any(sha256_bytes(contents[name]) != digest for name, digest in listed.items()):
        raise RuntimeError("backup archive SHA256 verification failed")
    return contents, manifest


def validate_restore_identity(state: Dict[str, object], manifest: Dict[str, object], expected_identity: Dict[str, str], configured_account_no: str) -> None:
    """Require both durable installation identity and configured account match."""
    from app.storage import StateStore

    StateStore.assert_installation_identity(state, expected_identity)
    identity = state.get("installation_identity")
    actual_hash = sha256_bytes(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode())
    if manifest.get("installation_identity_hash") != actual_hash:
        raise RuntimeError("backup manifest installation identity mismatch")
    if manifest.get("account_hash") != sha256_bytes(configured_account_no.encode()):
        raise RuntimeError("backup account identity mismatch")


def atomic_place_pair(state_path: Path, ledger_path: Path, files: Dict[str, bytes], allow_overwrite: bool = False) -> None:
    """Place validated state/ledger atomically per file, with rollback on failure."""
    if state_path.exists() or ledger_path.exists():
        if not allow_overwrite:
            raise RuntimeError("state or ledger already exists; refusing automatic overwrite")
    state_path.parent.mkdir(parents=True, exist_ok=True)
    ledger_path.parent.mkdir(parents=True, exist_ok=True)
    originals = {state_path: state_path.read_bytes() if state_path.exists() else None, ledger_path: ledger_path.read_bytes() if ledger_path.exists() else None}
    temporary = {}
    try:
        for target, key in ((state_path, "state.json"), (ledger_path, "order_ledger.json")):
            temp = target.with_suffix(target.suffix + ".restore-tmp")
            with open(temp, "wb") as handle:
                handle.write(files[key])
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temp, 0o600)
            temporary[target] = temp
        os.replace(temporary[state_path], state_path)
        os.replace(temporary[ledger_path], ledger_path)
        os.chmod(state_path, 0o600)
        os.chmod(ledger_path, 0o600)
    except Exception:
        for target, original in originals.items():
            if original is None:
                target.unlink(missing_ok=True)
            else:
                rollback = target.with_suffix(target.suffix + ".rollback-tmp")
                rollback.write_bytes(original)
                os.replace(rollback, target)
        raise
    finally:
        for temp in temporary.values():
            temp.unlink(missing_ok=True)
