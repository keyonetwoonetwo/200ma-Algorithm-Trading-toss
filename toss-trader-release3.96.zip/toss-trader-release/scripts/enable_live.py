#!/usr/bin/env python3
"""Explicit, account-bound LIVE promotion. No secret is printed or modified."""

import json

from release_common import (
    ENV_PATH,
    VALIDATION_PATH,
    identity_hash,
    read_env,
    runtime_context,
    write_env,
)


SPEC_ACK = "주문 접수가 체결을 의미하지 않음을 이해했습니다"
LIVE_ACK = "실거래를 활성화합니다"


def main() -> None:
    values = read_env()

    if (
        values.get("EXECUTION_MODE") != "DRY_RUN"
        or values.get("LIVE_TRADING_ENABLED", "false").lower() != "false"
    ):
        raise RuntimeError(
            "LIVE 전환은 현재 EXECUTION_MODE=DRY_RUN 및 "
            "LIVE_TRADING_ENABLED=false 상태에서만 가능합니다."
        )

    if not VALIDATION_PATH.exists():
        raise RuntimeError(
            "DRY_RUN 검증 기록이 없습니다. 먼저 ./validate.sh를 실행하세요."
        )

    record = json.loads(
        VALIDATION_PATH.read_text(encoding="utf-8")
    )

    (
        config,
        broker,
        adapter,
        state_store,
        ledger_store,
        identity,
    ) = runtime_context(require_dry=True)

    if (
        record.get("result") != "PASS"
        or record.get("execution_mode") != "DRY_RUN"
        or record.get("live_trading_enabled") is not False
    ):
        raise RuntimeError("DRY_RUN 검증 기록이 올바르지 않습니다.")

    if (
        record.get("identity_hash") != identity_hash(identity)
        or record.get("account_no") != identity["account_no"]
        or record.get("account_seq") != identity["account_seq"]
    ):
        raise RuntimeError(
            "DRY_RUN 검증 기록과 현재 installation/account identity가 일치하지 않습니다."
        )

    state = state_store.load_state_strict()
    state_store.assert_installation_identity(state, identity)

    ledger = ledger_store.load_strict()
    if ledger.get("active_workflow") or any(
        order.get("status")
        in {"UNKNOWN", "PARTIAL_FILLED_BLOCKED"}
        for order in ledger.get("orders", [])
    ):
        raise RuntimeError(
            "ledger에 active workflow, UNKNOWN 또는 PARTIAL_FILLED_BLOCKED 데이터가 있습니다. "
            "안전을 위해 LIVE 전환을 중단합니다. 파일을 임의로 수정하거나 재주문하지 말고 먼저 복구 절차를 수행하세요."
        )

    profile = config.resolved_strategy()

    masked = (
        "*" * max(0, len(identity["account_no"]) - 3)
        + identity["account_no"][-3:]
    )

    print(
        f"계좌: {masked}\n"
        f"신호/메인/과열/안전자산: "
        f"{profile.signal_symbol}/"
        f"{profile.main_symbol}/"
        f"{profile.overheat_symbol}/"
        f"{profile.safe_symbol}\n"
        f"실행 방식: {config.signal_mode}\n신호 시각: {profile.signal_time} America/New_York"
    )

    # Only warn about the execution path this installation will actually use.
    if config.signal_mode == "MINUTE":
        print(
            "\n[주의]\nMINUTE ±0.1% 지정가 주문이 토스증권 실계좌에서 실제 접수되는지는 "
            "현재 제공된 API 명세만으로 완전히 보장되지 않습니다."
        )
        print(
            "첫 LIVE 실행이 이 주문 경로의 최초 실계좌 검증이 될 수 있습니다."
        )

    elif config.signal_mode == "CLOSE":
        print(
            "\n[주의]\nCLOSE 애프터마켓 주문이 토스증권 실계좌에서 실제 접수되는지는 "
            "현재 제공된 API 명세만으로 완전히 보장되지 않습니다."
        )
        print(
            "첫 LIVE 실행이 이 주문 경로의 최초 실계좌 검증이 될 수 있습니다."
        )

    else:
        raise RuntimeError(
            f"unsupported TRADING_SIGNAL_MODE for LIVE promotion: "
            f"{config.signal_mode}"
        )

    print(
        "\nLIVE에서는 실제 토스증권 계좌에 주문이 전송됩니다."
        "\n기존 workflow/ledger/state/체결 확인/UNKNOWN 안전장치는 그대로 적용됩니다."
    )

    if input(
        f"\n계속하려면 다음 문구를 정확히 입력하세요:\n{SPEC_ACK}\n> "
    ).strip() != SPEC_ACK:
        raise SystemExit("LIVE 전환이 취소되었습니다.")

    if input(
        f"실거래를 활성화하려면 다음 문구를 정확히 입력하세요:\n{LIVE_ACK}\n> "
    ).strip() != LIVE_ACK:
        raise SystemExit("LIVE 전환이 취소되었습니다.")

    values["EXECUTION_MODE"] = "LIVE"
    values["LIVE_TRADING_ENABLED"] = "true"

    write_env(values, backup=True)

    print(
        "LIVE가 활성화되었습니다.\n기존 .env는 백업되었습니다.\n민감정보는 화면에 출력되지 않았습니다."
    )


if __name__ == "__main__":
    main()
