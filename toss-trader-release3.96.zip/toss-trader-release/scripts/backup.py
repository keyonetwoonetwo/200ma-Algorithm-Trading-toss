#!/usr/bin/env python3
"""Create the existing archive and send it only to the Telegram backup chat."""
import os
import tempfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import requests

try:
    from backup_common import ROOT, build_archive, sha256_bytes
    from release_common import read_env
except ModuleNotFoundError:
    from scripts.backup_common import ROOT, build_archive, sha256_bytes
    from scripts.release_common import read_env
from config.defaults import NY_ZONE


def send_backup_document(path: Path, token: str, chat_id: str, caption: str, post=requests.post, timeout: int = 60) -> None:
    if not token or not chat_id:
        raise RuntimeError("Telegram Bot Token 또는 유효한 백업 대상 Chat ID가 없습니다.")
    try:
        with path.open("rb") as document:
            response = post(
                f"https://api.telegram.org/bot{token}/sendDocument",
                data={"chat_id": chat_id, "caption": caption},
                files={"document": (path.name, document, "application/gzip")},
                timeout=timeout,
            )
        response.raise_for_status()
        payload = response.json()
        if payload.get("ok") is not True:
            raise RuntimeError("Telegram API가 ok=true를 반환하지 않았습니다.")
    except Exception as exc:
        # Never include the request URL: it contains the bot token.
        raise RuntimeError(f"Telegram sendDocument 실패: {type(exc).__name__}") from None


def notify_upload_failure(values: dict) -> None:
    try:
        from app.notification import TelegramNotifier
        notifier = TelegramNotifier(
            values.get("TELEGRAM_BOT_TOKEN", ""),
            values.get("TELEGRAM_ALERT_CHAT_ID", ""),
            values.get("TELEGRAM_ENABLED", "false").lower() == "true",
        )
        notifier.send_message("백업 파일 생성은 완료되었지만 Telegram 백업 전송에 실패했습니다.")
    except Exception:
        pass


def resolve_backup_destination(values: dict) -> tuple[str, str] | None:
    enabled = values.get("TELEGRAM_ENABLED", "false").lower() == "true"
    token = values.get("TELEGRAM_BOT_TOKEN", "")
    chat_id = values.get("TELEGRAM_BACKUP_CHAT_ID", "") or values.get("TELEGRAM_ALERT_CHAT_ID", "")
    return (token, chat_id) if enabled and token and chat_id else None


def main() -> None:
    values = read_env()
    destination = resolve_backup_destination(values)
    if destination is None:
        print("Telegram이 비활성화되었거나 필수 설정이 없어 백업 전송을 실행하지 않습니다.")
        return
    token, backup_chat_id = destination
    output_dir = ROOT / "data" / "backups"
    output_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".toss-trader-backup-build-",dir=output_dir,) as directory:
        built, _ = build_archive(Path(directory))
        archive = output_dir / built.name
        os.replace(built, archive)
    digest = sha256_bytes(archive.read_bytes())
    caption_time = datetime.now(ZoneInfo(NY_ZONE)).strftime(f"%Y-%m-%d %H:%M {NY_ZONE}")
    caption = f"Toss Trader 자동 백업\n{caption_time}"
    try:
        send_backup_document(
            archive,
            token,
            backup_chat_id,
            caption,
        )
    except Exception:
        notify_upload_failure(values)
        print(f"백업 파일은 로컬에 유지했습니다: {archive}")
        raise
    print(f"Telegram 백업 전송 완료: {archive.name} sha256={digest}")


if __name__ == "__main__":
    main()
