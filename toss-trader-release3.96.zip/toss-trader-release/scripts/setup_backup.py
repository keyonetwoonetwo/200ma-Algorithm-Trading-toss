#!/usr/bin/env python3
"""Configure the Telegram backup chat without exposing the bot token."""
from getpass import getpass

try:
    from release_common import read_env, write_env
except ModuleNotFoundError:
    from scripts.release_common import read_env, write_env


def main() -> None:
    values = read_env()
    token = values.get("TELEGRAM_BOT_TOKEN", "")
    if not token:
        token = getpass("Telegram Bot Token: ").strip()
    alert_chat_id = values.get("TELEGRAM_ALERT_CHAT_ID", "") or input("데이터 및 거래 알림 Chat ID: ").strip()
    chat_id = input("백업 데이터 Chat ID [Enter = 알림 대화방과 동일]: ").strip()
    if not token or not alert_chat_id:
        raise SystemExit("TELEGRAM_BOT_TOKEN과 TELEGRAM_ALERT_CHAT_ID가 필요합니다.")
    values["TELEGRAM_BOT_TOKEN"] = token
    values["TELEGRAM_ALERT_CHAT_ID"] = alert_chat_id
    values["TELEGRAM_BACKUP_CHAT_ID"] = chat_id
    values["TELEGRAM_ENABLED"] = "true"
    write_env(values, backup=True)
    print("Telegram 백업 설정을 저장했습니다. 백업 Chat ID가 비어 있으면 알림 대화방을 사용합니다. Bot Token은 화면에 출력하지 않았습니다.")


if __name__ == "__main__":
    main()
