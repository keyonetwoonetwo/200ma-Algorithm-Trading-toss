# Telegram 백업과 복구

## 백업 목적

Toss Trader 백업은 단순한 데이터 보관이 아니라 장애 후 기존 전략 cycle, state와 workflow를 검증된 상태로 이어서 복구하기 위한 것입니다.

## 백업 파일 내용

동일한 `tar.gz` 포맷을 Linux와 Termux에서 사용합니다. 정상 설치에서 archive에는 다음 파일이 들어갑니다.

- `state.json`
- `order_ledger.json`
- `dry_run_validation.json`
- `manifest.json`

## 포함되지 않는 민감정보

`.env`, API Client Secret, Telegram Bot Token, OAuth token과 기타 인증정보는 포함하지 않습니다. 다만 state와 ledger에는 계좌 상태와 installation identity 같은 운영 데이터가 있으므로 백업 파일 자체를 공개 파일로 취급하면 안 됩니다.

## Telegram 백업 대화방 만들기

1. Telegram에서 새 그룹을 만들고 비공개로 유지합니다.
2. 기존 Toss Trader 봇을 그룹에 추가합니다.
3. 그룹에서 메시지 하나를 보냅니다.
4. Bot API `getUpdates` 등으로 그룹 Chat ID를 확인합니다. supergroup ID는 보통 `-100...` 형식입니다.
5. 백업 대화방을 분리하려면 해당 값을 `TELEGRAM_BACKUP_CHAT_ID`로 설정합니다.

Bot Token을 문서, 공개 채팅 또는 화면 공유에 붙여 넣지 마십시오.

권장 구성은 데이터·거래 알림은 개인 대화방, 백업 데이터는 비공개 Telegram 그룹으로 분리하는 것입니다. 분리를 원하면 그룹 ID를 `TELEGRAM_BACKUP_CHAT_ID`에 입력합니다. 별도 백업방을 만들지 않으려면 이 값을 비워 두십시오. 백업 tar.gz가 자동으로 `TELEGRAM_ALERT_CHAT_ID`로 전송됩니다.

Telegram을 사용하지 않으면 `TELEGRAM_ENABLED=false`로 둡니다. 일반 알림과 백업 전송만 비활성화되며 거래에는 영향이 없습니다.

## 자동 백업 흐름

```text
scheduler
→ backup.sh
→ active workflow broker reconciliation
→ zero-fill 주문은 cancel 후 CANCELED 확인 / 불명확하면 clean backup 중단
→ 기존 tar.gz 생성 및 manifest/hash 작성
→ Telegram sendDocument
→ 별도 백업 대화방 또는 알림 대화방
```

Linux systemd timer와 Termux cron은 기존 시간대와 백업 시각을 유지합니다.

안전하게 종료된 workflow는 `order_ledger.json`의 `workflow_history`에 `ABORTED_PRE_BACKUP`, `ABORTED_NO_FILL` 또는 `ABORTED_DRY_RUN` 이력과 확인 결과를 남긴 뒤 `active_workflow`만 비웁니다. DRY_RUN은 simulated ledger만 정리하고 전략 state를 advance하지 않습니다. PARTIAL, UNKNOWN, 취소 미확정 또는 broker 조회 실패는 active 상태를 유지하고 Telegram 경고 후 정상 백업을 만들지 않습니다.

## 운영자 workflow reconciliation

```bash
./reconcile-workflow.sh
```

이 명령은 persisted `broker_order_id`로 모든 주문 상세와 MAIN/OVERHEAT/SAFE/USD cash를 다시 조회합니다. 전량체결이 확인되고 모든 step이 끝난 workflow만 기존 conditional state commit 경로로 완료하며, zero-fill terminal 주문만 abort history를 남기고 종료합니다. PARTIAL/UNKNOWN/조회 실패는 추정하지 않고 active 상태로 보존합니다. `state.json`이나 `order_ledger.json`을 직접 수정하지 마십시오.

## 복구 방법

### 새 서버 장애 복구 및 scheduler 재구성

setup이 기존 MAIN/OVERHEAT 보유 때문에 fresh initialize를 거부한 새 Linux/Termux 환경에서는 다음을 사용합니다.

```bash
./recover_backup.sh /path/to/toss-trader-backup-YYYYMMDD-HHMMSS-UTC.tar.gz
```

backup과 현재 `.env`의 `TRADING_SIGNAL_MODE` 또는 `SIGNAL_TIME`이 다르면 `[1] 전략 상태만 복구`와 `[2] 전략 상태 + 거래방식 복구` 중 하나를 선택합니다. `[1]`은 현재 `.env`의 CLOSE/MINUTE와 시각을 그대로 유지합니다. `[2]`는 backup의 두 값을 단일 `.env`에 자동 반영합니다. scheduler는 reconcile 성공 후 최종 선택값으로만 구성됩니다. 두 선택 모두 계좌번호, accountSeq와 SIGNAL/MAIN/OVERHEAT/SAFE 심볼은 반드시 일치해야 합니다.

archive hash와 3.91-compatible schema, protected identity를 검증하고 현재 인증정보로 Toss account/portfolio/persisted order를 다시 조회합니다. 임시 state/ledger에서 reconcile과 consistency 검사가 모두 성공한 후에만 실제 파일을 교체하고 scheduler를 구성합니다. PARTIAL, UNKNOWN, 주문조회 실패 또는 portfolio mismatch는 fail-closed이며 scheduler를 만들지 않습니다. 복구 중 주문 생성 및 취소 API는 호출하지 않습니다. `[2]`의 `.env` 반영 이후 어떤 단계라도 실패하면 `.env`도 복구 전 내용으로 rollback합니다.

기존 local state/ledger가 있으면 `data/pre-recovery-local-*-UTC/`에 보존합니다. 이후 실패하면 실제 pair와 기존 scheduler 상태를 rollback합니다.

### 일반 파일 복원

1. Telegram 백업 대화방에서 최신 `tar.gz`를 직접 다운로드합니다.
2. 파일을 Linux 서버 또는 Termux로 복사합니다.
3. `./restore.sh /path/to/toss-trader-backup-YYYYMMDD-HHMMSS-UTC.tar.gz`를 실행합니다.
4. manifest, hash, account/install identity, state와 ledger 검증이 완료된 뒤 `./validate.sh`를 실행하고 운영을 재개합니다.

자동 Telegram 다운로드 기능은 없습니다.

## 백업 실패 시

Telegram 전송 실패는 trading state, ledger 또는 workflow를 변경하거나 거래를 차단하지 않습니다. 생성된 archive는 `data/backups/`에 남기므로 수동 전송과 복구에 사용할 수 있습니다. 일반 alert 대화방 설정이 활성화되어 있으면 짧은 실패 알림도 시도하며, 그 알림까지 실패하면 로그만 남깁니다.
