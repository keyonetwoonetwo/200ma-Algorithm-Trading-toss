#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
.venv/bin/python "$ROOT/scripts/configure.py"
exec .venv/bin/python "$ROOT/scripts/configure_scheduler.py"
