# Release 3.96

- MINUTE의 `SIGNAL_TIME`을 정규장 16:00 기준 상대 시각으로 해석해 Toss calendar의 실제 `regularMarket.endTime`이 13:00인 조기폐장일에는 동일 offset의 분봉을 사용합니다.
- polling 시작과 `MINUTE_ORDER_CUTOFF`도 실제 종료시각만큼 함께 이동하며, 계산된 창이 실제 정규장 범위를 벗어나면 fail-closed합니다.
- Linux systemd와 Termux cron의 MINUTE scheduler는 13:00 조기폐장 및 16:00 정상장 후보에 모두 runner를 호출합니다. runner가 실제 Toss calendar와 맞지 않는 호출을 no-op 처리합니다.
- 실제 effective signal time과 admission/new-leg deadline을 workflow policy에 저장해 resume 시 생성 당시 의미를 유지합니다.
- CLOSE, 전략 우선순위, 주문가격 ±0.1%, workflow/ledger 및 backup/recovery 로직은 변경하지 않았습니다.

# Release 3.95

- MAIN 구간의 ACTIVE ENTRY_SPLIT 실행에서 당일 tranche reserve와 별도로 확인된 NEW_CASH를 같은 실행의 독립 MAIN 주문으로 처리합니다.
- tranche budget과 NEW_CASH budget은 합산하지 않으며 각각 `BUY_ENTRY_TRANCHE`와 `BUY_NEW_CASH_MAIN` workflow step으로 저장합니다.
- NEW_CASH 체결액은 split reserve 차감이나 tranche count에 포함하지 않고, 하루 한 tranche라는 기존 진행 규칙을 유지합니다.
- 두 MAIN 주문은 3.94의 `HASH_V2`로 서로 다른 36자 이하 `clientOrderId`를 사용하며 resume 시 각각 독립적으로 멱등 처리됩니다.
- Overheat + ACTION=MAIN의 MAIN tranche/OVERHEAT NEW_CASH 동작 및 SAFE/OVERHEAT 종료 동작은 그대로 유지됩니다.
- Risk-Off, Drawdown, Milestone 우선순위와 주문가격·신호·backup/recovery/scheduler 로직은 변경하지 않았습니다.

# Release 3.94

- Toss OpenAPI의 `clientOrderId` 최대 36자 제한은 유지하면서, 긴 workflow의 주문 leg가 단순 절단으로 사라지지 않도록 결정적 hash suffix 방식(`HASH_V2`)을 도입했습니다.
- `ENTRY_SPLIT_OVERHEAT_ACTION=MAIN`에서 MAIN tranche와 별도 NEW_CASH OVERHEAT 주문이 같은 `clientOrderId`로 충돌하던 경로를 수정했습니다.
- 새 ID는 최대 36자와 영숫자/`-`/`_` 패턴을 지키며 workflow와 leg가 같으면 항상 동일하고, leg가 다르면 구분됩니다.
- 기존 active workflow는 persisted intent ID를 override로 보존합니다. intent-before-submit으로 미제출이 확정된 누락 step만 새 ID를 사용하며, 잘못 앞서간 `next_index`를 durable intent 기준으로 복구합니다.
- 기존 주문 연결이 비연속적이거나 불명확하면 자동 변환하지 않고 fail-closed합니다.
- 전략 판단, 예산·수량·가격, CLOSE/MINUTE, ledger exactly-once 및 broker reconciliation 정책은 변경하지 않았습니다.

# Release 3.93

- 장애 복구에서 backup과 현재 `.env`의 CLOSE/MINUTE 또는 `SIGNAL_TIME`이 다를 때 복구 범위를 선택할 수 있습니다.
- `[1]`은 현재 거래방식을 유지하며 복원 state의 identity만 안전하게 현재 값으로 migration합니다.
- `[2]`는 backup 거래방식을 단일 `.env`에 원자 반영하고 최종 선택값으로 scheduler를 재구성합니다.
- 계좌/accountSeq/역할 심볼은 두 선택 모두 기존처럼 fail-closed이며, 일반 실행의 protected identity 정책은 바뀌지 않습니다.
- `.env`, state/ledger 또는 scheduler 단계가 실패하면 복구 전 상태로 rollback합니다.
- 전략 엔진, 주문, 신호 계산 및 3.91-compatible backup 포맷은 변경하지 않았습니다.

# Release 3.92

- 새 Linux/Termux에서 검증된 기존 backup으로 state/ledger, 현재 Toss reconciliation 및 scheduler를 복구하는 `recover_backup.sh`를 추가했습니다.
- 복구는 DRY_RUN/비활성 LIVE에서만 가능하며 신규 주문·취소 API를 호출하지 않습니다.
- PARTIAL, UNKNOWN, order lookup 실패, identity/portfolio mismatch는 실제 파일 교체와 scheduler 설치 전에 차단됩니다.
- 기존 local pair와 scheduler는 실패 시 rollback하며, local pair의 별도 안전 사본도 남깁니다.
- 기존 3.91 backup format version 1과 legacy identity hash 검증을 그대로 지원합니다.
- 전략, workflow 실행, MINUTE/CLOSE 및 고정 ±0.1% 주문가격 로직은 변경하지 않았습니다.

# Release 3.91

- `ENTRY_SPLIT_OVERHEAT_ACTION`에 `MAIN`을 추가했습니다. 기본값은 계속 `SAFE`입니다.
- MAIN은 Overheat에서도 기존 ACTIVE split reserve만 원래 tranche 일정대로 MAIN에 계속 배분합니다.
- ACTIVE reserve를 초과한 신규 현금은 별도 OVERHEAT order step으로 저장하며 split reserve에 합치지 않습니다.
- Risk-Off, Drawdown, Milestone 우선순위와 SAFE/OVERHEAT terminal 동작은 유지됩니다.
- 이미 생성된 workflow는 persisted budget, destination 및 order step을 사용합니다.
- MINUTE/CLOSE에 공통인 전략 변경이며 고정 ±0.1% slippage와 가격 정규화는 변경하지 않았습니다.

# Release 3.90

- installation identity를 계좌번호/accountSeq, 역할 심볼, 신호모드, 신호시각으로 축소했습니다.
- 3.80 state/workflow의 기존 tuning identity 필드는 보존하되 비교에서 제외해 수동 migration 없이 호환됩니다.
- threshold, wait, split, MA, drawdown, milestone 및 운영 파라미터는 `.env`의 runtime 설정으로 다음 새 판단부터 적용됩니다.
- ACTIVE ENTRY_SPLIT은 저장된 total/reserve/progress를 유지하고 새 `ENTRY_SPLIT`은 다음 cycle부터 사용합니다.
- 기존 workflow의 저장된 step, 목적지, pending transition은 runtime 설정 변경으로 재해석하지 않습니다.
- 주문 slippage는 3.80의 고정 ±0.1%와 가격 정규화를 그대로 유지합니다.

# Release 3.80

- CLOSE 주문 LIMIT 가격을 기존 MINUTE와 동일하게 적용합니다: BUY는 주문 종목의 현재 execution 가격 × 1.001, SELL은 × 0.999.
- 기존 미국주식 가격 정규화(1달러 미만 소수점 4자리, 이상 2자리 절삭)를 유지합니다.
- BUY는 최종 LIMIT 가격 기준 예산 내 정수 수량을 계산하므로 수량이 감소할 수 있습니다. SELL 전략 결정 수량은 유지합니다.
- 1주도 살 수 없는 경우 기존 최소주문/0주 처리 정책을 유지합니다.
- 전략 신호, TIF, workflow/state/ledger, fail-closed 정책은 변경하지 않습니다. 정규장 종료 후 주문 접수는 broker 제한을 따르며 보장되지 않습니다.
- 별도의 ORDER_SLIPPAGE_PCT 설정은 추가하지 않았으며, 두 모드 모두 기존 MINUTE의 고정 0.1%를 사용합니다.
- 기존 state/ledger의 수동 수정 또는 migration은 필요하지 않습니다.
