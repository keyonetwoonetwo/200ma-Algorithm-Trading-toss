# Release 3.93

- 장애 복구에서 backup과 현재 `.env`의 CLOSE/MINUTE 또는 `SIGNAL_TIME`이 다를 때 복구 범위를 선택할 수 있습니다.
- `[1]`은 현재 거래방식을 유지하며 복원 state의 identity만 안전하게 현재 값으로 migration합니다.
- `[2]`는 backup 거래방식을 단일 `.env`에 원자 반영하고 최종 선택값으로 scheduler를 재구성합니다.
- 계좌/accountSeq/역할 심볼은 두 선택 모두 기존처럼 fail-closed이며, 일반 실행의 protected identity 정책은 바뀌지 않습니다.
- `.env`, state/ledger 또는 scheduler 단계가 실패하면 복구 전 상태로 rollback합니다.
- 전략 엔진, 주문, 신호 계산 및 3.91-compatible backup 포맷은 변경하지 않았습니다.

# Release 3.92

- 새 Linux/Termux에서 검증된 기존 backup으로 state/ledger, 현재 Toss reconciliation 및 scheduler를 복구하는 `recover_backup.sh`를 추가했습니다.
- 복구는 DRY_RUN/비활성 LIVE에서만 가능하며 신규 주문·취소 API를 호출하지 않습니다.
- PARTIAL, UNKNOWN, order lookup 실패, identity/portfolio mismatch는 실제 파일 교체와 scheduler 설치 전에 차단됩니다.
- 기존 local pair와 scheduler는 실패 시 rollback하며, local pair의 별도 안전 사본도 남깁니다.
- 기존 3.91 backup format version 1과 legacy identity hash 검증을 그대로 지원합니다.
- 전략, workflow 실행, MINUTE/CLOSE 및 고정 ±0.1% 주문가격 로직은 변경하지 않았습니다.

# Release 3.91

- `ENTRY_SPLIT_OVERHEAT_ACTION`에 `MAIN`을 추가했습니다. 기본값은 계속 `SAFE`입니다.
- MAIN은 Overheat에서도 기존 ACTIVE split reserve만 원래 tranche 일정대로 MAIN에 계속 배분합니다.
- ACTIVE reserve를 초과한 신규 현금은 별도 OVERHEAT order step으로 저장하며 split reserve에 합치지 않습니다.
- Risk-Off, Drawdown, Milestone 우선순위와 SAFE/OVERHEAT terminal 동작은 유지됩니다.
- 이미 생성된 workflow는 persisted budget, destination 및 order step을 사용합니다.
- MINUTE/CLOSE에 공통인 전략 변경이며 고정 ±0.1% slippage와 가격 정규화는 변경하지 않았습니다.

# Release 3.90

- installation identity를 계좌번호/accountSeq, 역할 심볼, 신호모드, 신호시각으로 축소했습니다.
- 3.80 state/workflow의 기존 tuning identity 필드는 보존하되 비교에서 제외해 수동 migration 없이 호환됩니다.
- threshold, wait, split, MA, drawdown, milestone 및 운영 파라미터는 `.env`의 runtime 설정으로 다음 새 판단부터 적용됩니다.
- ACTIVE ENTRY_SPLIT은 저장된 total/reserve/progress를 유지하고 새 `ENTRY_SPLIT`은 다음 cycle부터 사용합니다.
- 기존 workflow의 저장된 step, 목적지, pending transition은 runtime 설정 변경으로 재해석하지 않습니다.
- 주문 slippage는 3.80의 고정 ±0.1%와 가격 정규화를 그대로 유지합니다.

# Release 3.80

- CLOSE 주문 LIMIT 가격을 기존 MINUTE와 동일하게 적용합니다: BUY는 주문 종목의 현재 execution 가격 × 1.001, SELL은 × 0.999.
- 기존 미국주식 가격 정규화(1달러 미만 소수점 4자리, 이상 2자리 절삭)를 유지합니다.
- BUY는 최종 LIMIT 가격 기준 예산 내 정수 수량을 계산하므로 수량이 감소할 수 있습니다. SELL 전략 결정 수량은 유지합니다.
- 1주도 살 수 없는 경우 기존 최소주문/0주 처리 정책을 유지합니다.
- 전략 신호, TIF, workflow/state/ledger, fail-closed 정책은 변경하지 않습니다. 정규장 종료 후 주문 접수는 broker 제한을 따르며 보장되지 않습니다.
- 별도의 ORDER_SLIPPAGE_PCT 설정은 추가하지 않았으며, 두 모드 모두 기존 MINUTE의 고정 0.1%를 사용합니다.
- 기존 state/ledger의 수동 수정 또는 migration은 필요하지 않습니다.
