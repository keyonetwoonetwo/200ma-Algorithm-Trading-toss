#!/usr/bin/env python3
"""One-command fresh VPS setup orchestration; it never runs the trader or enables LIVE."""
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Optional, Tuple
from config.defaults import DEFAULT_BACKUP_TIME, DEFAULT_CLOSE_EXECUTION_TIME, NY_ZONE

try:  # Windows test hosts do not provide POSIX account modules; VPS does.
    import grp
    import pwd
except ImportError:  # pragma: no cover - deployment target is Ubuntu
    grp = pwd = None

try:
    from backup_common import ROOT
    from release_common import read_env, write_env
    from initialize import initialize_from_fresh_setup
except ModuleNotFoundError:  # package import in regression tests
    from scripts.backup_common import ROOT
    from scripts.release_common import read_env, write_env
    from scripts.initialize import initialize_from_fresh_setup

def ask_yes_no(prompt: str) -> bool:
    return input(f"{prompt} [y/N]: ").strip().lower() in {"y", "yes"}


def canonical_time(value: str) -> str:
    value = value.strip()
    if re.fullmatch(r"\d{2}:\d{2}", value):
        value += ":00"
    if not re.fullmatch(r"\d{2}:\d{2}:\d{2}", value):
        raise ValueError("time must be HH:MM or HH:MM:SS")
    try:
        return datetime.strptime(value, "%H:%M:%S").strftime("%H:%M:%S")
    except ValueError as exc:
        raise ValueError("time must be a valid 24-hour clock time") from exc


def minute_execution_time(signal_time: str) -> str:
    signal = datetime.strptime(canonical_time(signal_time), "%H:%M:%S")
    execution = signal + timedelta(minutes=1, seconds=10)
    if execution.time() >= datetime.strptime("16:00:00", "%H:%M:%S").time():
        raise ValueError("MINUTE execution timer would reach the 16:00 NY hard stop")
    return execution.strftime("%H:%M:%S")


def validate_close_execution_time(value: str) -> str:
    canonical = canonical_time(value)
    parsed = datetime.strptime(canonical, "%H:%M:%S").time()
    regular_close = datetime.strptime("16:00:00", "%H:%M:%S").time()
    after_hours_end = datetime.strptime("20:00:00", "%H:%M:%S").time()
    if not regular_close <= parsed < after_hours_end:
        raise ValueError("CLOSE execution time must be from 16:00:00 through before 20:00:00 America/New_York")
    return canonical


def trading_schedule(values: dict) -> Tuple[str, str, str]:
    mode = values.get("TRADING_SIGNAL_MODE", "CLOSE").upper()
    if mode == "MINUTE":
        signal = canonical_time(values["SIGNAL_TIME"])
        execution = minute_execution_time(signal)
        return signal, execution, f"Mon..Fri *-*-* {execution} {NY_ZONE}"
    execution = DEFAULT_CLOSE_EXECUTION_TIME
    return "installation identity field", execution, f"Mon..Fri *-*-* 13,16:00:00 {NY_ZONE}"


def service_unit(project_root: Path, service_name: str, command: str, description: str, user: Optional[str] = None, group: Optional[str] = None) -> str:
    user = user or (pwd.getpwuid(os.getuid()).pw_name if pwd else os.environ.get("USERNAME", "root"))
    group = group or (grp.getgrgid(os.getgid()).gr_name if grp else user)
    project = project_root.as_posix()
    return f"""[Unit]
Description={description}
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
WorkingDirectory={project}
ExecStart={project}/{command}
User={user}
Group={group}
NoNewPrivileges=true
PrivateTmp=true
"""


def timer_unit(description: str, schedule: str, service_name: str) -> str:
    return f"""[Unit]
Description={description}

[Timer]
OnCalendar={schedule}
Persistent=true
Unit={service_name}

[Install]
WantedBy=timers.target
"""


def run(command, **kwargs):
    return subprocess.run(command, check=True, text=True, **kwargs)


def configure_backup() -> Optional[str]:
    values = read_env()
    effective_chat = values.get("TELEGRAM_BACKUP_CHAT_ID", "").strip() or values.get("TELEGRAM_ALERT_CHAT_ID", "").strip()
    enabled = values.get("TELEGRAM_ENABLED", "false").lower() == "true"
    if not enabled or not values.get("TELEGRAM_BOT_TOKEN", "").strip() or not effective_chat:
        print("Telegram 자동 백업: 비활성. 나중에 ./setup-backup.sh로 설정할 수 있습니다.")
        return None
    backup_time = canonical_time(input(f"Daily backup time in {NY_ZONE} [{DEFAULT_BACKUP_TIME}]: ").strip() or DEFAULT_BACKUP_TIME)
    print(f"Telegram 백업 스케줄: {backup_time} {NY_ZONE}")
    if not ask_yes_no("이 Telegram 백업 timer를 생성하고 활성화하시겠습니까?"):
        raise RuntimeError("백업 timer가 승인되지 않았습니다.")
    return backup_time


def install_unit(name: str, contents: str) -> None:
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False) as handle:
        handle.write(contents)
        temporary = handle.name
    try:
        run(["sudo", "install", "-m", "0644", temporary, f"/etc/systemd/system/{name}"])
    finally:
        Path(temporary).unlink(missing_ok=True)


def enable_timer(service_name: str, timer_name: str, service_contents: str, timer_contents: str) -> str:
    install_unit(service_name, service_contents)
    install_unit(timer_name, timer_contents)
    run(["sudo", "systemctl", "daemon-reload"])
    run(["sudo", "systemctl", "enable", "--now", timer_name])
    return run(["systemctl", "list-timers", "--all", timer_name, "--no-pager"], capture_output=True).stdout.strip()


def confirm_dry_run() -> None:
    values = read_env()
    if values.get("EXECUTION_MODE") != "DRY_RUN" or values.get("LIVE_TRADING_ENABLED") != "false":
        raise RuntimeError("fresh setup requires DRY_RUN with LIVE_TRADING_ENABLED=false")


def configure_close_execution_time() -> dict:
    """Persist the regular-close polling scheduler setting, outside identity."""
    values = read_env()
    if values.get("TRADING_SIGNAL_MODE", "CLOSE").upper() != "CLOSE":
        return values
    values["CLOSE_EXECUTION_TIME"] = DEFAULT_CLOSE_EXECUTION_TIME
    write_env(values, backup=False)
    return values


def run_fresh_stages() -> None:
    """Run approval-preserving setup stages in the required order."""
    confirm_dry_run()
    initialize_from_fresh_setup()
    run([str(ROOT / "validate.sh")])


def main() -> None:
    os.chdir(ROOT)
    try:
        from platform_deploy import selected_platform, validate_termux_runtime, install_termux_cron, install_termux_boot
    except ModuleNotFoundError:
        from scripts.platform_deploy import selected_platform, validate_termux_runtime, install_termux_cron, install_termux_boot
    platform = selected_platform(ROOT)
    if platform == "termux":
        validate_termux_runtime()
    # install.sh has completed the interactive configure wizard at this point.
    run_fresh_stages()
    selected_backup_time = configure_backup()
    backup = selected_backup_time is not None
    backup_time = selected_backup_time or DEFAULT_BACKUP_TIME
    scheduler_values = read_env()
    scheduler_values["BACKUP_TIME"] = backup_time
    write_env(scheduler_values, backup=False)

    values = configure_close_execution_time()
    signal, execution, schedule = trading_schedule(values)
    if not ask_yes_no(f"거래 자동실행을 활성화하시겠습니까? ({schedule})"):
        raise RuntimeError("거래 자동실행이 승인되지 않아 설치를 중단합니다.")
    trading_next = ""
    backup_next = "Disabled"
    if backup and platform == "linux":
        backup_schedule = f"*-*-* {backup_time} {NY_ZONE}"
        backup_next = enable_timer(
            "toss-trader-backup.service", "toss-trader-backup.timer",
            service_unit(
                ROOT,
                "toss-trader-backup.service",
                "backup.sh",
                "Toss Trader state backup",
        ),
        timer_unit(
                "Schedule Toss Trader state backup",
                backup_schedule,
                "toss-trader-backup.service",
            ),
        )
    if platform == "linux":
        trading_next = enable_timer(
            "toss-trader.service", "toss-trader.timer",
            service_unit(ROOT, "toss-trader.service", "run.sh", "Toss Trader one-shot run"),
            timer_unit("Schedule Toss Trader one-shot run", schedule, "toss-trader.service"),
        )
    else:
        print("\n자동실행을 위해 Termux:Boot 앱이 필요합니다.")
        if ask_yes_no("Termux:Boot가 설치되어 있습니까?"):
            install_termux_cron(ROOT, values, backup, backup_time)
            boot_path = install_termux_boot(ROOT)
            run([
                "sh",
                "-c",
                "pgrep -x crond >/dev/null 2>&1 || crond",
            ])
            trading_next = f"cron 등록 완료 / 부팅 스크립트: {boot_path}"

            if backup:
                backup_next = "cron 등록 완료"
        else:
            trading_next = "비활성 (Termux:Boot 확인 필요)"
            print("Termux:Boot 설치 후 setup.sh의 자동실행 설정을 다시 진행하세요. 현재 부팅 자동시작은 활성화하지 않았습니다.")
    public_ip = None
    if platform == "termux":
        try:
            try:
                from check_public_ip import check_public_ip
            except ModuleNotFoundError:
                from scripts.check_public_ip import check_public_ip
            _, public_ip = check_public_ip()
        except Exception as exc:
            print(f"경고: 공인 IPv4 기준값 확인을 완료하지 못했습니다: {exc}")
    state = __import__("json").loads((ROOT / "data" / "state.json").read_text(encoding="utf-8"))
    identity = state["installation_identity"]
    account = str(identity["account_no"])
    masked = "*" * max(0, len(account) - 3) + account[-3:]
    platform_label = "Linux" if platform == "linux" else "Android / Termux"
    print("\n========================================\nToss Trader 설치 완료\n========================================")
    print(f"플랫폼: {platform_label}")
    if platform == "termux":
        print("스케줄러: crond")
    if values["TRADING_SIGNAL_MODE"].upper() == "MINUTE":
        print(f"실행 방식: MINUTE\n신호 캔들: {signal} {NY_ZONE}\n자동 실행: {execution} {NY_ZONE}")
    else:
        print(f"실행 방식: CLOSE\n자동 실행: {execution} {NY_ZONE}")
    print(
        f"신호/메인/과열/안전자산: {values['SIGNAL_SYMBOL']}/{values['MAIN_SYMBOL']}/"
        f"{values['OVERHEAT_SYMBOL']}/{values['SAFE_SYMBOL']}\n"
        f"재진입 대기일: {values['WAIT_DAYS']}\n"
        f"미진입 tranche 목적지: {values.get('ENTRY_SPLIT_OVERHEAT_ACTION', 'SAFE')}"
    )
    print(f"계좌: {masked}\n계좌 순번: {identity['account_seq']}\n실행 모드: DRY_RUN\n실거래: 비활성화\n검증: PASS")
    auto_enabled = platform == "linux" or trading_next.startswith("cron 등록")
    print(f"거래 자동실행: {'활성' if auto_enabled else '비활성'}\n스케줄: {schedule}\n상태: {trading_next}")
    if backup:
        backup_target = "별도 백업 대화방" if values.get("TELEGRAM_BACKUP_CHAT_ID", "").strip() else "알림 대화방과 동일"
        print(f"Telegram 백업: 활성\n대화방: {backup_target}\n스케줄: 매일 {backup_time} {NY_ZONE}\n상태: {backup_next}")
    else:
        print("백업: 비활성")
    if platform == "termux":
        print(f"공인 IPv4 감시: {'활성' if auto_enabled else '비활성'}")
        print("스케줄: 매일 22:00 Asia/Seoul")
        print(f"현재 기준 IP: {public_ip or '아직 확인되지 않음'}")
        print("\n[Android 필수 확인]\n\n- Android 배터리 최적화에서 Termux 제외\n- Termux 알림 패널 Wake Lock ON\n- Termux 강제종료 금지\n- Termux:Boot 설치 및 활성화\n- crond 자동 시작 확인")
    print("복구는 ./restore.sh를 사용하세요. 기존 state 덮어쓰기는 명시적 --overwrite 확인이 필요합니다.")
    print("설치 과정에서는 거래를 실행하지 않았습니다. LIVE는 별도 ./enable-live.sh 절차가 필요합니다.")



if __name__ == "__main__":
    main()
