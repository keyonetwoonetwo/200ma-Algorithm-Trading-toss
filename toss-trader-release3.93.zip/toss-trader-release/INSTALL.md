# Toss Trader 3.93 설치 안내

## 1. 지원 환경

공식 지원 환경은 systemd를 사용하는 일반 **Linux/VPS**와 **Android/Termux** 두 가지입니다. WSL 전용 분기는 없으며, WSL에서 시도할 경우 Linux를 선택할 수 있지만 systemd가 실제 동작해야 합니다. 모든 거래 시각은 `America/New_York` 기준이며 설치는 항상 `DRY_RUN`, `LIVE_TRADING_ENABLED=false`로 시작합니다.

## 2. Linux 설치

```bash
chmod +x ./*.sh
./setup.sh
```

플랫폼에서 `1`(Linux)을 선택합니다. setup은 systemd 실행 여부를 확인하고 기존 `toss-trader.service`/`toss-trader.timer` 및 백업 service/timer 방식으로 구성합니다. `systemctl status toss-trader.timer`와 `systemctl list-timers --all toss-trader.timer toss-trader-backup.timer`로 확인합니다.

## 3. Android / Termux 설치

최초 한 번 저장소 접근 권한을 설정합니다.

```bash
termux-setup-storage
```

그 다음 release ZIP을 복사하고 설치합니다.

```bash
mkdir -p ~/toss-trader
cd ~/toss-trader
cp ~/storage/downloads/toss-trader-release3.93.zip .
pkg install -y unzip
unzip toss-trader-release3.93.zip
cd toss-trader-release
chmod +x *.sh
./setup.sh
```

플랫폼에서 `2`를 선택합니다. setup은 실제 Termux의 `PREFIX`를 확인한 뒤 `pkg update`, `pkg upgrade`, Python/pip, cronie, unzip과 runtime requirements를 설치합니다.

설치 전에 반드시 Android 배터리 최적화에서 Termux를 제외하고, Termux 알림 패널에서 **Wake Lock을 직접 ON** 하십시오. 프로그램은 `termux-wake-lock`을 호출하지 않으며 Termux:API를 요구하지 않습니다.

자동실행에는 별도 **Termux:Boot 앱**이 필요합니다. 설치 여부 질문에 `y`로 답한 경우에만 Toss Trader cron과 `$HOME/.termux/boot/start-toss-trader`를 만듭니다. 이 스크립트는 미실행 상태인 `crond`만 시작하며 거래 프로그램을 즉시 실행하지 않습니다. 거래는 cron schedule이 기존 `run.sh`를 호출할 때만 시작됩니다.

`crontab -l`과 `pgrep -a crond`로 확인합니다. crontab에는 `# BEGIN TOSS-TRADER`와 `# END TOSS-TRADER` 사이 블록 하나만 관리합니다. 재설치해도 중복되지 않으며 다른 cron 항목은 보존됩니다. 거래와 백업은 `CRON_TZ=America/New_York`를 사용합니다. MINUTE cron은 설정된 `SIGNAL_TIME`의 다음 분에 공통 runner를 시작합니다. CLOSE는 13:00(미국 조기 종료일 대응)과 16:00에 runner를 호출하며, runner가 Toss calendar의 `regularMarket.endTime`과 일치하는 호출에서만 10초 polling을 시작합니다. 백업 기본값은 16:15입니다. cron stdout/stderr는 `logs/cron-minute.log` 또는 `logs/cron-close.log`에 저장되고 5 MiB에서 한 세대 회전됩니다.

공인 IPv4 감시는 별도의 `CRON_TZ=Asia/Seoul` 구간에서 매일 22:00에 실행됩니다. 최초 IP는 `data/public_ip.txt`에 기준값으로 저장하며, 변경 또는 조회 실패 시 Telegram 경고를 전송합니다. 이 기능은 trading state, ledger, workflow 및 DRY_RUN/LIVE mode와 독립적입니다.

전체 설치가 성공한 뒤 pip cache를 자동 정리합니다. 정리 실패는 경고만 표시하며 설치된 `.venv`, state, ledger, 환경설정 및 cron은 삭제하지 않습니다.

## 4. DRY_RUN

`./validate.sh` 후 `./run.sh`를 사용합니다. DRY_RUN은 계좌를 조회하지만 주문/변경 API를 호출하지 않습니다.

사용자 설정의 유일한 원본은 setup 또는 `./configure.sh`가 생성하는 `.env`입니다. 계좌, 4개 역할 심볼, `TRADING_SIGNAL_MODE`, `SIGNAL_TIME`은 installation identity이므로 변경 시 fail-closed 합니다. 인증정보, Telegram 값과 threshold/wait/split/MA/drawdown/milestone/minimum-order/lookback/polling/cutoff/timeout 값은 runtime 설정이며 다음 실행의 새 전략 판단부터 적용됩니다. 기존 workflow는 생성 당시 저장한 주문 step·목적지·state transition을 그대로 사용합니다.

`ENTRY_SPLIT`은 초기 Risk-On 진입 횟수이며 기본값 1은 기존 전액 진입과 동일합니다. ACTIVE split의 total/reserve/progress는 state에 저장된 값을 계속 사용하므로 실행 중 설정을 바꿔도 재해석되지 않으며, 새 값은 다음 split cycle부터 적용됩니다.

`ENTRY_SPLIT=N`이면 첫 Risk-On 진입 기준금액을 한 번 고정하고 하루에 한 tranche만 진행합니다. 중간 tranche는 `entry_base_cash / N`, 마지막 tranche는 남은 reserve 전체를 사용해 정수 수량만 매수합니다. 0주 tranche도 회차는 소진됩니다.

`ENTRY_SPLIT_OVERHEAT_ACTION`은 ACTIVE split 중 Overheat가 발생했을 때 남은 reserve를 처리하는 정책입니다. 허용값은 `SAFE`, `OVERHEAT`, `MAIN`이며 생략 시 보수적인 `SAFE`가 기본입니다. SAFE와 OVERHEAT는 각각 해당 역할 자산에 남은 reserve를 정수주로 이동하고 split을 `TERMINATED_OVERHEAT`로 종료합니다. 정수주 미만 잔액은 같은 실행에서 재사용하지 않고 다음 실행부터 일반 New Cash로 해제되며, 종료된 split은 재개되지 않습니다.

MAIN은 이미 ACTIVE인 split에만 적용됩니다. Overheat에서도 state에 저장된 total/progress/reserve에 따라 하루 한 tranche씩 MAIN 매수를 계속하며 split을 종료하거나 reserve를 다시 계산하지 않습니다. reserve를 초과한 신규 현금은 별도 budget으로 OVERHEAT 자산에 배분합니다. Overheat 상태에서 새 MAIN split을 시작하지 않으며 Risk-Off, Drawdown, Milestone 우선순위도 바뀌지 않습니다. 선택한 action, tranche budget과 신규 현금 destination은 workflow에 저장되므로 시작 후 `.env`를 바꿔도 기존 workflow는 변하지 않습니다.

Milestone 값은 setup wizard에서 질문하지 않으며 다음 기본값이 `.env`에 자동 생성됩니다.

```text
MILESTONE_LEVELS=50,100,200,300,400,500,600
MILESTONE_SELL_RATIOS=0.30,0.50,0.50,0.50,0.50,0.50,0.50
```

원하는 사용자는 `.env`를 직접 수정할 수 있으며 변경값은 다음 실행부터 적용됩니다. 예를 들면 다음과 같습니다.

```text
MILESTONE_LEVELS=10,25,50,100,200,400
MILESTONE_SELL_RATIOS=0.10,0.10,0.10,0.50,0.50,0.50
```

두 목록은 같은 개수여야 하고, `MILESTONE_LEVELS`는 양의 정수를 중복 없이 오름차순으로 적어야 합니다. 각 `MILESTONE_SELL_RATIOS` 값은 0보다 크고 1 이하여야 합니다. 잘못된 값은 시작 단계에서 설정 오류로 중단됩니다. 설정한 마지막 level 이후 milestone은 자동 생성되지 않습니다. 이 설정은 installation identity에 포함되지 않으며 기존 state의 `last_milestone`은 유지되므로, 설정을 바꿔도 그 값 이하의 새 level이 소급 실행되지 않습니다. 전략의 모든 세부 동작이 config로 제공되는 것은 아니며 더 복잡한 전략 변경은 source 수정 대상입니다.

스케줄러는 설치 시 생성됩니다. MINUTE의 `SIGNAL_TIME`은 identity이자 설치된 timer/cron 시작 시각이므로 변경하려면 재설치/재초기화가 필요합니다. CLOSE timer/cron은 조기 종료 대응을 위해 13:00과 16:00 NY에 기동하며 실제 polling 시작은 Toss calendar의 `regularMarket.endTime`이 결정합니다. `CLOSE_EXECUTION_TIME`을 `.env`에서 바꾸는 것만으로 기존 scheduler는 변경되지 않으며 현재 CLOSE runtime 판단 시각도 바꾸지 않습니다. `MINUTE_ORDER_CUTOFF`, polling interval, API timeout과 candle lookback은 다음 프로세스 실행부터 바로 반영됩니다.

## 5. LIVE 승격

`./enable-live.sh`를 실행합니다. 설치 mode에 해당하는 미확정 주문 경고만 표시되며 다음 두 문구를 순서대로 정확히 입력해야 합니다.

```text
주문 접수가 체결을 의미하지 않음을 이해했습니다
실거래를 활성화합니다
```

승격 전 account/state/ledger/active workflow/UNKNOWN/partial-fill 안전 검사가 그대로 적용됩니다.

## 6. LIVE 해제

`./disable-live.sh`를 실행합니다. 실행 mode만 DRY_RUN으로 바꾸며 systemd timer, cron, crond를 제거하거나 종료하지 않습니다.

## 7. 백업/복구

백업은 Telegram 백업 전용 대화방으로 자동 전송됩니다. 설정, 파일 내용과 복구 방법은 `BACKUP.md`를 참고하십시오.

새 서버에서 setup이 기존 관리 자산 때문에 fresh initialize를 거부한 경우 `.env`와 `.install-platform`을 유지한 채 다음 명령으로 복구합니다.

```bash
./recover_backup.sh ~/storage/downloads/toss-trader-backup-YYYYMMDD-HHMMSS-UTC.tar.gz
```

복구는 반드시 `EXECUTION_MODE=DRY_RUN`, `LIVE_TRADING_ENABLED=false`에서만 실행됩니다. 기존 거래 scheduler를 먼저 중지하고 archive/identity/현재 Toss portfolio/workflow를 임시 파일에서 검증한 뒤 state와 ledger를 교체합니다. 성공한 경우에만 Linux systemd timer 또는 Termux cron·Boot를 다시 구성합니다. 실패하면 기존 local state/ledger와 scheduler 상태를 rollback합니다.

Telegram 설정은 세 가지 방식 중 선택할 수 있습니다.

1. 알림방과 백업방을 분리하려면 두 Chat ID를 모두 입력합니다.
2. 한 대화방에서 모두 받으려면 백업 Chat ID 입력에서 Enter를 누릅니다.
3. Telegram을 사용하지 않으려면 최초 질문에 `n`을 입력합니다. Telegram만 비활성화되며 거래에는 영향이 없습니다.

## 8. 장애 시 확인 방법

Linux는 `systemctl status toss-trader.service`와 `journalctl -u toss-trader.service`를 확인합니다. Termux는 `crontab -l`, `pgrep -a crond`, Termux:Boot 설치 및 Android Wake Lock 상태를 확인합니다. state/ledger/account mismatch, `UNKNOWN`, `PARTIAL_FILLED_BLOCKED`, active workflow가 표시되면 재주문하거나 파일을 수정하지 마십시오. Toss 앱에서 주문을 정리했거나 broker 결과를 다시 확인해야 할 때는 `./reconcile-workflow.sh`를 사용하십시오. 확인 불가능·부분체결 상태는 active로 남고 종료 코드 2를 반환합니다.

CLOSE polling의 각 NY 조회 시각, candle timestamp, OHLC, volume과 `stable_count`는 모든 환경에서 `logs/close_polling.log`에 기록됩니다. 파일은 5 MiB에서 회전하며 `close_polling.log.1`, `.2` 두 세대까지 보존합니다. Linux에서는 같은 stdout 로그를 `journalctl -u toss-trader.service --since today --no-pager`로도 확인할 수 있습니다. Termux에서는 전체 실행 로그가 기존 `logs/cron-close.log`에도 기록되며 이 파일은 5 MiB·1세대로 회전합니다.

## 9. 중요 안전사항

- 하나의 계좌에 동시에 여러 LIVE controller를 사용하지 마십시오.
- DRY_RUN 설치본도 같은 계좌를 조회합니다. 다른 LIVE controller가 계좌를 바꾸면 broker/state mismatch가 발생할 수 있습니다.
- state/ledger mismatch 시 파일을 임의 수정하지 마십시오.
- `UNKNOWN` 발생 시 재주문하지 마십시오.
- partial fill 상태에서 임의 재주문하지 마십시오.
- USD cash는 전략 조건에 따라 자동 투자될 수 있습니다.
- main/overheat가 모두 0인 initial-entry에서는 safe asset이 재진입 재원으로 사용될 수 있습니다.
- Android에서는 Wake Lock과 배터리 최적화 제외가 필수 운영조건입니다. Termux를 강제 종료하지 마십시오.
