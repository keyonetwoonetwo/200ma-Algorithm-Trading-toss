"""Persisted generic minute workflow policy; independent from runner admission."""
from datetime import datetime, timezone
from typing import Any, Dict


class MinuteExecution:
    core_name = "MINUTE"

    @staticmethod
    def _time(policy: Dict[str, Any], name: str) -> datetime:
        raw = policy.get(name)
        if not raw:
            raise ValueError(f"MINUTE workflow policy missing {name}")
        value = datetime.fromisoformat(str(raw))
        if value.tzinfo is None:
            raise ValueError(f"MINUTE workflow policy {name} must be timezone-aware")
        return value.astimezone(timezone.utc)

    @classmethod
    def validate_admission(cls, policy: Dict[str, Any], now_utc: datetime) -> None:
        if policy.get("kind") != "MINUTE_V1" or not policy.get("signal_time"):
            raise ValueError("MINUTE workflow has invalid execution policy")
        if now_utc >= cls._time(policy, "admission_deadline"):
            raise ValueError("MINUTE workflow admission cutoff reached; no workflow was started")

    @classmethod
    def step_permitted(cls, workflow: Dict[str, Any], step: Dict[str, Any], ledger: Dict[str, Any], now_utc: datetime) -> bool:
        policy = workflow["execution_policy"]
        # MINUTE is a regular-session-only execution core.  Persisted workflows
        # may be inspected or committed after close, but never submit another
        # broker leg at or after 16:00 America/New_York.
        return now_utc < cls._time(policy, "new_leg_deadline")
