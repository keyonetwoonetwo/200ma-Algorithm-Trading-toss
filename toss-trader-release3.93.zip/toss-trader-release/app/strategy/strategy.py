import logging
from decimal import Decimal, ROUND_CEILING
from typing import Any, Dict, List, Optional, Tuple
from config.config import StrategyConfig, TradingConfig
from app.models.common import OrderSide, OrderType, TimeInForce
from app.models.market import IndicatorResult
from app.models.orders import OrderItem, OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState
from app.strategy.base_strategy import BaseStrategy

logger = logging.getLogger(__name__)


class StrategyEngine(BaseStrategy):
    """Generic moving-average, drawdown, and milestone allocation engine.

    Rules:
    1. Risk-Off: current_close < 200MA
       -> Sell the Main and Overheat assets -> Safe asset
       -> Reset cycle high, last milestone, and drawdown trigger.
    2. Wait: apply the configured confirmation-day policy after a rebound.
       -> Maintain the Safe asset / standby.
    3. Risk-On: the configured confirmation policy is satisfied.
       - If no Main position: Sell the Safe asset -> Buy the configured entry asset.
       - If holding Main:
         - Update cycle_high_close = max(cycle_high, current_close).
         - Drawdown Check: if current_close <= cycle_high * 0.75 (and not already triggered at this peak):
           -> Sell configured Main ratio -> Buy Overheat asset.
         - Milestone Check: use the explicitly configured level/ratio list.
         - New Cash Allocation:
           - Risk-On threshold <= close < Overheat threshold: New Cash -> Main
           - close >= Overheat threshold: New Cash -> Overheat
    """

    def __init__(
        self,
        strategy_config: Optional[StrategyConfig] = None,
        trading_config: Optional[TradingConfig] = None,
    ):
        self.config = strategy_config or StrategyConfig()
        self.trading = trading_config or TradingConfig()

    @staticmethod
    def _state_cash(state: Dict[str, Any], key: str) -> Decimal:
        try:
            value = Decimal(str(state.get(key, "0")))
        except Exception as exc:
            raise ValueError(f"Invalid split state value: {key}") from exc
        if value < 0:
            raise ValueError(f"Invalid negative split state value: {key}")
        return value

    @staticmethod
    def _terminate_split(state: Dict[str, Any], status: str, reason: str) -> None:
        state["entry_split_status"] = status
        state["entry_split_terminated_reason"] = reason
        if status == "TERMINATED_RISK_OFF":
            state["entry_reserved_cash"] = "0"
            state["entry_reserved_cash_balance"] = "0"

    def _entry_tranche_plan(
        self,
        updated_state: Dict[str, Any],
        portfolio: PortfolioState,
        target_sym: str,
        safe_sym: str,
        main_price: Decimal,
        safe_price: Decimal,
        main_signal_price: Decimal,
        base_cash: Decimal,
        reserved_cash: Decimal,
        reserved_cash_balance: Decimal,
        done: int,
        initial: bool,
    ) -> Tuple[OrderPlan, Dict[str, Any]]:
        # An ACTIVE split is defined by durable state, not today's runtime
        # ENTRY_SPLIT.  A changed setting applies only when a new split starts.
        total = self.config.entry_split if initial else int(updated_state.get("entry_split_total", 0))
        tranche_index = done + 1
        if total <= 1 or tranche_index > total:
            raise ValueError("Invalid active entry split state")
        last = tranche_index == total
        tranche_budget = reserved_cash if last else min(reserved_cash, base_cash / Decimal(total))
        min_order = Decimal(str(self.trading.min_order_amount_usd))
        planned_buy_qty = int(tranche_budget / main_price) if main_price > 0 and tranche_budget >= min_order else 0
        orders: List[OrderItem] = []
        safe_sell_qty = 0
        if planned_buy_qty > 0:
            reserved_cash_on_hand = min(portfolio.available_cash_usd, reserved_cash_balance)
            funding_gap = max(Decimal("0"), tranche_budget - reserved_cash_on_hand)
            if funding_gap > 0 and portfolio.safe_quantity > 0:
                if safe_price <= 0:
                    raise ValueError(f"No valid {safe_sym} price for entry split funding")
                safe_sell_qty = min(
                    int(portfolio.safe_quantity),
                    int((funding_gap / safe_price).to_integral_value(rounding=ROUND_CEILING)),
                )
                if safe_sell_qty > 0:
                    orders.append(OrderItem(
                        symbol=safe_sym,
                        side=OrderSide.SELL,
                        quantity=safe_sell_qty,
                        price=safe_price,
                        reason=f"Entry split tranche {tranche_index}/{total}: fund from {safe_sym}",
                    ))
            orders.append(OrderItem(
                symbol=target_sym,
                side=OrderSide.BUY,
                quantity=planned_buy_qty,
                price=main_price,
                reason=f"Entry split tranche {tranche_index}/{total}: buy {target_sym}",
            ))

        planned_spend = Decimal(planned_buy_qty) * main_price
        planned_safe_proceeds = Decimal(safe_sell_qty) * safe_price
        reserved_after = max(Decimal("0"), reserved_cash - planned_spend)
        cash_reserved_after = max(
            Decimal("0"),
            min(reserved_after, reserved_cash_balance + planned_safe_proceeds - planned_spend),
        )
        updated_state.update({
            "entry_split_total": total,
            "entry_split_done": tranche_index,
            "entry_base_cash": str(base_cash),
            "entry_reserved_cash": "0" if last else str(reserved_after),
            "entry_reserved_cash_balance": "0" if last else str(cash_reserved_after),
            "entry_split_status": "COMPLETED" if last else "ACTIVE",
            "entry_split_terminated_reason": None,
            "wait_confirmation_count": 0,
        })
        if portfolio.main_quantity > 0 or planned_buy_qty > 0:
            updated_state["cycle_state"] = "RISK_ON"
            updated_state["cycle_high_close"] = float(main_signal_price)
        else:
            updated_state["cycle_state"] = "WAIT"
            updated_state["cycle_high_close"] = None
        if initial:
            updated_state["last_milestone"] = 0
            updated_state["drawdown_triggered_at_high"] = None

        decision = "RISK_ON_ENTRY" if initial else "ENTRY_SPLIT_TRANCHE"
        reason = (
            f"Entry split tranche {tranche_index}/{total}: budget ${tranche_budget:.2f}, "
            f"planned {target_sym} quantity {planned_buy_qty}."
        )
        plan = OrderPlan("generic", decision, reason, orders)
        plan.entry_split = {
            "kind": "TRANCHE",
            "tranche_index": tranche_index,
            "total": total,
            "budget": str(tranche_budget),
            "base_cash": str(base_cash),
            "reserved_before": str(reserved_cash),
            "cash_reserved_before": str(reserved_cash_balance),
            "last": last,
        }
        return plan, updated_state

    def _overheat_termination_plan(
        self,
        updated_state: Dict[str, Any],
        portfolio: PortfolioState,
        overheat_sym: str,
        overheat_price: Decimal,
        safe_sym: str,
        safe_price: Decimal,
    ) -> Tuple[OrderPlan, Dict[str, Any]]:
        destination_action = self.config.entry_split_overheat_action.upper()
        if destination_action == "SAFE":
            destination_symbol, destination_price = safe_sym, safe_price
        elif destination_action == "OVERHEAT":
            destination_symbol, destination_price = overheat_sym, overheat_price
        else:
            raise ValueError("ENTRY_SPLIT_OVERHEAT_ACTION must be SAFE or OVERHEAT")
        reserved = self._state_cash(updated_state, "entry_reserved_cash")
        cash_reserved = min(
            portfolio.available_cash_usd,
            self._state_cash(updated_state, "entry_reserved_cash_balance"),
        )
        min_order = Decimal(str(self.trading.min_order_amount_usd))
        quantity = (
            int(cash_reserved / destination_price)
            if destination_price > 0 and cash_reserved >= min_order else 0
        )
        orders = []
        if quantity > 0:
            orders.append(OrderItem(
                symbol=destination_symbol,
                side=OrderSide.BUY,
                quantity=quantity,
                price=destination_price,
                reason=(
                    f"ENTRY_SPLIT 진행 중 Overheat 발생. 남은 reserve를 "
                    f"{destination_symbol}로 이동하고 split을 종료합니다."
                ),
            ))
        planned_spend = Decimal(quantity) * destination_price
        self._terminate_split(updated_state, "TERMINATED_OVERHEAT", "OVERHEAT")
        updated_state["entry_reserved_cash"] = str(max(Decimal("0"), reserved - planned_spend))
        updated_state["entry_reserved_cash_balance"] = str(max(Decimal("0"), cash_reserved - planned_spend))
        plan = OrderPlan(
            "generic",
            "ENTRY_SPLIT_TERMINATED_OVERHEAT",
            (
                f"ENTRY_SPLIT 진행 중 Overheat 발생. 남은 reserve를 "
                f"{destination_symbol}로 이동하고 split을 종료합니다."
            ),
            orders,
        )
        plan.entry_split = {
            "kind": "TERMINATE_OVERHEAT",
            "budget": str(cash_reserved),
            "reserved_before": str(reserved),
            "cash_reserved_before": str(cash_reserved),
            "destination_action": destination_action,
            "destination_symbol": destination_symbol,
        }
        return plan, updated_state

    def _overheat_main_continuation_plan(
        self,
        updated_state: Dict[str, Any],
        portfolio: PortfolioState,
        target_sym: str,
        main_price: Decimal,
        main_signal_price: Decimal,
        safe_sym: str,
        safe_price: Decimal,
        growth_sym: str,
        overheat_price: Decimal,
        reserved_cash_balance: Decimal,
        new_cash: Decimal,
    ) -> Tuple[OrderPlan, Dict[str, Any]]:
        """Continue only the persisted MAIN tranche and separately route New Cash."""
        plan, state = self._entry_tranche_plan(
            updated_state, portfolio, target_sym, safe_sym, main_price, safe_price,
            main_signal_price,
            self._state_cash(updated_state, "entry_base_cash"),
            self._state_cash(updated_state, "entry_reserved_cash"),
            reserved_cash_balance,
            int(updated_state.get("entry_split_done", 0)),
            False,
        )
        plan.reason += (
            " Overheat detected; ENTRY_SPLIT_OVERHEAT_ACTION=MAIN allows only "
            "the existing split reserve to continue in MAIN."
        )
        plan.decision = "ENTRY_SPLIT_TRANCHE_OVERHEAT_MAIN"
        if overheat_price > 0 and new_cash >= Decimal(str(self.trading.min_order_amount_usd)):
            new_cash_qty = int(new_cash / overheat_price)
            if new_cash_qty > 0:
                plan.orders.append(OrderItem(
                    symbol=growth_sym,
                    side=OrderSide.BUY,
                    quantity=new_cash_qty,
                    price=overheat_price,
                    reason=f"Overheat New Cash Allocation: Buy {growth_sym}",
                ))
                plan.entry_split["new_cash_budget"] = str(new_cash)
                plan.entry_split["new_cash_symbol"] = growth_sym
        plan.entry_split["overheat_action"] = "MAIN"
        return plan, state

    def evaluate(
        self,
        indicator: IndicatorResult,
        portfolio: PortfolioState,
        state_data: Dict[str, Any],
        lifecycle_price: Optional[Decimal] = None,
    ) -> Tuple[OrderPlan, Dict[str, Any]]:
        updated_state = dict(state_data)
        orders: List[OrderItem] = []

        target_sym = self.config.main_symbol
        growth_sym = self.config.overheat_symbol
        safe_sym = self.config.safe_symbol

        # Strategy signals must use the confirmed regular-session close.  The
        # broker's quote is still retained below as the executable limit price,
        # but must never advance a daily milestone during after-hours trading.
        main_price = portfolio.prices.get(target_sym, lifecycle_price or indicator.current_close)
        # Regime and rebound always use ``indicator``.  Lifecycle state and
        # milestones intentionally use the independently finalized main price.
        main_signal_price = lifecycle_price or indicator.current_close
        overheat_price = portfolio.prices.get(growth_sym, Decimal("0"))
        safe_price = portfolio.prices.get(safe_sym, Decimal("0"))

        min_order_amount = Decimal(str(self.trading.min_order_amount_usd))
        account_cash = portfolio.available_cash_usd
        split_status = str(updated_state.get("entry_split_status", "INACTIVE"))
        if split_status == "TERMINATED_OVERHEAT":
            # The terminating execution already returned immediately after its
            # dedicated OVERHEAT order was planned.  On the next evaluation the
            # integer-share residual is ordinary cash again; split progress and
            # terminal status remain durable and the split can never resume.
            updated_state["entry_reserved_cash"] = "0"
            updated_state["entry_reserved_cash_balance"] = "0"
            reserved_cash_balance = Decimal("0")
        else:
            reserved_cash_balance = (
                self._state_cash(updated_state, "entry_reserved_cash_balance")
                if split_status == "ACTIVE" else Decimal("0")
            )
        # Only cash above an ACTIVE entry reserve is New Cash.
        available_cash = max(Decimal("0"), account_cash - reserved_cash_balance)

        # ----------------------------------------------------
        # 1. RISK-OFF: Trend breakdown (current_close < 200MA)
        # ----------------------------------------------------
        if not indicator.is_above_ma200:
            decision = "RISK_OFF"
            reason = (
                f"{indicator.symbol} 종가 ${indicator.current_close:.2f}가 "
                f"Risk-On 기준 ${indicator.ma200:.2f} 미만입니다. Risk-Off로 전환합니다."
            )

            # Reset cycle state
            updated_state["cycle_state"] = "RISK_OFF"
            updated_state["cycle_high_close"] = None
            updated_state["last_milestone"] = 0
            updated_state["drawdown_triggered_at_high"] = None
            updated_state["wait_confirmation_count"] = 0
            if split_status == "ACTIVE" or self.config.entry_split > 1:
                self._terminate_split(updated_state, "TERMINATED_RISK_OFF", "RISK_OFF")

            total_estimated_cash = account_cash

            # Sell all Main asset
            if portfolio.main_quantity > 0:
                sell_qty = int(portfolio.main_quantity)
                orders.append(
                    OrderItem(
                        symbol=target_sym,
                        side=OrderSide.SELL,
                        quantity=sell_qty,
                        price=main_price,
                        reason=f"Risk-Off: Sell 100% {target_sym}",
                    )
                )
                total_estimated_cash += Decimal(sell_qty) * main_price

            # Sell all Overheat asset
            if portfolio.overheat_quantity > 0:
                sell_qty = int(portfolio.overheat_quantity)
                orders.append(
                    OrderItem(
                        symbol=growth_sym,
                        side=OrderSide.SELL,
                        quantity=sell_qty,
                        price=overheat_price if overheat_price > 0 else None,
                        reason=f"Risk-Off: Sell 100% {growth_sym}",
                    )
                )
                if overheat_price > 0:
                    total_estimated_cash += Decimal(sell_qty) * overheat_price

            # Buy Safe asset with cash when a usable price and sufficient cash are available.
            if safe_price > 0 and total_estimated_cash >= min_order_amount:
                buy_qty = int(total_estimated_cash / safe_price)
                if buy_qty > 0:
                    orders.append(
                        OrderItem(
                            symbol=safe_sym,
                            side=OrderSide.BUY,
                            quantity=buy_qty,
                            price=safe_price,
                            reason=f"Risk-Off: Buy {safe_sym} 100%",
                        )
                    )

            plan = OrderPlan(
                strategy_name="generic",
                decision=decision,
                reason=reason,
                orders=orders,
            )
            return plan, updated_state

        # ----------------------------------------------------
        # 2. WAIT: configured confirmation period after a rebound.
        # ----------------------------------------------------
        # Legacy persisted WAIT state predates the counter and represents the
        # already-completed one-day confirmation under the default policy.
        existing_wait_count = int(updated_state.get(
            "wait_confirmation_count",
            self.config.wait_days if updated_state.get("cycle_state") == "WAIT" else 0,
        ))

        def wait_confirmation(initial_rebound: bool = False) -> Tuple[OrderPlan, Dict[str, Any]]:
            completed = min((0 if initial_rebound else existing_wait_count) + 1, self.config.wait_days)
            updated_state["wait_confirmation_count"] = completed
            decision = "WAIT_CONFIRMATION"
            reason = (
                f"{indicator.symbol}가 Risk-On 기준을 회복했습니다. "
                f"설정된 확인 대기 {self.config.wait_days}일 중 {completed}일을 완료했습니다."
            )
            updated_state["cycle_state"] = "WAIT"
            if safe_price > 0 and available_cash >= min_order_amount:
                buy_qty = int(available_cash / safe_price)
                if buy_qty > 0:
                    orders.append(OrderItem(symbol=safe_sym, side=OrderSide.BUY, quantity=buy_qty, price=safe_price, reason=f"Wait: Allocate idle cash to {safe_sym}"))
            return OrderPlan(strategy_name="generic", decision=decision, reason=reason, orders=orders), updated_state

        if self.config.wait_days > 0 and indicator.is_above_ma200 and not indicator.is_prev_above_ma200:
            return wait_confirmation(initial_rebound=True)

        if (
            self.config.wait_days > 0
            and updated_state.get("cycle_state") == "WAIT"
            and split_status != "ACTIVE"
            and portfolio.main_quantity <= 0 and portfolio.overheat_quantity <= 0
            and existing_wait_count < self.config.wait_days
        ):
            return wait_confirmation()

        is_overheat = indicator.current_close >= indicator.overheat_price
        split_active = split_status == "ACTIVE"
        if split_active and portfolio.main_quantity <= 0:
            if is_overheat:
                if self.config.entry_split_overheat_action.upper() == "MAIN":
                    return self._overheat_main_continuation_plan(
                        updated_state, portfolio, target_sym, main_price, main_signal_price,
                        safe_sym, safe_price, growth_sym, overheat_price,
                        reserved_cash_balance, available_cash,
                    )
                return self._overheat_termination_plan(
                    updated_state, portfolio, growth_sym, overheat_price, safe_sym, safe_price,
                )
            return self._entry_tranche_plan(
                updated_state, portfolio, target_sym, safe_sym, main_price, safe_price,
                main_signal_price,
                self._state_cash(updated_state, "entry_base_cash"),
                self._state_cash(updated_state, "entry_reserved_cash"),
                reserved_cash_balance,
                int(updated_state.get("entry_split_done", 0)),
                False,
            )

        # ----------------------------------------------------
        # 3. RISK-ON: configured confirmation policy satisfied.
        # Subcase 3-1: Initial Entry (Neither Main nor Overheat held)
        if portfolio.main_quantity <= 0 and portfolio.overheat_quantity <= 0:
            updated_state["wait_confirmation_count"] = 0
            if split_status in {"COMPLETED", "TERMINATED_OVERHEAT"}:
                decision = "HOLD_WAIT"
                reason = "Prior entry split is closed; it will not be restarted."
                updated_state["cycle_state"] = "WAIT"
                if available_cash >= min_order_amount:
                    entry_sym = growth_sym if is_overheat else target_sym
                    entry_price = overheat_price if is_overheat else main_price
                    buy_qty = int(available_cash / entry_price) if entry_price > 0 else 0
                    if buy_qty > 0:
                        orders.append(OrderItem(
                            symbol=entry_sym, side=OrderSide.BUY, quantity=buy_qty, price=entry_price,
                            reason=f"New Cash Allocation after closed entry split: Buy {entry_sym}",
                        ))
                        decision = "NEW_CASH_SPYM" if is_overheat else "NEW_CASH_TQQQ"
                        reason = f"Allocating ${available_cash:.2f} new cash after the prior entry split closed."
                        if not is_overheat:
                            updated_state["cycle_state"] = "RISK_ON"
                            updated_state["cycle_high_close"] = float(main_signal_price)
                return OrderPlan("generic", decision, reason, orders), updated_state

            if not is_overheat and self.config.entry_split > 1:
                if portfolio.safe_quantity > 0 and safe_price <= 0:
                    raise ValueError(f"No valid {safe_sym} price for entry split base")
                entry_base_cash = account_cash + Decimal(int(portfolio.safe_quantity)) * safe_price
                return self._entry_tranche_plan(
                    updated_state, portfolio, target_sym, safe_sym, main_price, safe_price,
                    main_signal_price, entry_base_cash, entry_base_cash, account_cash, 0, True,
                )
            if is_overheat:
                decision = "RISK_ON_OVERHEAT_ENTRY"
                reason = (
                    f"{indicator.symbol}가 Risk-On 조건을 충족했으며, 종가 ${indicator.current_close:.2f}가 "
                    f"Overheat 기준 ${indicator.overheat_price:.2f} 이상입니다. "
                    f"신규 자금을 {growth_sym}에 배분합니다."
                )
                updated_state["cycle_state"] = "WAIT"
                updated_state["cycle_high_close"] = None
                updated_state["last_milestone"] = 0
                updated_state["drawdown_triggered_at_high"] = None
            else:
                decision = "RISK_ON_ENTRY"
                reason = (
                    f"{indicator.symbol}가 Risk-On 조건을 충족했으며, 종가 ${indicator.current_close:.2f}가 "
                    f"Overheat 기준 ${indicator.overheat_price:.2f} 미만입니다. "
                    f"신규 자금을 {target_sym}에 배분합니다."
                )
                updated_state["cycle_state"] = "RISK_ON"
                updated_state["cycle_high_close"] = float(main_signal_price)
                updated_state["last_milestone"] = 0
                updated_state["drawdown_triggered_at_high"] = None

            total_entry_cash = available_cash

            # Sell 100% Safe asset
            if portfolio.safe_quantity > 0:
                sell_qty = int(portfolio.safe_quantity)
                orders.append(
                    OrderItem(
                        symbol=safe_sym,
                        side=OrderSide.SELL,
                        quantity=sell_qty,
                        price=safe_price if safe_price > 0 else None,
                        reason=f"Risk-On Entry: Sell 100% {safe_sym}",
                    )
                )
                if safe_price > 0:
                    total_entry_cash += Decimal(sell_qty) * safe_price

            # Buy asset with all available cash (Overheat if overheat, Main if normal)
            entry_sym = growth_sym if is_overheat else target_sym
            entry_price = overheat_price if is_overheat else main_price

            if entry_price > 0 and total_entry_cash >= min_order_amount:
                buy_qty = int(total_entry_cash / entry_price)
                if buy_qty > 0:
                    orders.append(
                        OrderItem(
                            symbol=entry_sym,
                            side=OrderSide.BUY,
                            quantity=buy_qty,
                            price=entry_price,
                            reason=f"Risk-On Entry: Buy {entry_sym} with {safe_sym} proceeds and cash{' (Overheat)' if is_overheat else ''}",
                        )
                    )

            plan = OrderPlan(
                strategy_name="generic",
                decision=decision,
                reason=reason,
                orders=orders,
            )
            return plan, updated_state

        # Subcase 3-2: Overheat-only held before Main cycle starts
        if portfolio.main_quantity <= 0 and portfolio.overheat_quantity > 0:
            decision = "HOLD_WAIT"
            reason = f"Holding {growth_sym}-only position before {target_sym} cycle start. Close={indicator.current_close}, 200MA={indicator.ma200:.2f}"
            updated_state["cycle_state"] = "WAIT"
            updated_state["cycle_high_close"] = None
            updated_state["last_milestone"] = 0
            updated_state["drawdown_triggered_at_high"] = None

            if available_cash >= min_order_amount:
                if indicator.current_close >= indicator.overheat_price:
                    if overheat_price > 0:
                        buy_qty = int(available_cash / overheat_price)
                        if buy_qty > 0:
                            orders.append(
                                OrderItem(
                                    symbol=growth_sym,
                                    side=OrderSide.BUY,
                                    quantity=buy_qty,
                                    price=overheat_price,
                                    reason=f"New Cash Allocation (Overheat >= {indicator.overheat_price:.2f}): Buy {growth_sym}",
                                )
                            )
                            decision = "NEW_CASH_SPYM"
                            reason = f"Allocating ${available_cash:.2f} new cash to {growth_sym} ({indicator.symbol} >= {indicator.overheat_price:.2f})."
                else:
                    if main_price > 0:
                        buy_qty = int(available_cash / main_price)
                        if buy_qty > 0:
                            orders.append(
                                OrderItem(
                                    symbol=target_sym,
                                    side=OrderSide.BUY,
                                    quantity=buy_qty,
                                    price=main_price,
                                    reason=f"New Cash Allocation (Normal < {indicator.overheat_price:.2f}): Buy {target_sym}",
                                )
                            )
                            decision = "NEW_CASH_TQQQ"
                            reason = f"Allocating ${available_cash:.2f} new cash to {target_sym} (200MA <= {indicator.symbol} < {indicator.overheat_price:.2f})."
                            # First Main purchase starts the Main Risk-On cycle
                            updated_state["cycle_state"] = "RISK_ON"
                            updated_state["cycle_high_close"] = float(main_signal_price)
                            updated_state["last_milestone"] = 0
                            updated_state["drawdown_triggered_at_high"] = None

            plan = OrderPlan(
                strategy_name="generic",
                decision=decision,
                reason=reason,
                orders=orders,
            )
            return plan, updated_state

        # Subcase 3-3: Maintaining Main Risk-On Position (Main > 0)
        updated_state["cycle_state"] = "RISK_ON"
        existing_cycle_high = Decimal(str(updated_state.get("cycle_high_close") or main_signal_price))
        cycle_high_close = max(existing_cycle_high, main_signal_price)
        updated_state["cycle_high_close"] = float(cycle_high_close)

        continue_active_main_for_overheat = (
            split_active and is_overheat
            and self.config.entry_split_overheat_action.upper() == "MAIN"
        )
        terminate_active_for_overheat = split_active and is_overheat and not continue_active_main_for_overheat
        if terminate_active_for_overheat:
            self._terminate_split(updated_state, "TERMINATED_OVERHEAT", "OVERHEAT")

        last_milestone = int(updated_state.get("last_milestone") or 0)
        drawdown_triggered_high = updated_state.get("drawdown_triggered_at_high")
        drawdown_triggered_high_dec = Decimal(str(drawdown_triggered_high)) if drawdown_triggered_high is not None else None

        decision = "HOLD_RISK_ON"
        reason = f"Holding {target_sym} Risk-On position. Close={indicator.current_close}, 200MA={indicator.ma200:.2f}"

        drawdown_threshold = cycle_high_close * Decimal(str(self.config.drawdown_threshold))  # cycle_high * 0.75

        # ----------------------------------------------------
        # Priority 1 (Drawdown Protection): -25% from cycle high
        # Executes ONCE per cycle peak. If triggered, halts further sells/milestones today.
        # ----------------------------------------------------
        if main_signal_price <= drawdown_threshold and (
            drawdown_triggered_high_dec is None or drawdown_triggered_high_dec < cycle_high_close
        ):
            sell_ratio = Decimal(str(self.config.drawdown_sell_ratio))  # 0.50
            sell_qty = int(portfolio.main_quantity * sell_ratio)
            if sell_qty > 0:
                decision = "DRAWDOWN_REDUCE"
                reason = (
                    f"{target_sym} close ({main_signal_price:.2f}) <= 75% of cycle peak ({cycle_high_close:.2f}). "
                    f"Selling 50% {target_sym} ({sell_qty} shares) and rotating to {growth_sym}."
                )
                orders.append(
                    OrderItem(
                        symbol=target_sym,
                        side=OrderSide.SELL,
                        quantity=sell_qty,
                        price=main_price,
                        reason=f"Drawdown: Sell 50% {target_sym}",
                    )
                )
                updated_state["drawdown_triggered_at_high"] = float(cycle_high_close)

                # Rotate proceeds + available_cash to Overheat asset
                total_overheat_budget = (Decimal(sell_qty) * main_price) + available_cash
                if overheat_price > 0 and total_overheat_budget >= min_order_amount:
                    overheat_buy_qty = int(total_overheat_budget / overheat_price)
                    if overheat_buy_qty > 0:
                        orders.append(
                            OrderItem(
                                symbol=growth_sym,
                                side=OrderSide.BUY,
                                quantity=overheat_buy_qty,
                                price=overheat_price,
                                reason=f"Drawdown: Buy {growth_sym} with {target_sym} proceeds and new cash",
                            )
                        )

                # End trading logic for today (no milestone or additional sells on the same day)
                plan = OrderPlan(
                    strategy_name="generic",
                    decision=decision,
                    reason=reason,
                    orders=orders,
                )
                return plan, updated_state

        # ----------------------------------------------------
        # Priority 2 (Milestone Profit-Taking): explicitly configured levels only.
        # ----------------------------------------------------
        milestone_triggered = False
        main_avg_price = portfolio.main_avg_price
        if main_avg_price > 0 and main_signal_price > 0:
            return_rate = ((main_signal_price / main_avg_price) - Decimal("1")) * Decimal("100")

            # Execute exactly one: the highest currently reached, unexecuted
            # configured milestone. A jump across several levels therefore
            # executes only the highest reached level, and levels at or below
            # durable last_milestone are never applied retroactively.
            reached = [
                (level, ratio)
                for level, ratio in self.config.milestones
                if level > last_milestone and return_rate >= Decimal(level)
            ]
            target_milestone, sell_ratio = reached[-1] if reached else (None, Decimal("0"))

            if target_milestone and sell_ratio > 0:
                sell_qty = int(portfolio.main_quantity * sell_ratio)
                if sell_qty > 0:
                    milestone_triggered = True
                    decision = f"MILESTONE_{target_milestone}"
                    reason = (
                        f"{target_sym} return rate {return_rate:.2f}% reached milestone +{target_milestone}%. "
                        f"Selling {int(sell_ratio * 100)}% ({sell_qty} shares) to split into {growth_sym} (principal) and {safe_sym} (profit)."
                    )
                    orders.append(
                        OrderItem(
                            symbol=target_sym,
                            side=OrderSide.SELL,
                            quantity=sell_qty,
                            price=main_price,
                            reason=f"Milestone +{target_milestone}%: Sell {target_sym}",
                        )
                    )
                    updated_state["last_milestone"] = target_milestone

                    # Split proceeds using exact formula:
                    # 원금 = 총 매도대금 * (평균매수가 / 현재가)
                    # 수익 = 총 매도대금 * ((현재가 - 평균매수가) / 현재가)
                    total_proceeds = Decimal(sell_qty) * main_price
                    principal_amount = total_proceeds * (main_avg_price / main_price)
                    profit_amount = max(Decimal("0"), total_proceeds * ((main_price - main_avg_price) / main_price))

                    # Principal + New Cash -> Overheat asset
                    total_overheat_budget = principal_amount + available_cash
                    if overheat_price > 0 and total_overheat_budget >= min_order_amount:
                        overheat_buy_qty = int(total_overheat_budget / overheat_price)
                        if overheat_buy_qty > 0:
                            orders.append(
                                OrderItem(
                                    symbol=growth_sym,
                                    side=OrderSide.BUY,
                                    quantity=overheat_buy_qty,
                                    price=overheat_price,
                                    reason=f"Milestone +{target_milestone}%: Buy {growth_sym} with principal and new cash",
                                )
                            )

                    # Profit -> Safe asset
                    if safe_price > 0 and profit_amount >= min_order_amount:
                        safe_buy_qty = int(profit_amount / safe_price)
                        if safe_buy_qty > 0:
                            orders.append(
                                OrderItem(
                                    symbol=safe_sym,
                                    side=OrderSide.BUY,
                                    quantity=safe_buy_qty,
                                    price=safe_price,
                                    reason=f"Milestone +{target_milestone}%: Buy {safe_sym} with profit",
                                )
                            )

                    # End trading logic on milestone day; new cash is already
                    # included in the configured Overheat-asset allocation.
                    plan = OrderPlan(
                        strategy_name="generic",
                        decision=decision,
                        reason=reason,
                        orders=orders,
                    )
                    return plan, updated_state

        # ----------------------------------------------------
        # Priority 3: Entry split continuation/termination, then New Cash.
        # ----------------------------------------------------
        if terminate_active_for_overheat:
            return self._overheat_termination_plan(
                updated_state, portfolio, growth_sym, overheat_price, safe_sym, safe_price,
            )
        if continue_active_main_for_overheat:
            return self._overheat_main_continuation_plan(
                updated_state, portfolio, target_sym, main_price, main_signal_price,
                safe_sym, safe_price, growth_sym, overheat_price,
                reserved_cash_balance, available_cash,
            )
        if split_active:
            return self._entry_tranche_plan(
                updated_state, portfolio, target_sym, safe_sym, main_price, safe_price,
                main_signal_price,
                self._state_cash(updated_state, "entry_base_cash"),
                self._state_cash(updated_state, "entry_reserved_cash"),
                reserved_cash_balance,
                int(updated_state.get("entry_split_done", 0)),
                False,
            )
        # New Cash Allocation: Separate idle cash allocation.
        if available_cash >= min_order_amount:
            # Overheat condition: current_close >= 1.05 * 200MA
            if indicator.current_close >= indicator.overheat_price:
                if overheat_price > 0:
                    buy_qty = int(available_cash / overheat_price)
                    if buy_qty > 0:
                        orders.append(
                            OrderItem(
                                symbol=growth_sym,
                                side=OrderSide.BUY,
                                quantity=buy_qty,
                                price=overheat_price,
                                reason=f"New Cash Allocation (Overheat >= {indicator.overheat_price:.2f}): Buy {growth_sym}",
                            )
                        )
                        if not milestone_triggered:
                            decision = "NEW_CASH_SPYM"
                            reason = f"Allocating ${available_cash:.2f} new cash to {growth_sym} ({indicator.symbol} >= {indicator.overheat_price:.2f})."
            else:
                # Normal condition: 200MA <= current_close < 1.05 * 200MA
                if main_price > 0:
                    buy_qty = int(available_cash / main_price)
                    if buy_qty > 0:
                        orders.append(
                            OrderItem(
                                symbol=target_sym,
                                side=OrderSide.BUY,
                                quantity=buy_qty,
                                price=main_price,
                                reason=f"New Cash Allocation (Normal < {indicator.overheat_price:.2f}): Buy {target_sym}",
                            )
                        )
                        if not milestone_triggered:
                            decision = "NEW_CASH_TQQQ"
                            reason = f"Allocating ${available_cash:.2f} new cash to {target_sym} (200MA <= {indicator.symbol} < {indicator.overheat_price:.2f})."

        plan = OrderPlan(
            strategy_name="generic",
            decision=decision,
            reason=reason,
            orders=orders,
        )
        return plan, updated_state

    def evaluate_decision(
        self,
        indicator: IndicatorResult,
        portfolio: PortfolioState,
        state_data: Dict[str, Any],
        lifecycle_price: Optional[Decimal] = None,
    ) -> Tuple[StrategyDecision, OrderPlan]:
        """Return a proposed event and its conditional state transition.

        ``evaluate`` remains a pure planning helper for compatibility.  Its
        tentative state is never persisted by the live execution path; only
        WorkflowExecutor may commit it after every broker leg is FILLED.
        """
        plan, tentative_state = self.evaluate(indicator, portfolio, state_data, lifecycle_price)
        transition = {
            key: value
            for key, value in tentative_state.items()
            if state_data.get(key) != value and key != "last_execution_date"
        }
        decision = StrategyDecision(
            strategy_name="generic",
            decision=plan.decision,
            reason=plan.reason,
            event=plan.decision,
            pending_state_transition=transition,
        )
        if plan.decision == "DRAWDOWN_REDUCE":
            decision.sell_ratio = Decimal(str(self.config.drawdown_sell_ratio))
        elif plan.decision.startswith("MILESTONE_"):
            decision.milestone = int(plan.decision.split("_")[-1])
            decision.sell_ratio = dict(self.config.milestones)[decision.milestone]
        elif plan.decision == "NEW_CASH_TQQQ":
            decision.cash_target_symbol = self.config.main_symbol
        elif plan.decision == "NEW_CASH_SPYM":
            decision.cash_target_symbol = self.config.overheat_symbol
        elif plan.decision == "WAIT_CONFIRMATION" and plan.orders:
            decision.cash_target_symbol = self.config.safe_symbol
        return decision, plan
