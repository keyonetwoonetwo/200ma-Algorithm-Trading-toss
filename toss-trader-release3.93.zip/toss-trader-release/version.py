"""Public release version SSOT."""

RELEASE_VERSION = "3.93"
