from decimal import Decimal

import pytest

from app.execution.workflow_executor import WorkflowBlocked, WorkflowExecutor
from app.models.common import OrderSide
from app.models.market import IndicatorResult
from app.models.orders import StrategyDecision
from app.models.portfolio import PortfolioState
from app.strategy.strategy import StrategyEngine
from config.config import AppConfig, StrategyConfig


def overheat_indicator(risk_on=True):
    return IndicatorResult(
        "TQQQ", Decimal("110") if risk_on else Decimal("40"), Decimal("100"),
        Decimal("105"), Decimal("100"), risk_on, True, Decimal("105"),
    )


def active_state():
    return {
        "cycle_state": "RISK_ON", "cycle_high_close": 110, "last_milestone": 0,
        "entry_split_total": 3, "entry_split_done": 2, "entry_base_cash": "900",
        "entry_reserved_cash": "300", "entry_reserved_cash_balance": "300",
        "entry_split_status": "ACTIVE", "entry_split_terminated_reason": None,
    }


def portfolio(cash="300"):
    return PortfolioState(
        main_quantity=Decimal("6"), main_avg_price=Decimal("100"),
        available_cash_usd=Decimal(cash),
        prices={"TQQQ": Decimal("110"), "SPYM": Decimal("80"), "SGOV": Decimal("100")},
    )


def test_active_split_overheat_defaults_to_safe_and_preserves_main():
    engine = StrategyEngine(StrategyConfig(entry_split=3))
    plan, state = engine.evaluate(overheat_indicator(), portfolio(), active_state(), Decimal("110"))
    assert plan.decision == "ENTRY_SPLIT_TERMINATED_OVERHEAT"
    assert [(o.symbol, o.side, o.quantity) for o in plan.orders] == [("SGOV", OrderSide.BUY, 3)]
    assert all(order.symbol != "TQQQ" for order in plan.orders)
    assert plan.entry_split["destination_action"] == "SAFE"
    assert plan.entry_split["destination_symbol"] == "SGOV"
    assert "SGOV" in plan.reason
    assert state["entry_reserved_cash"] == "0"
    assert state["entry_reserved_cash_balance"] == "0"
    assert state["entry_split_status"] == "TERMINATED_OVERHEAT"
    assert state["entry_split_terminated_reason"] == "OVERHEAT"
    assert state["entry_split_done"] == 2


def test_active_split_overheat_action_routes_only_reserve_to_overheat():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="OVERHEAT"))
    original = portfolio()
    plan, state = engine.evaluate(overheat_indicator(), original, active_state(), Decimal("110"))
    assert [(o.symbol, o.side, o.quantity) for o in plan.orders] == [("SPYM", OrderSide.BUY, 3)]
    assert all(order.symbol != "TQQQ" for order in plan.orders)
    assert original.main_quantity == Decimal("6")
    assert plan.entry_split["destination_action"] == "OVERHEAT"
    assert plan.entry_split["destination_symbol"] == "SPYM"
    assert "SPYM" in plan.reason
    assert state["entry_reserved_cash"] == "60"
    assert state["entry_split_status"] == "TERMINATED_OVERHEAT"


def test_overheat_residual_is_released_to_new_cash_on_next_run_without_resuming_split():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="OVERHEAT"))
    _, terminated = engine.evaluate(overheat_indicator(), portfolio(), active_state(), Decimal("110"))
    next_portfolio = portfolio("60")
    next_portfolio.overheat_quantity = Decimal("3")
    next_portfolio.prices["SPYM"] = Decimal("50")
    plan, state = engine.evaluate(overheat_indicator(), next_portfolio, terminated, Decimal("110"))
    assert [(order.symbol, order.quantity) for order in plan.orders] == [("SPYM", 1)]
    assert plan.decision == "NEW_CASH_SPYM"
    assert state["entry_reserved_cash"] == "0"
    assert state["entry_reserved_cash_balance"] == "0"
    assert state["entry_split_status"] == "TERMINATED_OVERHEAT"
    assert state["entry_split_done"] == 2


@pytest.mark.parametrize(
    ("action", "symbol", "kind"),
    [("SAFE", "SGOV", "BUY_ENTRY_SAFE"), ("OVERHEAT", "SPYM", "BUY_ENTRY_OVERHEAT")],
)
def test_overheat_termination_workflow_persists_selected_destination(action, symbol, kind):
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action=action))
    plan, state = engine.evaluate(overheat_indicator(), portfolio(), active_state(), Decimal("110"))
    decision = StrategyDecision("generic", plan.decision, plan.reason, plan.decision, state)
    steps = WorkflowExecutor(None, None, None)._build_steps(decision, plan, "TQQQ", "SPYM", "SGOV")
    assert steps == [{
        "leg": f"BUY_{symbol}_ENTRY_TERMINATION", "kind": kind,
        "symbol": symbol, "budget": "300", "required": False,
    }]


def test_sub_one_share_reserve_creates_no_order_and_terminates_without_deadlock():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="SAFE"))
    small = portfolio("50")
    state_before = active_state()
    state_before["entry_reserved_cash"] = "50"
    state_before["entry_reserved_cash_balance"] = "50"
    decision, plan = engine.evaluate_decision(overheat_indicator(), small, state_before, Decimal("110"))
    assert plan.orders == []
    steps = WorkflowExecutor(None, None, None)._build_steps(decision, plan, "TQQQ", "SPYM", "SGOV")
    assert steps == []
    workflow = {
        "workflow_id": "wf-zero-order", "status": "READY_TO_COMMIT", "signal_date": "2026-09-15",
        "pending_state_transition": decision.pending_state_transition,
        "entry_split": plan.entry_split, "steps": steps,
    }
    ledger = CommitLedger({"active_workflow": workflow, "orders": []})
    state_store = CommitState(state_before)
    committed = WorkflowExecutor(None, ledger, None).commit_confirmed_state(state_store, small)
    assert committed["entry_split_status"] == "TERMINATED_OVERHEAT"
    assert ledger.data["active_workflow"] is None


def test_all_strategy_symbols_can_be_distinct():
    engine = StrategyEngine(StrategyConfig(
        main_symbol="MAINX", overheat_symbol="HOTX", safe_symbol="SAFEX",
        entry_split=3, entry_split_overheat_action="SAFE",
    ))
    indicator = IndicatorResult(
        "SIGNALX", Decimal("110"), Decimal("100"), Decimal("105"), Decimal("100"), True, True, Decimal("105"),
    )
    holdings = PortfolioState(
        main_quantity=Decimal("6"), main_avg_price=Decimal("100"), available_cash_usd=Decimal("300"),
        prices={"MAINX": Decimal("110"), "HOTX": Decimal("80"), "SAFEX": Decimal("100")},
    )
    plan, state = engine.evaluate(indicator, holdings, active_state(), Decimal("110"))
    assert [(order.symbol, order.quantity) for order in plan.orders] == [("SAFEX", 3)]
    assert state["entry_split_status"] == "TERMINATED_OVERHEAT"


def test_app_config_action_defaults_validates_and_accepts_case(monkeypatch):
    required = {
        "SIGNAL_SYMBOL": "SIGNALX", "MAIN_SYMBOL": "MAINX", "OVERHEAT_SYMBOL": "HOTX",
        "SAFE_SYMBOL": "SAFEX", "RISK_THRESHOLD": "1", "OVERHEAT_THRESHOLD": "1.05",
        "SIGNAL_TIME": "15:57:00",
    }
    for key, value in required.items():
        monkeypatch.setenv(key, value)
    monkeypatch.delenv("ENTRY_SPLIT_OVERHEAT_ACTION", raising=False)
    default_config = AppConfig.load()
    assert default_config.resolved_strategy().entry_split_overheat_action == "SAFE"
    assert default_config.strategy_rules.entry_split_overheat_action == "SAFE"
    monkeypatch.setenv("ENTRY_SPLIT_OVERHEAT_ACTION", "overheat")
    assert AppConfig.load().resolved_strategy().entry_split_overheat_action == "OVERHEAT"
    monkeypatch.setenv("ENTRY_SPLIT_OVERHEAT_ACTION", "main")
    assert AppConfig.load().resolved_strategy().entry_split_overheat_action == "MAIN"
    monkeypatch.setenv("ENTRY_SPLIT_OVERHEAT_ACTION", "SELL")
    with pytest.raises(ValueError, match="ENTRY_SPLIT_OVERHEAT_ACTION"):
        AppConfig.load()


def test_overheat_action_is_runtime_routing_not_installation_identity():
    identity = AppConfig().resolved_strategy().installation_identity("CLOSE")
    assert "entry_split_overheat_action" not in identity


class CommitLedger:
    def __init__(self, data):
        self.data = data

    def load(self):
        return self.data

    def complete_workflow(self):
        self.data["active_workflow"] = None


class CommitState:
    def __init__(self, value):
        self.value = dict(value)

    def load_state_strict(self):
        return dict(self.value)

    def save_state(self, value):
        self.value = dict(value)

    @staticmethod
    def account_snapshot(portfolio_state):
        return {"available_cash_usd": str(portfolio_state.available_cash_usd)}


def termination_commit_fixture(action, workflow_status="READY_TO_COMMIT", order_status="FILLED"):
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action=action))
    decision, plan = engine.evaluate_decision(overheat_indicator(), portfolio(), active_state(), Decimal("110"))
    executor = WorkflowExecutor(None, None, None)
    steps = executor._build_steps(decision, plan, "TQQQ", "SPYM", "SGOV")
    orders = []
    if steps:
        planned = plan.orders[0]
        orders.append({
            "workflow_id": "wf-termination", "leg": steps[0]["leg"], "status": order_status,
            "filled_amount": str(Decimal(planned.quantity) * planned.price),
        })
    workflow = {
        "workflow_id": "wf-termination", "status": workflow_status, "signal_date": "2026-09-15",
        "pending_state_transition": decision.pending_state_transition,
        "entry_split": plan.entry_split, "steps": steps,
    }
    ledger = CommitLedger({"active_workflow": workflow, "orders": orders})
    state = CommitState(active_state())
    executor.ledger_store = ledger
    return executor, state


@pytest.mark.parametrize("action", ["SAFE", "OVERHEAT"])
def test_selected_destination_commits_same_terminal_state_only_after_confirmation(action):
    executor, state = termination_commit_fixture(action)
    committed = executor.commit_confirmed_state(state, portfolio("0" if action == "SAFE" else "60"))
    assert committed["entry_split_status"] == "TERMINATED_OVERHEAT"
    assert committed["entry_split_terminated_reason"] == "OVERHEAT"
    assert committed["entry_split_done"] == 2
    assert executor.ledger_store.data["active_workflow"] is None


@pytest.mark.parametrize(
    ("workflow_status", "order_status"),
    [("PARTIAL_FILLED_BLOCKED", "PARTIAL_FILLED_BLOCKED"), ("UNKNOWN", "UNKNOWN")],
)
def test_partial_or_unknown_cannot_commit_terminated_overheat(workflow_status, order_status):
    executor, state = termination_commit_fixture("OVERHEAT", workflow_status, order_status)
    with pytest.raises(WorkflowBlocked, match="No workflow ready to commit"):
        executor.commit_confirmed_state(state, portfolio("60"))
    assert state.value["entry_split_status"] == "ACTIVE"


def test_risk_off_policy_still_routes_to_safe():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="OVERHEAT"))
    plan, state = engine.evaluate(overheat_indicator(False), portfolio(), active_state(), Decimal("40"))
    assert plan.decision == "RISK_OFF"
    assert any(order.side == OrderSide.BUY and order.symbol == "SGOV" for order in plan.orders)
    assert state["entry_split_status"] == "TERMINATED_RISK_OFF"


def one_of_three_state():
    state = active_state()
    state.update(
        entry_split_done=1, entry_reserved_cash="600",
        entry_reserved_cash_balance="600",
    )
    return state


def test_main_action_continues_active_split_in_main_without_termination():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="MAIN"))
    holdings = portfolio("600")
    plan, state = engine.evaluate(overheat_indicator(), holdings, one_of_three_state(), Decimal("110"))
    assert plan.decision == "ENTRY_SPLIT_TRANCHE_OVERHEAT_MAIN"
    assert [(o.symbol, o.quantity) for o in plan.orders] == [("TQQQ", 2)]
    assert plan.entry_split["tranche_index"] == 2
    assert plan.entry_split["total"] == 3
    assert plan.entry_split["budget"] == "300"
    assert plan.entry_split["overheat_action"] == "MAIN"
    assert state["entry_split_status"] == "ACTIVE"
    assert state["entry_split_done"] == 2
    assert state["entry_split_total"] == 3
    assert state["entry_reserved_cash"] == "380"
    assert "ENTRY_SPLIT_OVERHEAT_ACTION=MAIN" in plan.reason


def test_main_action_completes_original_tranches_over_two_overheat_days():
    engine = StrategyEngine(StrategyConfig(entry_split=9, entry_split_overheat_action="MAIN"))
    first_plan, after_second = engine.evaluate(
        overheat_indicator(), portfolio("600"), one_of_three_state(), Decimal("110"),
    )
    assert first_plan.entry_split["tranche_index"] == 2
    assert first_plan.entry_split["total"] == 3
    third_day = portfolio(after_second["entry_reserved_cash_balance"])
    final_plan, completed = engine.evaluate(overheat_indicator(), third_day, after_second, Decimal("110"))
    assert final_plan.entry_split["tranche_index"] == 3
    assert final_plan.entry_split["total"] == 3
    assert completed["entry_split_status"] == "COMPLETED"
    assert completed["entry_split_done"] == 3


def test_main_action_keeps_external_cash_separate_and_routes_it_to_overheat():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="MAIN"))
    state_before = one_of_three_state()
    holdings = portfolio("800")  # persisted reserve cash 600 + New Cash 200
    plan, state = engine.evaluate(overheat_indicator(), holdings, state_before, Decimal("110"))
    assert [(o.symbol, o.quantity) for o in plan.orders] == [("TQQQ", 2), ("SPYM", 2)]
    assert plan.entry_split["budget"] == "300"
    assert plan.entry_split["new_cash_budget"] == "200"
    assert plan.entry_split["new_cash_symbol"] == "SPYM"
    assert state["entry_split_total"] == 3
    assert state["entry_reserved_cash"] == "380"
    assert state["entry_reserved_cash_balance"] == "380"


def test_main_action_without_active_split_does_not_start_main_entry_in_overheat():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="MAIN"))
    state = one_of_three_state()
    state.update(entry_split_status="INACTIVE", entry_split_total=0, entry_split_done=0,
                 entry_reserved_cash="0", entry_reserved_cash_balance="0", cycle_state="WAIT")
    holdings = portfolio("240")
    holdings.main_quantity = Decimal("0")
    plan, updated = engine.evaluate(overheat_indicator(), holdings, state, Decimal("110"))
    assert plan.decision == "RISK_ON_OVERHEAT_ENTRY"
    assert [(o.symbol, o.quantity) for o in plan.orders] == [("SPYM", 3)]
    assert updated["entry_split_status"] == "INACTIVE"


def test_main_continuation_workflow_persists_main_and_new_cash_budgets():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="MAIN"))
    decision, plan = engine.evaluate_decision(
        overheat_indicator(), portfolio("800"), one_of_three_state(), Decimal("110"),
    )
    steps = WorkflowExecutor(None, None, None)._build_steps(decision, plan, "TQQQ", "SPYM", "SGOV")
    assert steps == [
        {"leg": "BUY_TQQQ_ENTRY_2", "kind": "BUY_ENTRY_TRANCHE", "symbol": "TQQQ", "budget": "300", "required": False},
        {"leg": "BUY_SPYM_NEW_CASH_ENTRY_2", "kind": "BUY_NEW_CASH_OVERHEAT", "symbol": "SPYM", "budget": "200", "required": False},
    ]


def test_started_safe_workflow_is_not_reinterpreted_after_action_changes_to_main():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="SAFE"))
    decision, plan = engine.evaluate_decision(
        overheat_indicator(), portfolio(), active_state(), Decimal("110"),
    )
    engine.config.entry_split_overheat_action = "MAIN"
    steps = WorkflowExecutor(None, None, None)._build_steps(decision, plan, "TQQQ", "SPYM", "SGOV")
    assert plan.entry_split["destination_action"] == "SAFE"
    assert steps[0]["kind"] == "BUY_ENTRY_SAFE"
    assert steps[0]["symbol"] == "SGOV"


def test_main_action_risk_off_still_terminates_and_routes_safe():
    # Runtime ENTRY_SPLIT may have changed after this persisted 3-tranche split began.
    engine = StrategyEngine(StrategyConfig(entry_split=1, entry_split_overheat_action="MAIN"))
    plan, state = engine.evaluate(overheat_indicator(False), portfolio(), active_state(), Decimal("40"))
    assert plan.decision == "RISK_OFF"
    assert all(not (o.side == OrderSide.BUY and o.symbol == "TQQQ") for o in plan.orders)
    assert any(o.side == OrderSide.BUY and o.symbol == "SGOV" for o in plan.orders)
    assert state["entry_split_status"] == "TERMINATED_RISK_OFF"


def test_main_action_does_not_override_drawdown_priority():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="MAIN"))
    state = active_state()
    state["cycle_high_close"] = 200
    plan, updated = engine.evaluate(overheat_indicator(), portfolio(), state, Decimal("110"))
    assert plan.decision == "DRAWDOWN_REDUCE"
    assert updated["entry_split_status"] == "ACTIVE"


def test_main_action_does_not_override_milestone_priority():
    engine = StrategyEngine(StrategyConfig(
        entry_split=3, entry_split_overheat_action="MAIN", milestones=((100, Decimal("0.5")),),
    ))
    holdings = portfolio()
    holdings.main_avg_price = Decimal("50")
    plan, updated = engine.evaluate(overheat_indicator(), holdings, active_state(), Decimal("110"))
    assert plan.decision == "MILESTONE_100"
    assert updated["entry_split_status"] == "ACTIVE"


@pytest.mark.parametrize("status", ["PARTIAL_FILLED_BLOCKED", "UNKNOWN"])
def test_main_continuation_partial_or_unknown_cannot_commit(status):
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="MAIN"))
    decision, plan = engine.evaluate_decision(
        overheat_indicator(), portfolio("600"), one_of_three_state(), Decimal("110"),
    )
    steps = WorkflowExecutor(None, None, None)._build_steps(decision, plan, "TQQQ", "SPYM", "SGOV")
    workflow = {
        "workflow_id": "wf-main", "status": status, "signal_date": "2026-09-29",
        "pending_state_transition": decision.pending_state_transition,
        "entry_split": plan.entry_split, "steps": steps,
    }
    ledger = CommitLedger({"active_workflow": workflow, "orders": [{
        "workflow_id": "wf-main", "leg": steps[0]["leg"], "status": status,
    }]})
    state_store = CommitState(one_of_three_state())
    with pytest.raises(WorkflowBlocked, match="No workflow ready to commit"):
        WorkflowExecutor(None, ledger, None).commit_confirmed_state(state_store, portfolio())
    assert state_store.value["entry_split_status"] == "ACTIVE"
    assert state_store.value["entry_split_done"] == 1


def test_main_action_zero_share_tranche_creates_no_zero_order():
    engine = StrategyEngine(StrategyConfig(entry_split=3, entry_split_overheat_action="MAIN"))
    state = one_of_three_state()
    state.update(entry_base_cash="150", entry_reserved_cash="100", entry_reserved_cash_balance="100")
    holdings = portfolio("100")
    plan, updated = engine.evaluate(overheat_indicator(), holdings, state, Decimal("110"))
    assert plan.orders == []
    assert updated["entry_split_status"] == "ACTIVE"
    assert updated["entry_split_done"] == 2
